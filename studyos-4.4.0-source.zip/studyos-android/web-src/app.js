(() => {
  'use strict';
  const STORE_KEY = 'studyos.v1.data';
  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  const todayISO = () => { const d=new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
  const addDays = (n) => { const d=new Date(); d.setDate(d.getDate()+n); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
  const uid = () => `${Date.now().toString(36)}${Math.random().toString(36).slice(2,8)}`;
  const esc = (v='') => String(v).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const fmtDate = (s, opts={month:'short',day:'numeric'}) => { if(!s)return 'No date'; const d=new Date(`${s}T12:00:00`); return Number.isNaN(+d)?s:d.toLocaleDateString(undefined,opts); };
  const fmtLong = (s) => fmtDate(s,{weekday:'long',month:'long',day:'numeric'});
  const daysUntil = (s) => { if(!s)return null; const a=new Date(`${todayISO()}T12:00:00`), b=new Date(`${s}T12:00:00`); return Math.round((b-a)/86400000); };
  const monthShort = (s) => s ? new Date(`${s}T12:00:00`).toLocaleDateString(undefined,{month:'short'}).toUpperCase() : '—';
  const defaultData = () => ({
    profile:{name:'Student',year:'Year 10',schoolYear:'2026–2027',term:'Term 1',grading:'percentage',target:90,theme:'system',accent:'mono',weeklyGoal:300,customColor:'#6750a4',black:true,avatar:'',weekStart:'Monday',reminders:true},
    subjects:[
      {id:'s-math',name:'Mathematics',code:'MATH',color:'#6750a4',target:95,scheme:'percentage',categories:[{name:'Exams',weight:60},{name:'Coursework',weight:25},{name:'Quizzes',weight:15}]},
      {id:'s-physics',name:'Physics',code:'PHYS',color:'#4776a8',target:90,scheme:'percentage',categories:[{name:'Exams',weight:60},{name:'Coursework',weight:25},{name:'Quizzes',weight:15}]},
      {id:'s-chem',name:'Chemistry',code:'CHEM',color:'#2f7654',target:90,scheme:'percentage',categories:[{name:'Exams',weight:60},{name:'Coursework',weight:25},{name:'Quizzes',weight:15}]},
      {id:'s-english',name:'English',code:'ENG',color:'#b16a38',target:88,scheme:'percentage',categories:[{name:'Exams',weight:50},{name:'Coursework',weight:30},{name:'Quizzes',weight:20}]}
    ],
    assessments:[
      {id:'a1',subjectId:'s-math',title:'Algebra test',category:'Exams',score:96,maxScore:100,date:addDays(-12),weight:1},
      {id:'a2',subjectId:'s-math',title:'Functions quiz',category:'Quizzes',score:92,maxScore:100,date:addDays(-7),weight:1},
      {id:'a3',subjectId:'s-physics',title:'Forces assessment',category:'Exams',score:89,maxScore:100,date:addDays(-10),weight:1},
      {id:'a4',subjectId:'s-chem',title:'Chemical equations',category:'Coursework',score:87,maxScore:100,date:addDays(-5),weight:1},
      {id:'a5',subjectId:'s-english',title:'Reading analysis',category:'Coursework',score:84,maxScore:100,date:addDays(-4),weight:1}
    ],
    tasks:[
      {id:'t1',title:'Finish algebra practice',subjectId:'s-math',due:addDays(0),priority:'High',status:'In progress',estimate:35,description:'Complete the assigned practice questions.',createdAt:todayISO()},
      {id:'t2',title:'Forces and motion worksheet',subjectId:'s-physics',due:addDays(1),priority:'Medium',status:'Not started',estimate:45,description:'Show working for each calculation.',createdAt:todayISO()},
      {id:'t3',title:'Balance chemical equations',subjectId:'s-chem',due:addDays(3),priority:'High',status:'Not started',estimate:30,description:'Balance each equation and check atom counts.',createdAt:todayISO()},
      {id:'t4',title:'English essay plan',subjectId:'s-english',due:addDays(5),priority:'Low',status:'Submitted',estimate:40,description:'Prepare an outline for the essay.',createdAt:todayISO()}
    ],
    exams:[
      {id:'e1',title:'Mathematics exam',subjectId:'s-math',date:addDays(8),time:'09:00',topics:'Algebra, functions, bounds',notes:'Bring calculator and ruler.'},
      {id:'e2',title:'Physics test',subjectId:'s-physics',date:addDays(14),time:'10:30',topics:'Forces, motion, energy',notes:''}
    ],
    schoolTimetable:{days:['Mon','Tue','Wed','Thu','Fri'],slots:[]},
    sessions:[],notes:[],events:[],flashcards:[],mistakes:[],formulas:[],pastPapers:[],topics:[{id:'tp1',subjectId:'s-math',title:'Algebra',status:'Practising',difficulty:'Medium'},{id:'tp2',subjectId:'s-math',title:'Functions',status:'Learning',difficulty:'Medium'},{id:'tp3',subjectId:'s-physics',title:'Forces and motion',status:'Learning',difficulty:'Hard'},{id:'tp4',subjectId:'s-chem',title:'Balancing equations',status:'Practising',difficulty:'Medium'}],settings:{sampleData:true},mindMaps:[]
  });
  const BUILTIN_FORMULAS=[
    {subject:'Mathematics',topic:'Algebra',title:'Quadratic formula',expression:'x = (-b ± √(b² - 4ac)) / 2a',notes:'For ax² + bx + c = 0.'},
    {subject:'Mathematics',topic:'Geometry',title:'Area of a circle',expression:'A = πr²',notes:'r is the radius.'},
    {subject:'Mathematics',topic:'Geometry',title:'Pythagorean theorem',expression:'a² + b² = c²',notes:'For a right-angled triangle; c is the hypotenuse.'},
    {subject:'Physics',topic:'Motion',title:'Speed',expression:'speed = distance / time',notes:'Use consistent units.'},
    {subject:'Physics',topic:'Motion',title:'Acceleration',expression:'a = (v - u) / t',notes:'u initial velocity, v final velocity, t time.'},
    {subject:'Physics',topic:'Forces',title:'Newton’s second law',expression:'F = ma',notes:'Resultant force = mass × acceleration.'},
    {subject:'Physics',topic:'Electricity',title:'Ohm’s law',expression:'V = IR',notes:'Voltage = current × resistance.'},
    {subject:'Chemistry',topic:'Moles',title:'Amount of substance',expression:'n = m / Mᵣ',notes:'Mass divided by molar mass.'}
  ];
  let data;
  try { data = JSON.parse(localStorage.getItem(STORE_KEY)) || defaultData(); } catch { data=defaultData(); }
  // Recover missing fields if an older saved version is opened.
  const seed=defaultData();
  for(const k of Object.keys(seed)) if(data[k]===undefined) data[k]=seed[k];
  if(!Array.isArray(data.topics)) data.topics=[];
  if(!data.profile) data.profile=seed.profile;
  data.profile={...seed.profile,...data.profile};
  const ACCENTS={mono:{label:'Black + Grey',h:0,s:0},violet:{label:'Material purple',h:258,s:34},indigo:{label:'Indigo',h:232,s:46},blue:{label:'Google blue',h:218,s:68},cyan:{label:'Cyan',h:192,s:72},teal:{label:'Teal',h:172,s:58},green:{label:'Sage green',h:112,s:38},lime:{label:'Lime',h:78,s:58},amber:{label:'Amber',h:42,s:78},orange:{label:'Orange',h:22,s:74},red:{label:'Crimson',h:4,s:66},rose:{label:'Rose',h:336,s:62},orchid:{label:'Orchid',h:298,s:44},graphite:{label:'Graphite',h:215,s:7}};
  const clampN=(v,a,b)=>Math.max(a,Math.min(b,v));
  function hslHex(h,s,l){s=clampN(s,0,100)/100;l=clampN(l,0,100)/100;const k=n=>(n+h/30)%12,a=s*Math.min(l,1-l),f=n=>l-a*Math.max(-1,Math.min(k(n)-3,Math.min(9-k(n),1))),x=v=>Math.round(255*v).toString(16).padStart(2,'0');return `#${x(f(0))}${x(f(8))}${x(f(4))}`;}
  function hexToHS(hex){const m=/^#?([0-9a-f]{6})$/i.exec(hex||'');if(!m)return{h:258,s:34};const n=parseInt(m[1],16),r=(n>>16&255)/255,g=(n>>8&255)/255,b=(n&255)/255,mx=Math.max(r,g,b),mn=Math.min(r,g,b),d=mx-mn,l=(mx+mn)/2;let h=0;if(d){if(mx===r)h=((g-b)/d)%6;else if(mx===g)h=(b-r)/d+2;else h=(r-g)/d+4;h=Math.round(h*60);if(h<0)h+=360;}const s=d?d/(1-Math.abs(2*l-1))*100:0;return{h,s:clampN(Math.round(s),5,85)};}
  function normalize(){
    const seed=defaultData();
    if(!data||typeof data!=='object')data=seed;
    for(const k of Object.keys(seed)) if(data[k]===undefined) data[k]=seed[k];
    ['subjects','assessments','tasks','exams','sessions','topics','notes','events','flashcards','mistakes','formulas','pastPapers'].forEach(k=>{if(!Array.isArray(data[k]))data[k]=[];data[k]=data[k].filter(Boolean);});
    ['subjects','assessments','tasks','exams','sessions','topics','pastPapers','flashcards','mistakes','formulas'].forEach(k=>data[k].forEach(x=>{if(!x.id)x.id=uid();}));
    data.profile={...seed.profile,...(data.profile||{})};
    if(!['system','light','dark'].includes(data.profile.theme))data.profile.theme='system';
    if(data.profile.accent!=='custom'&&!ACCENTS[data.profile.accent])data.profile.accent='violet';
    if(!/^#[0-9a-f]{6}$/i.test(data.profile.customColor||''))data.profile.customColor='#6750a4';
    data.profile.black=!!data.profile.black;
    const wg=Number(data.profile.weeklyGoal);data.profile.weeklyGoal=Number.isFinite(wg)?Math.max(0,Math.min(10080,Math.round(wg))):300;
    if(!data.settings||typeof data.settings!=='object')data.settings={sampleData:false};
    if(!Array.isArray(data.mindMaps))data.mindMaps=[];
    data.mindMaps=data.mindMaps.filter(m=>m&&typeof m==='object').map(mmClean);
  }
  normalize();
  /* Animation preference: ONE switch. data-motion="off" on <html> (CSS) + animationsOff() (JS). Device-local, not part of backups. */
  let userAnimOff=(()=>{try{return localStorage.getItem('studyos.pref.animations')==='off';}catch{return false;}})();
  const osReduceMotion=()=>!!(window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches);
  const animationsOff=()=>userAnimOff||osReduceMotion();
  const reduceMotion=animationsOff;
  let revealIO=null,revealWired=false,revealPend=[],revealShow=null;
  function clearReveal(){if(revealIO){revealIO.disconnect();revealIO=null;}revealPend=[];document.querySelectorAll('.rv').forEach(el=>el.classList.remove('rv'));}
  function applyMotion(){const off=animationsOff();document.documentElement.dataset.motion=off?'off':'on';if(off)clearReveal();}
  applyMotion();
  if(window.matchMedia){const mmq=matchMedia('(prefers-reduced-motion: reduce)');if(mmq.addEventListener)mmq.addEventListener('change',applyMotion);}
  function setAnimOff(v){userAnimOff=!!v;try{if(userAnimOff)localStorage.setItem('studyos.pref.animations','off');else localStorage.removeItem('studyos.pref.animations');}catch{}applyMotion();render();}
  const prefersDark=()=>!!(window.matchMedia&&matchMedia('(prefers-color-scheme: dark)').matches);
  function buildPalette(h,s,dark,black){
    const c=v=>clampN(Math.round(v),0,100),k=Math.min(1,(s+8)/38),t=v=>c(v*k),H=(sat,l)=>`hsl(${h} ${s===0?0:c(sat)}% ${l}%)`,warm=h>35&&h<85;
    if(dark){
      const bg=black?'#000':H(t(14),8),surface=black?H(t(10),6):H(t(12),13),low=black?H(t(8),4):H(t(12),10.5);
      return {'--primary':H(s+35,warm?68:82),'--primary-dark':H(s+30,warm?58:72),'--on-primary':H(s+10,14),'--primary-container':H(s,26),'--on-primary-container':H(60,90),'--bg':bg,'--surface':surface,'--surface-low':low,'--surface-high':black?H(t(10),11):H(t(10),18),'--line':H(t(10),black?19:27),'--text':H(t(20),91),'--muted':H(t(12),76),'--side':low,'--topbar':surface};
    }
    return {'--primary':H(s+18,warm?30:38),'--primary-dark':H(s+18,warm?22:29),'--on-primary':'#ffffff','--primary-container':H(s+50,90),'--on-primary-container':H(s+45,13),'--bg':H(t(45),97),'--surface':H(t(40),99),'--surface-low':H(t(32),95),'--surface-high':H(t(26),91),'--line':H(t(20),88),'--text':H(t(20),11),'--muted':H(t(10),38),'--side':H(t(36),94),'--topbar':H(t(40),98)};
  }
  function applyAppearance(){
    const p=data.profile,theme=p.theme||'system',dark=theme==='dark'||(theme==='system'&&prefersDark()),root=document.documentElement;
    root.dataset.theme=theme;root.dataset.accent=p.accent;
    const a=p.accent==='custom'?hexToHS(p.customColor):(ACCENTS[p.accent]||ACCENTS.violet),vars=buildPalette(a.h,a.s,dark,!!p.black);
    for(const k in vars)root.style.setProperty(k,vars[k]);
    const lg=logoColors(a.h,a.s,dark);root.style.setProperty('--logo-bg',lg.bg);root.style.setProperty('--logo-fg',lg.fg);
    const tv=toneVars(a.h,a.s,dark);for(const k in tv)root.style.setProperty(k,tv[k]);
    const fav=document.querySelector('link[rel=icon]');if(fav){const svg=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128"><rect width="128" height="128" rx="34" fill="${lg.bg}"/><path d="${LOGO_PATH}" fill="${lg.fg}"/></svg>`;const href='data:image/svg+xml,'+encodeURIComponent(svg);if(fav.getAttribute('href')!==href)fav.setAttribute('href',href);}
    const meta=document.querySelector('meta[name=theme-color]');
    if(meta){const warm=a.h>35&&a.h<85,kk=Math.min(1,(a.s+8)/38);meta.content=dark?hslHex(a.h,a.s===0?0:14*kk,p.black?0:8):hslHex(a.h,a.s===0?0:a.s+18,warm?30:38);}
  }
  if(window.matchMedia){const mq=matchMedia('(prefers-color-scheme: dark)');const onMq=()=>{if(data.profile.theme==='system')applyAppearance();};if(mq.addEventListener)mq.addEventListener('change',onMq);}
  let selectedDay=todayISO(), playNext=true, splashActive=true, currentView='home', taskFilter='All', taskSearch='', academicTab='subjects', selectedMonth=new Date().getMonth(), selectedYear=new Date().getFullYear(), toastTimer;
  let focusMinutes=25, focusSeconds=25*60, focusRunning=false, focusInterval=null, focusSubjectId='', focusMode='Focus session', pastPaperEditingId='';
  const focusBreakMinutes=()=>Math.max(1,Math.round(focusMinutes/3));
  const focusTotalSeconds=()=>((focusMode==='Break'||focusMode==='Short break'||focusMode==='Long break'?focusBreakMinutes():focusMinutes)*60);
  const updateFocusVisual=()=>{const ring=$('#focusTimerRing'),clock=$('#focusClock');if(ring)ring.style.setProperty('--timer-progress',`${Math.max(0,Math.min(100,((focusTotalSeconds()-focusSeconds)/focusTotalSeconds())*100))}%`);if(ring){ring.classList.toggle('is-running',focusRunning);ring.classList.toggle('is-complete',focusSeconds===0);}};
  const save = () => { try { localStorage.setItem(STORE_KEY,JSON.stringify(data));  } catch { toast('Could not save: device storage may be full. Export a backup.'); } };
  const toast = (msg) => { const el=$('#toast'); el.textContent=msg; el.classList.add('show'); clearTimeout(toastTimer); toastTimer=setTimeout(()=>el.classList.remove('show'),2600); };
  const subject = id => data.subjects.find(s=>s.id===id);
  const subjectName = id => subject(id)?.name || 'Unassigned';
  const subjectColor = id => subject(id)?.color || '#8a8292';
  const average = vals => vals.length ? vals.reduce((a,b)=>a+b,0)/vals.length : null;
  const scorePct = a => Number(a.maxScore)>0 && Number.isFinite(Number(a.score)) ? Number(a.score)/Number(a.maxScore)*100 : null;
  function categoryPct(s, catName) { const vals=data.assessments.filter(a=>a.subjectId===s.id&&a.category===catName).map(scorePct).filter(v=>v!==null); return average(vals); }
  function gradeFor(s) {
    const records=data.assessments.filter(a=>a.subjectId===s.id&&scorePct(a)!==null);
    if(!records.length)return null;
    if(s.scheme==='unweighted')return average(records.map(scorePct));
    const cats=(s.categories||[]).filter(c=>Number(c.weight)>0);
    if(!cats.length)return average(records.map(scorePct));
    const valid=cats.map(c=>({weight:Number(c.weight),pct:categoryPct(s,c.name)})).filter(c=>c.pct!==null);
    const total=valid.reduce((n,c)=>n+c.weight,0);
    if(!valid.length||total<=0)return null;
    // Current grade is normalized over categories that have graded assessments.
    return valid.reduce((n,c)=>n+c.pct*c.weight,0)/total;
  }
  function totalAverage() { return average(data.subjects.map(gradeFor).filter(v=>v!==null)); }
  const pct = v => v===null||v===undefined ? '—' : `${Math.round(v*10)/10}%`;
  const initials = name => (name||'S').trim().split(/\s+/).slice(0,2).map(s=>s[0]||'').join('').toUpperCase()||'S';
  const activeTasks = () => data.tasks.filter(t=>!['Submitted','Graded','Cancelled'].includes(t.status));
  const sortedTasks = list => [...list].sort((a,b)=> (a.due||'9999').localeCompare(b.due||'9999') || ({High:0,Medium:1,Low:2}[a.priority]??1)-({High:0,Medium:1,Low:2}[b.priority]??1));
  function duePill(t) { const d=daysUntil(t.due); if(!t.due)return '<span class="due-pill">No deadline</span>'; if(t.status==='Submitted'||t.status==='Graded')return `<span class="due-pill">${esc(fmtDate(t.due))}</span>`; if(d<0)return `<span class="due-pill urgent">${Math.abs(d)}d overdue</span>`; if(d===0)return '<span class="due-pill urgent">Due today</span>'; if(d<=2)return `<span class="due-pill soon">Due ${esc(d===1?'tomorrow':fmtDate(t.due))}</span>`; return `<span class="due-pill">${esc(fmtDate(t.due))}</span>`; }
  function statusPill(status) { return `<span class="status-pill ${status.toLowerCase().replace(/\s+/g,'-')}">${esc(status)}</span>`; }
  function heading(eyebrow,title,desc,action='') { return `<div class="page-heading"><div><div class="eyebrow">${esc(eyebrow)}</div><h1>${title}</h1><p>${desc}</p></div>${action}</div>`; }
  function emptyState(icon,title,desc,button='') { return `<div class="empty-state"><div class="empty-icon">${icon}</div><strong>${title}</strong><div>${desc}</div>${button?`<div style="margin-top:13px">${button}</div>`:''}</div>`; }
  function button(label,action,kind='primary',extra='') { return `<button class="button ${kind}" data-action="${action}" ${extra}>${label}</button>`; }
  function processAvatar(file){if(!file.type.startsWith('image/')){toast('Choose an image file.');return;}if(file.size>12*1024*1024){toast('Choose an image under 12 MB.');return;}const reader=new FileReader();reader.onload=()=>{const img=new Image();img.onload=()=>{const canvas=document.createElement('canvas'),max=320,scale=Math.min(1,max/Math.max(img.width,img.height));canvas.width=Math.round(img.width*scale);canvas.height=Math.round(img.height*scale);const ctx=canvas.getContext('2d');ctx.drawImage(img,0,0,canvas.width,canvas.height);data.profile.avatar=canvas.toDataURL('image/jpeg',0.82);save();render();toast('Profile picture updated.');};img.onerror=()=>toast('Could not read that image.');img.src=reader.result;};reader.readAsDataURL(file);}
  function render() {
    $('#pageCrumb').textContent={home:'Home',academics:'Academics',tasks:'Tasks',planner:'Planner',timetable:'Timetable',pastpapers:'Past Papers',insights:'Insights',tools:'StudyOS Tools',mindmap:'Tools / Mind Map',settings:'Settings',studyspace:'Study Space'}[currentView]||'Home';
    $$('.nav-item[data-view],.mobile-nav-item[data-view]').forEach(el=>el.classList.toggle('active',el.dataset.view===currentView||(currentView==='mindmap'&&el.dataset.view==='tools')));
    applyAppearance();
    $('#profileName').textContent=data.profile.name||'Student'; $('#profileYear').textContent=data.profile.year||'Academic year';
    const avatarHtml=data.profile.avatar?`<img src="${data.profile.avatar}" alt="Profile picture">`:'';
    const sideAvatar=$('#avatarInitial'),topAvatar=$('#topProfile');
    if(avatarHtml){sideAvatar.innerHTML=avatarHtml;topAvatar.innerHTML=avatarHtml;sideAvatar.classList.add('has-photo');topAvatar.classList.add('has-photo');}else{sideAvatar.textContent=initials(data.profile.name);topAvatar.textContent=initials(data.profile.name);sideAvatar.classList.remove('has-photo');topAvatar.classList.remove('has-photo');}
    $('#taskNavCount').textContent=activeTasks().length;
    $('#todayLabel').textContent=new Date().toLocaleDateString(undefined,{weekday:'short',month:'short',day:'numeric'});
    const views={home:renderHome,academics:renderAcademics,tasks:renderTasks,planner:renderPlanner,timetable:renderTimetable,pastpapers:renderPastPapers,insights:renderInsights,tools:renderTools,mindmap:renderMindMap,settings:renderSettings,studyspace:renderStudySpace};
    clearReveal();const c=$('#content'),y=window.scrollY;c.classList.remove('anim');
    c.innerHTML=(views[currentView]||renderHome)();hydrateIcons(c);hydrateLogos(c);c.classList.toggle('is-mindmap',currentView==='mindmap');
    if(playNext&&!splashActive){playNext=false;playEnter();}
    if(!playNext)window.scrollTo(0,y);
    if(currentView==='mindmap')mmMount();else if(MM.saveT)mmFlush();
    drawCharts();
    const moreBtn=$('#mobileMore');if(moreBtn)moreBtn.classList.toggle('active',!['home','academics','tasks','planner','studyspace'].includes(currentView));
  }
  function renderStudySpace() {
    if(!focusSubjectId && data.subjects.length) focusSubjectId=data.subjects[0].id;
    const sub=subject(focusSubjectId);
    const time=`${String(Math.floor(focusSeconds/60)).padStart(2,'0')}:${String(focusSeconds%60).padStart(2,'0')}`;
    const isBreak=focusMode!=='Focus session';
    return `<section class="study-space"><div class="focus-kicker">STUDY SPACE</div><h1>Time to focus.</h1><div class="focus-meta"><label for="focusSubject">Subject</label><select id="focusSubject">${data.subjects.map(x=>`<option value="${esc(x.id)}" ${x.id===focusSubjectId?'selected':''}>${esc(x.name)}</option>`).join('')}</select><span class="focus-dot">·</span><select id="focusMode" aria-label="Session type"><option ${!isBreak?'selected':''}>Focus session</option><option ${isBreak?'selected':''}>Break</option></select>${!isBreak?`<label for="focusDuration">Study duration in minutes</label><div class="focus-duration-wrap"><input id="focusDuration" class="focus-duration-input" type="number" inputmode="numeric" min="1" max="180" step="1" value="${focusMinutes}" aria-label="Study duration in minutes"><span>min</span></div>`:`<div class="focus-break-length" aria-live="polite">${focusBreakMinutes()} min break <small>1:3 study-to-break ratio</small></div>`}</div><div class="focus-timer-ring" id="focusTimerRing" style="--timer-progress:${Math.max(0,Math.min(100,((focusTotalSeconds()-focusSeconds)/focusTotalSeconds())*100))}%"><div class="focus-clock" id="focusClock" aria-live="off">${time}</div></div><div class="focus-state">${focusRunning?'Session in progress':isBreak?'Break timer · no study log':'Completed focus sessions are logged automatically'}</div><div class="focus-controls"><button class="button primary" data-action="focus-toggle">${focusRunning?'Pause':'Start'}</button><button class="button outline" data-action="focus-reset">Reset</button></div><p class="focus-footnote">${isBreak?`Your ${focusMinutes}-minute study session earns a ${focusBreakMinutes}-minute break.`:'Adjust your study duration; your break is automatically set to one-third.'}</p></section>`;
  }
  /* ===== StudyOS 4.3.6 · icons, study analytics helpers and chart engine ===== */
  const ICONS={
    home:'<path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
    academics:'<path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20"/>',
    tasks:'<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><path d="M22 4 12 14.01l-3-3"/>',
    planner:'<path d="M8 2v4M16 2v4M3 10h18"/><rect x="3" y="4" width="18" height="18" rx="2.5"/>',
    timetable:'<rect x="3" y="3" width="18" height="18" rx="2.5"/><path d="M3 9h18M3 15h18M9 3v18M15 3v18"/>',
    pastpapers:'<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M8 13h8M8 17h8M8 9h2"/>',
    studyspace:'<path d="M10 2h4M12 14l3-3"/><circle cx="12" cy="14" r="8"/>',
    insights:'<path d="M3 3v18h18M7 16V9M12 16V5M17 16v-4"/>',
    tools:'<path d="m12 3 1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z"/><path d="m19 15 .8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8z"/>',
    settings:'<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
    mindmap:'<circle cx="5" cy="12" r="2.6"/><circle cx="19" cy="5.5" r="2.6"/><circle cx="19" cy="18.5" r="2.6"/><path d="M7.3 10.9 16.7 6.6M7.3 13.1l9.4 4.3"/>',
    percent:'<path d="M19 5 5 19"/><circle cx="6.5" cy="6.5" r="2.5"/><circle cx="17.5" cy="17.5" r="2.5"/>',
    clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    flag:'<path d="M5 22V4M5 4h11l-2 4 2 4H5"/>',
    flame:'<path d="M12 22c4 0 7-2.8 7-7 0-3-1.6-5-3-6.5-.3 1.6-1.2 2.7-2.3 3C14 8 12.6 4.5 10 2c.2 3.3-1.5 5.2-3.2 7.2C5.5 10.700 5 12.600 5 15c0 4.200 3 7 7 7z"/>',
    plus:'<path d="M12 5v14M5 12h14"/>',
    more:'<circle cx="5" cy="12" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="19" cy="12" r="1.6"/>',
    undo:'<path d="M9 14 4 9l5-5"/><path d="M4 9h10.500a5.500 5.500 0 0 1 0 11H11"/>',
    redo:'<path d="m15 14 5-5-5-5"/><path d="M20 9H9.500a5.500 5.500 0 0 0 0 11H13"/>',
    fit:'<path d="M8 3H5a2 2 0 0 0-2 2v3M16 3h3a2 2 0 0 1 2 2v3M8 21H5a2 2 0 0 1-2-2v-3M16 21h3a2 2 0 0 0 2-2v-3"/>',
    layout:'<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="8.500" y="14" width="7" height="7" rx="1.5"/><path d="M6.500 10v2h11v-2M12 12v2"/>',
    trash:'<path d="M3 6h18M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6M10 11v6M14 11v6"/>',
    edit:'<path d="M12 20h9"/><path d="M16.500 3.500a2.100 2.100 0 0 1 3 3L7 19l-4 1 1-4z"/>',
    link:'<path d="M10 13a5 5 0 0 0 7.500.5l3-3a5 5 0 0 0-7-7l-1.700 1.700"/><path d="M14 11a5 5 0 0 0-7.500-.5l-3 3a5 5 0 0 0 7 7l1.700-1.700"/>',
    minus:'<path d="M5 12h14"/>',
    help:'<circle cx="12" cy="12" r="9"/><path d="M9.100 9a3 3 0 0 1 5.800 1c0 2-3 3-3 3M12 17h.01"/>',
    copy:'<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1"/>',
    chevron:'<path d="m9 6 6 6-6 6"/>',
    arrowUp:'<path d="M12 19V5M5 12l7-7 7 7"/>',
    arrowDown:'<path d="M12 5v14M19 12l-7 7-7-7"/>'
  };
  const icon=(name,size=18)=>`<svg class="ic" viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name]||''}</svg>`;
  const hydrateIcons=(root=document)=>$$('[data-ic]',root).forEach(el=>{if(el.dataset.icDone!==el.dataset.ic){el.innerHTML=icon(el.dataset.ic,Number(el.dataset.icSize)||22);el.dataset.icDone=el.dataset.ic;}});
  // Brand mark follows the selected accent (including custom colours) in every appearance mode.
  const LOGO_PATH='M36 35h57v13H51v13h36c10 0 16 6 16 16v7c0 10-7 16-18 16H30V87h54V74H48c-10 0-16-6-16-16v-7c0-10 6-16 16-16';
  const logoSVG=()=>`<svg class="logo-svg" viewBox="0 0 128 128" aria-hidden="true"><rect width="128" height="128" rx="34" fill="var(--logo-bg)"/><path d="${LOGO_PATH}" fill="var(--logo-fg)"/></svg>`;
  const hydrateLogos=(root=document)=>$$('[data-logo]',root).forEach(el=>{if(!el.firstElementChild)el.innerHTML=logoSVG();});
  function logoColors(h,s,dark){
    if(s===0)return dark?{bg:'#343434',fg:'#e8e8e8'}:{bg:'#e4e4e4',fg:'#474747'};
    const sat=clampN(s+12,24,92);
    // A tinted surface in light mode and a deep accent surface in dark mode;
    // the monogram uses the same hue with strong contrast.
    return dark
      ? {bg:hslHex(h,clampN(sat,28,88),24),fg:hslHex(h,clampN(sat-4,24,88),91)}
      : {bg:hslHex(h,clampN(sat+8,30,96),91),fg:hslHex(h,clampN(sat,24,92),34)};
  }
  const toneVars=(h,s,dark)=>{const out={},sat=Math.round(30+Math.min(s,60)*0.5),offs=[0,40,120,190,260,320];offs.forEach((o,i)=>{const hh=(h+o)%360;out[`--mm-t${i}-bg`]=dark?`hsl(${hh} ${sat-6}% 24%)`:`hsl(${hh} ${sat+30}% 90%)`;out[`--mm-t${i}-fg`]=dark?`hsl(${hh} 70% 90%)`:`hsl(${hh} ${sat+12}% 18%)`;out[`--mm-t${i}-ln`]=dark?`hsl(${hh} ${sat+6}% 62%)`:`hsl(${hh} ${sat+8}% 48%)`;});return out;};

  const isoOf=d=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  const atNoon=s=>new Date(`${s}T12:00:00`);
  const shiftISO=(s,n)=>{const d=atNoon(s);d.setDate(d.getDate()+n);return isoOf(d);};
  const weekStartISO=ref=>{const d=atNoon(ref||todayISO());const off=data.profile.weekStart==='Sunday'?d.getDay():(d.getDay()+6)%7;d.setDate(d.getDate()-off);return isoOf(d);};
  // A "completed" study session is one that was logged (manually or by the focus timer), not a planned revision slot, and not in the future.
  const isDoneSession=s=>!!(s&&s.date&&!s.generated&&s.date<=todayISO());
  const doneSessions=()=>data.sessions.filter(isDoneSession);
  const sumMinutes=(from,to,list)=>(list||doneSessions()).filter(s=>s.date>=from&&s.date<=to).reduce((n,s)=>n+(Number(s.minutes)||0),0);
  const countSessions=(from,to,list)=>(list||doneSessions()).filter(s=>s.date>=from&&s.date<=to).length;
  const fmtMin=m=>{m=Math.max(0,Math.round(Number(m)||0));return m>=60?`${Math.floor(m/60)}h ${m%60}m`:`${m}m`;};
  const dayLabel=(d,o={weekday:'short'})=>atNoon(d).toLocaleDateString(undefined,o);
  const longDay=d=>atNoon(d).toLocaleDateString(undefined,{weekday:'long',month:'short',day:'numeric'});
  const plural=(n,w,p)=>`${n} ${n===1?w:(p||w+'s')}`;
  function dayStats(){const m={};doneSessions().forEach(s=>{const e=m[s.date]||(m[s.date]={min:0,n:0});e.min+=Number(s.minutes)||0;e.n++;});return m;}
  function studyStreak(ds){let cur=0,d=todayISO();if(!ds[d])d=shiftISO(d,-1);while(ds[d]){cur++;d=shiftISO(d,-1);}let best=0,run=0,prev=null;Object.keys(ds).sort().forEach(k=>{run=prev&&shiftISO(prev,1)===k?run+1:1;if(run>best)best=run;prev=k;});return{cur,best};}
  const deltaChip=(a,b,suffix='')=>{if(!a&&!b)return '<span class="delta flat">No activity</span>';if(!b)return `<span class="delta up">${icon('arrowUp',12)}New</span>`;const p=Math.round((a-b)/b*100);if(p===0)return `<span class="delta flat">Same${suffix}</span>`;return `<span class="delta ${p>0?'up':'down'}">${icon(p>0?'arrowUp':'arrowDown',12)}${Math.abs(p)}%${suffix}</span>`;};

  let chartSpecs={},chartSeq=0;
  const chartBox=(spec,cls='')=>{const id='ch'+(++chartSeq);chartSpecs[id]=spec;return `<div class="chart ${cls}" data-chart="${id}" role="img" aria-label="${esc(spec.label||'Chart')}"></div>`;};
  function niceStep(max,kind){const c=kind==='min'?[5,10,15,20,30,60,120,180,240,300,600,1200]:[1,2,5,10,20,50,100,200,500];let step=c[c.length-1];for(const v of c){if(max/v<=4){step=v;break;}}return{step,top:Math.max(step,Math.ceil(max/step)*step)};}
  const axisFmt=(v,kind)=>kind==='min'?(v%60===0&&v>0?`${v/60}h`:v>=60?`${(v/60).toFixed(1)}h`:`${v}m`):String(v);
  function monoPath(p){const n=p.length;if(n<2)return '';const dx=[],m=[],t=[];for(let i=0;i<n-1;i++){dx[i]=p[i+1][0]-p[i][0];m[i]=(p[i+1][1]-p[i][1])/dx[i];}t[0]=m[0];t[n-1]=m[n-2];for(let i=1;i<n-1;i++)t[i]=m[i-1]*m[i]<=0?0:3*(dx[i-1]+dx[i])/((2*dx[i]+dx[i-1])/m[i-1]+(dx[i]+2*dx[i-1])/m[i]);let d=`M${p[0][0].toFixed(1)},${p[0][1].toFixed(1)}`;for(let i=0;i<n-1;i++){d+=`C${(p[i][0]+dx[i]/3).toFixed(1)},${(p[i][1]+t[i]*dx[i]/3).toFixed(1)} ${(p[i+1][0]-dx[i]/3).toFixed(1)},${(p[i+1][1]-t[i+1]*dx[i]/3).toFixed(1)} ${p[i+1][0].toFixed(1)},${p[i+1][1].toFixed(1)}`;}return d;}
  function gridSVG(spec,w,h,pad,top){const ih=h-pad.t-pad.b;let s='';for(let v=0;v<=top.top;v+=top.step){const y=pad.t+ih-(v/top.top)*ih;s+=`<line class="c-grid${v===0?' base':''}" x1="${pad.l}" x2="${w-pad.r}" y1="${y.toFixed(1)}" y2="${y.toFixed(1)}"/><text class="c-axis" x="${pad.l-8}" y="${(y+3.5).toFixed(1)}" text-anchor="end">${axisFmt(v,spec.kind)}</text>`;}return s;}
  function xLabels(items,slotW,pad,w,h,center=true){const minW=spec_labelW(items);const every=Math.max(1,Math.ceil(minW/slotW));let s='';items.forEach((it,i)=>{if((items.length-1-i)%every)return;const x=pad.l+slotW*i+(center?slotW/2:0);s+=`<text class="c-axis x${it.current?' cur':''}" x="${x.toFixed(1)}" y="${h-pad.b+17}" text-anchor="middle">${esc(it.label)}</text>`;});return s;}
  const spec_labelW=items=>Math.max(30,Math.max(...items.map(i=>String(i.label).length))*6.6+10);
  function drawBars(spec,w){
    const h=spec.h||190,pad={l:38,r:6,t:14,b:26},iw=w-pad.l-pad.r,ih=h-pad.t-pad.b,items=spec.items,n=items.length;
    const max=Math.max(1,...items.map(i=>i.value)),top=niceStep(max,spec.kind),slot=iw/n,bw=Math.max(4,Math.min(44,slot*0.62));
    let bars='',hits='',vals='';
    items.forEach((it,i)=>{const bh=it.value>0?Math.max(3,it.value/top.top*ih):0,x=pad.l+slot*i+(slot-bw)/2,y=pad.t+ih-bh,r=Math.min(8,bw/2,bh);
      if(bh>0)bars+=`<path class="c-bar${it.current?' cur':''}${it.future?' future':''}" style="--i:${i}${it.color?`;fill:${it.color}`:''}" d="M${x.toFixed(1)},${(y+bh).toFixed(1)}V${(y+r).toFixed(1)}Q${x.toFixed(1)},${y.toFixed(1)} ${(x+r).toFixed(1)},${y.toFixed(1)}H${(x+bw-r).toFixed(1)}Q${(x+bw).toFixed(1)},${y.toFixed(1)} ${(x+bw).toFixed(1)},${(y+r).toFixed(1)}V${(y+bh).toFixed(1)}Z"/>`;
      else if(!it.future)bars+=`<rect class="c-stub" x="${x.toFixed(1)}" y="${pad.t+ih-2}" width="${bw.toFixed(1)}" height="2" rx="1"/>`;
      if(spec.values!==false&&it.value>0&&slot>=30&&n<=16)vals+=`<text class="c-val" style="--i:${i}" x="${(x+bw/2).toFixed(1)}" y="${(y-5).toFixed(1)}" text-anchor="middle">${spec.kind==='min'?axisFmt(it.value,'min'):it.value}</text>`;
      hits+=`<g class="c-hit" data-tip="${esc(it.tip||'')}"><rect class="c-hitbox" x="${(pad.l+slot*i).toFixed(1)}" y="${pad.t}" width="${slot.toFixed(1)}" height="${ih}"/></g>`;});
    return `<svg width="${w}" height="${h}" viewBox="0 0 ${w} ${h}">${gridSVG(spec,w,h,pad,top)}${bars}${vals}${xLabels(items,slot,pad,w,h)}${hits}</svg>`;
  }
  function drawLine(spec,w,id){
    const h=spec.h||200,pad={l:38,r:12,t:14,b:26},iw=w-pad.l-pad.r,ih=h-pad.t-pad.b,items=spec.items,n=items.length;
    const max=Math.max(1,...items.map(i=>i.value)),top=niceStep(max,spec.kind),X=i=>n===1?pad.l+iw/2:pad.l+iw*i/(n-1),Y=v=>pad.t+ih-(v/top.top)*ih;
    const pts=items.map((it,i)=>[X(i),Y(it.value)]);
    const line=n>1?monoPath(pts):'',area=n>1?`${line}L${X(n-1).toFixed(1)},${(pad.t+ih).toFixed(1)}L${X(0).toFixed(1)},${(pad.t+ih).toFixed(1)}Z`:'';
    const slot=n>1?iw/(n-1):iw;let dots='',hits='';
    items.forEach((it,i)=>{if(n<=31||it.value>0&&n<=60)dots+=`<circle class="c-dot${it.value?'':' zero'}" cx="${pts[i][0].toFixed(1)}" cy="${pts[i][1].toFixed(1)}" r="${n>31?2:3}"/>`;
      hits+=`<g class="c-hit" data-tip="${esc(it.tip||'')}"><rect class="c-hitbox" x="${(pts[i][0]-slot/2).toFixed(1)}" y="${pad.t}" width="${slot.toFixed(1)}" height="${ih}"/><line class="c-guide" x1="${pts[i][0].toFixed(1)}" x2="${pts[i][0].toFixed(1)}" y1="${pad.t}" y2="${pad.t+ih}"/><circle class="c-focus" cx="${pts[i][0].toFixed(1)}" cy="${pts[i][1].toFixed(1)}" r="5.5"/></g>`;});
    let labels='';const every=Math.max(1,Math.ceil(spec_labelW(items)/(n>1?iw/(n-1):iw)));items.forEach((it,i)=>{if((n-1-i)%every)return;labels+=`<text class="c-axis x${it.current?' cur':''}" x="${pts[i][0].toFixed(1)}" y="${h-pad.b+17}" text-anchor="middle">${esc(it.label)}</text>`;});
    return `<svg width="${w}" height="${h}" viewBox="0 0 ${w} ${h}"><defs><linearGradient id="g-${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:var(--primary);stop-opacity:.28"/><stop offset="1" style="stop-color:var(--primary);stop-opacity:0"/></linearGradient></defs>${gridSVG(spec,w,h,pad,top)}${area?`<path class="c-area" d="${area}" fill="url(#g-${id})"/>`:''}${line?`<path class="c-line" pathLength="1" d="${line}"/>`:''}${dots}${labels}${hits}</svg>`;
  }
  function drawDonut(spec){
    const size=spec.size||190,R=size/2-16,cx=size/2,total=spec.items.reduce((n,i)=>n+i.value,0)||1;let off=0,arcs='';
    spec.items.forEach((it,i)=>{const len=it.value/total*100,gap=spec.items.length>1?Math.min(1.2,len*0.4):0,dash=Math.max(0,len-gap);arcs+=`<g class="c-hit" data-tip="${esc(it.tip||'')}"><circle class="c-arc" style="--da:${dash.toFixed(2)} ${(100-dash).toFixed(2)};--i:${i};stroke:${it.color}" cx="${cx}" cy="${cx}" r="${R}" pathLength="100" stroke-dasharray="${dash.toFixed(2)} ${(100-dash).toFixed(2)}" stroke-dashoffset="${(-off).toFixed(2)}" transform="rotate(-90 ${cx} ${cx})"/></g>`;off+=len;});
    return `<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}"><circle class="c-track" cx="${cx}" cy="${cx}" r="${R}"/>${arcs}<text class="c-donut-big" x="${cx}" y="${cx+2}" text-anchor="middle">${esc(spec.center?.big||'')}</text><text class="c-donut-sub" x="${cx}" y="${cx+20}" text-anchor="middle">${esc(spec.center?.small||'')}</text></svg>`;
  }
  function drawCharts(){
    $$('#content .chart[data-chart]').forEach(el=>{const spec=chartSpecs[el.dataset.chart];if(!spec)return;const w=Math.floor(el.clientWidth);if(w<40)return;if(el.dataset.w===String(w))return;const first=!el.dataset.drawn;
      el.innerHTML=spec.type==='line'?drawLine(spec,w,el.dataset.chart):spec.type==='donut'?drawDonut(spec):drawBars(spec,w);
      el.dataset.w=String(w);el.dataset.drawn='1';const svg=el.firstElementChild;if(svg&&first&&!reduceMotion())svg.classList.add('c-anim');});
  }
  let chartResizeTimer;window.addEventListener('resize',()=>{clearTimeout(chartResizeTimer);chartResizeTimer=setTimeout(drawCharts,120);});
  if(window.ResizeObserver){const ro=new ResizeObserver(()=>{clearTimeout(chartResizeTimer);chartResizeTimer=setTimeout(drawCharts,80);});const c0=document.getElementById('content');if(c0)ro.observe(c0);}
  // Shared tooltip for charts, heat-map cells and rings.
  const tipEl=document.createElement('div');tipEl.id='chartTip';tipEl.className='chart-tip';tipEl.setAttribute('role','tooltip');document.body.appendChild(tipEl);
  let tipHide;
  const showTip=(t,x,y)=>{if(!t){tipEl.classList.remove('show');return;}tipEl.innerHTML=t;tipEl.classList.add('show');const r=tipEl.getBoundingClientRect();let L=x+14,T=y-r.height-12;if(L+r.width>innerWidth-8)L=x-r.width-14;if(L<8)L=8;if(T<8)T=y+18;tipEl.style.transform=`translate(${Math.round(L)}px,${Math.round(T)}px)`;};
  document.addEventListener('pointermove',e=>{const t=e.target.closest&&e.target.closest('[data-tip]');if(t&&t.dataset.tip){clearTimeout(tipHide);showTip(t.dataset.tip,e.clientX,e.clientY);}else if(tipEl.classList.contains('show'))showTip('');});
  document.addEventListener('pointerdown',e=>{if(e.pointerType==='mouse')return;const t=e.target.closest&&e.target.closest('[data-tip]');if(t&&t.dataset.tip){showTip(t.dataset.tip,e.clientX,e.clientY);clearTimeout(tipHide);tipHide=setTimeout(()=>showTip(''),2200);}else showTip('');});
  document.addEventListener('scroll',()=>showTip(''),true);
  const tipHTML=(title,line)=>`<strong>${esc(title)}</strong><span>${esc(line)}</span>`;
  const ringSVG=(pct,label,sub,color='var(--primary)')=>{const p=Math.max(0,Math.min(100,pct||0)),R=34;return `<div class="ring-card"><svg class="ring" viewBox="0 0 84 84" width="84" height="84" role="img" aria-label="${esc(label)} ${Math.round(p)}%"><circle class="ring-track" cx="42" cy="42" r="${R}"/><circle class="ring-arc" style="--da:${p} ${100-p};stroke:${color}" cx="42" cy="42" r="${R}" pathLength="100" stroke-dasharray="${p} ${100-p}" transform="rotate(-90 42 42)"/><text x="42" y="47" text-anchor="middle" class="ring-num">${Math.round(p)}%</text></svg><div class="ring-copy"><strong>${esc(label)}</strong><small>${esc(sub)}</small></div></div>`;};

  /* Streak display: x-prefixed counter + a real flame whose colour follows the milestone (display only; studyStreak() is untouched). */
  const streakX=n=>`x${Math.max(0,Math.floor(Number(n)||0))}`;
  const hexRgb=h=>[1,3,5].map(i=>parseInt(h.slice(i,i+2),16)),rgbHex=r=>'#'+r.map(v=>Math.round(v).toString(16).padStart(2,'0')).join('');
  const mixHex=(x,y,t)=>{const A=hexRgb(x),B=hexRgb(y);return rgbHex(A.map((v,i)=>v+(B[i]-v)*t));};
  function streakTone(n){
    n=Math.floor(Number(n)||0);let c;
    if(n<=0)c='#9aa0a6';
    else if(n<7)c='#f6c90e';                                                    /* 1–6 yellow */
    else if(n<16)c=mixHex('#f7b52c','#f39a1f',(n-7)/8);                         /* 7–15 slight orange */
    else if(n<30)c=mixHex('#f39a1f','#ee6a14',(n-16)/13);                       /* 16–29 orange, deepening */
    else if(n<60)c='#e53935';                                                   /* 30 red */
    else if(n<100)c='#b3201f';                                                  /* 60 deeper red */
    else if(n<200)c='#2f80ed';                                                  /* 100 blue */
    else if(n<300)c='#8e44ec';                                                  /* 200 purple */
    else if(n<400)c='#2eb872';                                                  /* 300 green */
    else c='#ffffff';                                                           /* 400+ white */
    return {c,core:n>=400?'#cfd8e3':mixHex(c,'#ffffff',.55),white:n>=400};
  }
  const streakStyle=n=>{const t=streakTone(n);return `--flame:${t.c};--flame-core:${t.core}`;};
  function streakFlame(n,size=26){
    const t=streakTone(n);
    return `<svg class="flame${t.white?' flame-white':''}" viewBox="0 0 24 24" width="${size}" height="${size}" aria-hidden="true" focusable="false" style="${streakStyle(n)}"><path class="flame-body" d="M12 2.2c.5 3.1-1 4.9-2.6 6.8C7.8 10.9 6 13 6 16c0 3.3 2.7 6 6 6s6-2.7 6-6c0-2.6-1.2-4.3-2.4-5.8-.5 1.1-1.200 1.800-2.100 2.200.6-3.500-.1-7.600-1.500-10.200z"/><path class="flame-core" d="M12 21.600c-2 0-3.500-1.500-3.500-3.500 0-1.600.9-2.600 1.800-3.700.5-.6 1-1.200 1.300-2 .3 1 .9 1.700 1.500 2.400.8.900 1.400 1.800 1.400 3.300 0 2-1.500 3.500-3.500 3.500z"/></svg>`;
  }
  function renderHome() {
    chartSpecs={};
    const today=todayISO(),ws=weekStartISO(),prevWs=shiftISO(ws,-7),prevToday=shiftISO(today,-7);
    const avg=totalAverage(), pending=activeTasks(), overdue=pending.filter(t=>daysUntil(t.due)<0), dueToday=pending.filter(t=>t.due===today), upcoming=sortedTasks(pending).slice(0,4);
    const exams=[...data.exams].sort((a,b)=>a.date.localeCompare(b.date)).filter(e=>daysUntil(e.date)>=0).slice(0,3);
    const subjects=[...data.subjects].sort((a,b)=>(gradeFor(b)??-1)-(gradeFor(a)??-1));
    const done=doneSessions(),ds=dayStats(),streak=studyStreak(ds);
    const weekMin=sumMinutes(ws,shiftISO(ws,6),done),weekN=countSessions(ws,shiftISO(ws,6),done),prevMin=sumMinutes(prevWs,prevToday,done);
    const goal=Number(data.profile.weeklyGoal)||0,goalPct=goal>0?Math.min(100,weekMin/goal*100):0;
    const hr=new Date().getHours(),greet=hr<12?'morning':hr<18?'afternoon':'evening';
    const first=esc((data.profile.name||'Student').split(' ')[0]);
    const AN=analyticsBlocks();
    const bits=[];
    if(overdue.length)bits.push(`${plural(overdue.length,'task')} overdue`);
    if(dueToday.length)bits.push(`${plural(dueToday.length,'task')} due today`);
    if(exams[0])bits.push(`${esc(exams[0].title)} ${daysUntil(exams[0].date)===0?'is today':daysUntil(exams[0].date)===1?'is tomorrow':`in ${daysUntil(exams[0].date)} days`}`);
    const summary=bits.length?bits.join(' · '):'You are all caught up. A short focus session keeps the momentum going.';
    const weekDays=Array.from({length:7},(_,i)=>shiftISO(ws,i));
    const weekItems=weekDays.map(d=>{const e=ds[d]||{min:0,n:0};return{label:dayLabel(d),value:d>today?0:e.min,current:d===today,future:d>today,tip:tipHTML(longDay(d),d>today?'Upcoming':e.n?`${fmtMin(e.min)} · ${plural(e.n,'session')}`:'No study logged')};});
    const hasWeek=weekMin>0;
    const deltaTxt=prevMin===0&&weekMin===0?'No sessions logged yet this week':prevMin===0?'First study time since last week':weekMin===prevMin?'Same as this point last week':`${weekMin>prevMin?'▲':'▼'} ${fmtMin(Math.abs(weekMin-prevMin))} ${weekMin>prevMin?'more':'less'} than this point last week`;
    return `<section class="dash-hero"><div class="dash-hero-copy"><div class="eyebrow">${esc(new Date().toLocaleDateString(undefined,{weekday:'long',month:'long',day:'numeric'}))}</div><h1>Good ${greet}, ${first}</h1><p>${summary}</p></div><div class="dash-hero-actions"><button class="button primary" data-view="studyspace">${icon('studyspace',16)} Start focus</button>${button(`${icon('plus',16)} Add new`,'quick-add','tonal')}</div></section>
      <div class="grid stats-grid dash-stats">
        <div class="stat-card"><div class="stat-top">Current average <span class="stat-icon">${icon('percent',17)}</span></div><div class="stat-value">${avg===null?'—':Math.round(avg*10)/10+'%'}</div><div class="stat-foot">Across subjects with grades</div></div>
        <div class="stat-card"><div class="stat-top">Active tasks <span class="stat-icon">${icon('tasks',17)}</span></div><div class="stat-value">${pending.length}</div><div class="stat-foot ${overdue.length?'':'good'}">${overdue.length?`${overdue.length} overdue`:`${dueToday.length} due today`}</div></div>
        <div class="stat-card"><div class="stat-top">Upcoming exams <span class="stat-icon">${icon('planner',17)}</span></div><div class="stat-value">${data.exams.filter(e=>daysUntil(e.date)>=0).length}</div><div class="stat-foot">${exams[0]?`Next: ${esc(exams[0].title)} in ${daysUntil(exams[0].date)}d`:'No exams scheduled'}</div></div>
        <div class="stat-card"><div class="stat-top">Study time this week <span class="stat-icon">${icon('clock',17)}</span></div><div class="stat-value" data-plain>${fmtMin(weekMin)}</div><div class="stat-foot">${weekMin>prevMin&&prevMin>0||weekMin>0&&prevMin===0?'<span class="good">'+deltaTxt+'</span>':deltaTxt}</div></div>
      </div>
      <div class="dash-stack">
        ${AN.daily}
        ${AN.consistency}
        <div class="dash-row dash-row-main">
<section class="panel week-panel"><div class="panel-header"><div><h2>This week</h2><p>${plural(weekN,'completed session')} · ${fmtMin(weekMin)} studied</p></div><button class="panel-link" data-view="insights">Full insights ↗</button></div>
          ${hasWeek?chartBox({type:'bars',kind:'min',h:176,items:weekItems,label:'Study minutes per day this week'}):`<div class="week-empty">${chartBox({type:'bars',kind:'min',h:150,items:weekItems,values:false,label:'No study logged this week'})}<p>Nothing logged yet this week. Finish a focus session or log one manually and it will show up here.</p></div>`}
          ${goal>0?`<div class="goal-line"><div class="goal-line-head"><span>Weekly goal</span><strong>${fmtMin(weekMin)} <small>of ${fmtMin(goal)}</small></strong></div><div class="progress-track"><div class="progress-fill" style="width:${goalPct}%"></div></div></div>`:''}
        </section>
<section class="panel streak-panel"><div class="panel-header"><div><h2>Study streak</h2><p>Consecutive days with a completed session</p></div></div>
          <div class="streak-main" style="${streakStyle(streak.cur)}"><span class="streak-flame ${streak.cur?'on':''}">${streakFlame(streak.cur,36)}</span><div><strong class="streak-num">${streakX(streak.cur)}</strong><small>${streak.cur?`${streak.cur===1?'day':'days'} in a row · ${streak.best>streak.cur?`Longest: ${streakX(streak.best)}`:'Your longest run so far'}`:(streak.best>0?`Log a session to start a new one · Longest: ${streakX(streak.best)}`:'Log a session to start one')}</small></div></div>
          <div class="streak-dots">${weekDays.map(d=>{const e=ds[d];return `<div class="streak-dot ${e?'on':''} ${d===today?'today':''} ${d>today?'future':''}" data-tip="${esc(tipHTML(longDay(d),d>today?'Upcoming':e?`${fmtMin(e.min)} · ${plural(e.n,'session')}`:'No study logged'))}"><i></i><span>${esc(dayLabel(d,{weekday:'narrow'}))}</span></div>`;}).join('')}</div>
        </section>
        </div>
        <div class="dash-row dash-row-half">
<section class="panel"><div class="panel-header"><div><h2>Priority tasks</h2><p>Keep your next steps in sight</p></div><button class="panel-link" data-view="tasks">All tasks ↗</button></div>
          ${upcoming.length?`<div class="task-list">${upcoming.map(t=>`<div class="task-row"><button class="task-check ${t.status==='Submitted'?'checked':''}" data-action="cycle-task" data-id="${t.id}" aria-label="Update ${esc(t.title)}">${t.status==='Submitted'?'✓':''}</button><div class="task-main"><div class="task-title">${esc(t.title)}</div><div class="task-meta">${esc(subjectName(t.subjectId))} · ${t.estimate?`${t.estimate} min`:'Time not set'}</div></div>${duePill(t)}</div>`).join('')}</div>`:emptyState('✓','All caught up','Add a task when new work comes in.',button('Add a task','add-task','tonal'))}
        </section>
<section class="panel"><div class="panel-header"><div><h2>Upcoming exams</h2><p>A little preparation goes a long way</p></div><button class="panel-link" data-view="planner">Planner ↗</button></div>
          ${exams.length?`<div class="exam-list">${exams.map(e=>{const d=daysUntil(e.date);return `<div class="exam-row"><div class="date-tile"><strong>${new Date(`${e.date}T12:00:00`).getDate()}</strong><small>${monthShort(e.date)}</small></div><div class="exam-main"><strong>${esc(e.title)}</strong><small>${esc(subjectName(e.subjectId))}${e.time?' · '+esc(e.time):''}</small></div><div class="countdown">${d===0?'Today':d===1?'Tomorrow':`${d} days`}</div></div>`}).join('')}</div>`:emptyState('▦','No exams yet','Add an exam to start a revision plan.',button('Add exam','add-exam','tonal'))}
        </section>
        </div>
        <div class="dash-row dash-row-half">
<section class="panel"><div class="panel-header"><div><h2>Subject performance</h2><p>Your current standing by subject</p></div><button class="panel-link" data-view="academics">View gradebook ↗</button></div>
          ${subjects.length?`<div class="subject-list">${subjects.slice(0,5).map(s=>{const g=gradeFor(s);return `<div class="subject-row"><div class="subject-icon" style="background:${esc(s.color)}20;color:${esc(s.color)}">${esc((s.code||s.name).slice(0,2))}</div><div><div class="subject-name">${esc(s.name)}</div><div class="subject-sub">Target ${s.target??data.profile.target??90}%</div><div class="progress-track"><div class="progress-fill" style="width:${Math.max(0,Math.min(100,g||0))}%;background:${esc(s.color)}"></div></div></div><div class="subject-grade">${g===null?'—':Math.round(g)+'%'}<small>${g===null?'No grades':g>=(s.target||90)?'On target':'Below target'}</small></div></div>`}).join('')}</div>`:emptyState('▤','No subjects yet','Add your subjects to start tracking grades.',button('Add a subject','add-subject','tonal'))}
        </section>
<section class="panel"><div class="panel-header"><div><h2>Quick actions</h2><p>Capture it before you forget</p></div></div><div class="grid quick-grid">${button('＋ Assignment','add-task','tonal')}${button('＋ Record grade','add-assessment','outline')}${button('＋ Exam','add-exam','outline')}${button('◷ Study session','add-session','outline')}</div></section>
        </div>
        <div class="inline-note"><strong>Heads up:</strong> StudyOS stores your records locally on this device. Export a backup in Settings regularly.</div>
      </div>`;
  }
  function renderAcademics() {
    const avg=totalAverage();
    const tabs=`<div class="toolbar"><button class="button ${academicTab==='subjects'?'tonal':'outline'} small" data-action="academic-tab" data-tab="subjects">Subjects</button><button class="button ${academicTab==='grades'?'tonal':'outline'} small" data-action="academic-tab" data-tab="grades">Assessments & grades</button><button class="button ${academicTab==='schemes'?'tonal':'outline'} small" data-action="academic-tab" data-tab="schemes">Grade settings</button><button class="button ${academicTab==='mastery'?'tonal':'outline'} small" data-action="academic-tab" data-tab="mastery">Syllabus mastery</button></div>`;
    let body='';
    if(academicTab==='subjects') body=`<div class="grid subject-grid">${data.subjects.map(s=>{const g=gradeFor(s), count=data.assessments.filter(a=>a.subjectId===s.id).length;return `<article class="subject-card"><div class="subject-card-top"><div class="subject-icon" style="background:${esc(s.color)}20;color:${esc(s.color)}">${esc((s.code||s.name).slice(0,2))}</div><div><h3>${esc(s.name)}</h3><p>${count} assessment${count===1?'':'s'} recorded</p></div></div><div class="muted" style="font-size:10px">Current grade</div><div class="subject-card-grade">${g===null?'—':Math.round(g*10)/10+'%'}</div><div class="progress-track"><div class="progress-fill" style="width:${g||0}%;background:${esc(s.color)}"></div></div><div class="subject-card-foot"><span>Target: ${s.target??90}%</span><span>${g===null?'Add grades':g>=(s.target??90)?'On target':'Target gap '+Math.max(0,Math.round((s.target??90)-g))+'%'}</span></div><div class="card-actions"><button class="button tonal small" data-action="add-assessment" data-subject="${s.id}">＋ Add grade</button><button class="button outline small" data-action="edit-subject" data-id="${s.id}">Edit</button><button class="button text small" data-action="subject-details" data-id="${s.id}">Details</button></div></article>`}).join('')}${button('＋ Add subject','add-subject','outline')}</div>`;
    if(academicTab==='grades') body=`<div class="toolbar"><div class="search-box"><input id="assessmentSearch" placeholder="Search assessments…" aria-label="Search assessments"></div><button class="button primary" data-action="add-assessment">＋ Record grade</button></div><div class="table-wrap"><table class="data-table"><thead><tr><th>Assessment</th><th>Subject</th><th>Category</th><th>Score</th><th>Date</th><th></th></tr></thead><tbody>${data.assessments.length?data.assessments.slice().sort((a,b)=>(b.date||'').localeCompare(a.date||'')).map(a=>`<tr data-assessment-row><td><div class="table-primary">${esc(a.title)}</div></td><td>${esc(subjectName(a.subjectId))}</td><td>${esc(a.category||'Uncategorized')}</td><td><strong>${esc(a.score)}/${esc(a.maxScore)}</strong><div class="table-secondary">${scorePct(a)===null?'Invalid score':Math.round(scorePct(a)*10)/10+'%'}</div></td><td>${esc(fmtDate(a.date))}</td><td><div class="row-actions"><button class="mini-action" data-action="edit-assessment" data-id="${a.id}">Edit</button><button class="mini-action" data-action="delete-assessment" data-id="${a.id}">×</button></div></td></tr>`).join(''):`<tr><td colspan="6">${emptyState('％','No assessments recorded','Add your first assessment to calculate a grade.',button('Record grade','add-assessment','tonal'))}</td></tr>`}</tbody></table></div><div class="inline-note" style="margin-top:14px"><strong>Calculation note:</strong> Current grades use category weights normalized across categories with graded assessments. Categories without grades are not treated as zero. Configure your categories before relying on projected final grades.</div>`;
    if(academicTab==='schemes') body=`<div class="panel"><div class="panel-header"><div><h2>Grading configuration</h2><p>Weights are applied within each subject.</p></div></div>${data.subjects.length?data.subjects.map(s=>`<div class="settings-row" style="padding:15px 0;border-bottom:1px solid var(--line)"><div style="display:flex;align-items:center;justify-content:space-between;gap:12px"><div><strong style="font-size:12px">${esc(s.name)}</strong><div class="muted" style="font-size:10px;margin-top:3px">${(s.categories||[]).map(c=>`${esc(c.name)} ${Number(c.weight)}%`).join(' · ')||'Unweighted average'}</div></div><button class="button outline small" data-action="edit-scheme" data-id="${s.id}">Configure</button></div></div>`).join(''):`${emptyState('▤','Add a subject first','Grade settings are configured per subject.',button('Add subject','add-subject','tonal'))}`}<div class="inline-note" style="margin-top:15px">Category weights should normally total 100%. The app normalizes the current grade over categories that have scored assessments, so unassessed categories do not silently count as zero.</div></div>`;
    if(academicTab==='mastery') { const statuses=['Not started','Learning','Practising','Mastered']; body=`<section class="panel"><div class="panel-header"><div><h2>Syllabus mastery</h2><p>Track topics and focus on what needs more practice. All progress is stored locally.</p></div><button class="button primary small" data-action="add-topic">＋ Add topic</button></div><div class="toolbar"><select id="masterySubjectFilter" class="select-control"><option value="all">All subjects</option>${data.subjects.map(s=>`<option value="${s.id}">${esc(s.name)}</option>`).join('')}</select></div>${data.topics.length?`<div class="table-wrap"><table class="data-table"><thead><tr><th>Topic</th><th>Subject</th><th>Difficulty</th><th>Mastery</th><th></th></tr></thead><tbody>${data.topics.map(t=>`<tr data-topic-row data-subject="${t.subjectId}"><td><div class="table-primary">${esc(t.title)}</div></td><td>${esc(subjectName(t.subjectId))}</td><td>${esc(t.difficulty||'Medium')}</td><td><select class="select-control mastery-status" data-topic-status="${t.id}">${statuses.map(st=>`<option ${t.status===st?'selected':''}>${st}</option>`).join('')}</select></td><td><button class="mini-action" data-action="delete-topic" data-id="${t.id}">Remove</button></td></tr>`).join('')}</tbody></table></div>`:emptyState('◎','No syllabus topics yet','Add topics from your subjects and update their mastery as you revise.',button('＋ Add topic','add-topic','tonal'))}<div class="inline-note" style="margin-top:14px">Mastered topics are not assumed to be permanently learned. Use practice results to revisit them when needed.</div></section>`; }
    return `${heading('ACADEMIC RECORD','Academics','Manage subjects, assessments, and the rules behind your grades.',button('＋ Add subject','add-subject'))}<div class="grid stats-grid"><div class="stat-card"><div class="stat-top">Overall current average <span class="stat-icon">％</span></div><div class="stat-value">${avg===null?'—':Math.round(avg*10)/10+'%'}</div><div class="stat-foot">Mean of subjects with recorded grades</div></div><div class="stat-card"><div class="stat-top">Subjects <span class="stat-icon">▤</span></div><div class="stat-value">${data.subjects.length}</div><div class="stat-foot">In your current workspace</div></div><div class="stat-card"><div class="stat-top">Assessments <span class="stat-icon">✓</span></div><div class="stat-value">${data.assessments.length}</div><div class="stat-foot">Recorded marks</div></div><div class="stat-card"><div class="stat-top">Targets met <span class="stat-icon">◎</span></div><div class="stat-value">${data.subjects.filter(s=>gradeFor(s)!==null&&gradeFor(s)>=(s.target??90)).length}<span style="font-size:14px;color:var(--muted)">/${data.subjects.length}</span></div><div class="stat-foot">Subjects at or above target</div></div></div>${tabs}${body}`;
  }
  function renderTasks() {
    const tasks=sortedTasks(data.tasks.filter(t=>{const ok=taskFilter==='All'||(taskFilter==='Active'?!['Submitted','Graded','Cancelled'].includes(t.status):taskFilter==='Overdue'?daysUntil(t.due)<0&&!['Submitted','Graded','Cancelled'].includes(t.status):t.status===taskFilter);const q=taskSearch.toLowerCase();return ok&&(!q||`${t.title} ${subjectName(t.subjectId)} ${t.description||''}`.toLowerCase().includes(q));}));
    const filters=['All','Active','Not started','In progress','Submitted','Graded','Overdue'];
    return `${heading('STAY ON TOP OF IT','Tasks & assignments','Every deadline, in one place. Break big tasks into manageable steps.',button('＋ New assignment','add-task'))}<div class="grid stats-grid"><div class="stat-card"><div class="stat-top">Active <span class="stat-icon">✓</span></div><div class="stat-value">${activeTasks().length}</div><div class="stat-foot">Not yet submitted</div></div><div class="stat-card"><div class="stat-top">Due today <span class="stat-icon">◷</span></div><div class="stat-value">${activeTasks().filter(t=>t.due===todayISO()).length}</div><div class="stat-foot">Needs attention today</div></div><div class="stat-card"><div class="stat-top">Overdue <span class="stat-icon">!</span></div><div class="stat-value">${activeTasks().filter(t=>daysUntil(t.due)<0).length}</div><div class="stat-foot">Not automatically marked zero</div></div><div class="stat-card"><div class="stat-top">Submitted / graded <span class="stat-icon">✓</span></div><div class="stat-value">${data.tasks.filter(t=>['Submitted','Graded'].includes(t.status)).length}</div><div class="stat-foot">Completed workflow items</div></div></div><div class="toolbar"><div class="search-box"><input id="taskSearch" value="${esc(taskSearch)}" placeholder="Search tasks or subjects…" aria-label="Search tasks"></div><select id="taskFilter" class="select-control" aria-label="Filter tasks">${filters.map(f=>`<option ${taskFilter===f?'selected':''}>${f}</option>`).join('')}</select></div><div class="panel" style="padding:8px 20px"><div class="task-list">${tasks.length?tasks.map(t=>`<div class="task-row"><button class="task-check ${['Submitted','Graded'].includes(t.status)?'checked':''}" data-action="cycle-task" data-id="${t.id}" aria-label="Update ${esc(t.title)}">${['Submitted','Graded'].includes(t.status)?'✓':''}</button><div class="task-main"><div class="task-title">${esc(t.title)}</div><div class="task-meta">${esc(subjectName(t.subjectId))} · ${t.estimate?`${t.estimate} min estimated`:'No time estimate'} ${t.description?'· '+esc(t.description):''}</div><div class="tag-row" style="margin-top:7px">${statusPill(t.status)}<span class="priority-pill ${(t.priority||'Medium').toLowerCase()}">${esc(t.priority||'Medium')} priority</span></div></div><div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;justify-content:flex-end">${duePill(t)}<button class="mini-action" data-action="edit-task" data-id="${t.id}">Edit</button><button class="mini-action" data-action="delete-task" data-id="${t.id}">×</button></div></div>`).join(''):emptyState('✓',taskSearch?'No matching tasks':'Nothing in this view',taskSearch?'Try another search.':'Add a task or choose a different filter.',button('＋ Add assignment','add-task','tonal'))}</div></div>`;
  }
  const TYPE_META={exam:{label:'Exam',edit:'edit-exam',del:'delete-exam',order:0},task:{label:'Task',edit:'edit-task',del:'delete-task',order:1},study:{label:'Study',edit:'edit-session',del:'delete-session',order:2}};
  function plannerItems(){
    const list=[];
    data.exams.forEach(e=>{if(e&&e.date)list.push({id:e.id,type:'exam',title:e.title||'Exam',date:e.date,subjectId:e.subjectId,time:e.time||''});});
    data.tasks.forEach(t=>{if(t&&t.due&&t.status!=='Cancelled')list.push({id:t.id,type:'task',title:t.title||'Assignment',date:t.due,subjectId:t.subjectId,done:['Submitted','Graded'].includes(t.status)});});
    data.sessions.forEach(s=>{if(s&&s.date)list.push({id:s.id,type:'study',title:s.title||`Study: ${subjectName(s.subjectId)}`,date:s.date,subjectId:s.subjectId,minutes:Number(s.minutes)||0,generated:!!s.generated});});
    return list.sort((a,b)=>a.date.localeCompare(b.date)||TYPE_META[a.type].order-TYPE_META[b.type].order);
  }
  let timetableEditing=false;
  function timetableDayIndex(iso){const d=new Date(`${iso}T12:00:00`).getDay();return d===0||d===6?-1:(d+6)%7;}
  function timetableForDate(iso){const di=timetableDayIndex(iso);if(di<0)return [];return data.schoolTimetable.slots.map(slot=>({time:slot.time,subject:String(slot.subjects[di]||'').replace(/^—$/,'')})).filter(x=>x.subject);}
  function renderTimetable(){
    const days=data.schoolTimetable.days,slots=data.schoolTimetable.slots,cell=v=>v==='—'?'':String(v||'');
    const editBtn=slots.length?`<button type="button" class="button ${timetableEditing?'primary':'outline'}" data-action="toggle-timetable-edit">${timetableEditing?'✓ Finish editing':'✎ Edit timetable'}</button>`:'';
    if(!slots.length){
      return `${heading('WEEKLY SCHEDULE','Timetable','Your lessons for each weekday.','')}
      <section class="panel timetable-panel timetable-empty"><p><strong>Your timetable is empty.</strong></p><p class="inline-note">Add a period, then type your lessons into the grid.</p><button type="button" class="button primary" data-action="timetable-add-period">Add a period</button></section>`;
    }
    return `${heading('WEEKLY SCHEDULE','Timetable','Your lessons for each weekday.',editBtn)}
    <section class="panel timetable-panel"><div class="table-wrap timetable-wrap"><table class="data-table timetable-table"><thead><tr><th>Time</th>${days.map(d=>`<th>${d}</th>`).join('')}${timetableEditing?'<th class="tt-actions"><span class="sr-only">Remove</span></th>':''}</tr></thead><tbody>
    ${slots.map((slot,si)=>`<tr class="${slot.subjects.every(x=>x==='Break')?'timetable-break':''}"><th>${timetableEditing?`<input class="timetable-time-input" aria-label="Period ${si+1} time" data-timetable-time="${si}" value="${esc(slot.time)}" maxlength="24" placeholder="9:00–10:00">`:esc(slot.time)}</th>${slot.subjects.map((sub,di)=>`<td>${timetableEditing?`<input class="timetable-cell-input" aria-label="${days[di]} ${esc(slot.time)}" data-timetable-slot="${si}" data-timetable-day="${di}" value="${esc(cell(sub))}" maxlength="32">`:`<span class="timetable-subject ${sub==='Break'?'is-break':''}">${esc(cell(sub))}</span>`}</td>`).join('')}${timetableEditing?`<td class="tt-actions"><button type="button" class="icon-button tt-remove" data-action="timetable-remove-period" data-id="${si}" aria-label="Remove period ${si+1}">✕</button></td>`:''}</tr>`).join('')}
    </tbody></table></div>${timetableEditing?'<button type="button" class="button tonal tt-add" data-action="timetable-add-period">+ Add a period</button>':''}<p class="inline-note">${timetableEditing?'Type directly in the grid. Changes are saved automatically.':'Each weekday’s lessons also appear in your Planner.'}</p></section>`;
  }
  function renderPlanner() {
    const first=new Date(selectedYear,selectedMonth,1),startOffset=(first.getDay()+(data.profile.weekStart==='Monday'?6:0))%7,daysInMonth=new Date(selectedYear,selectedMonth+1,0).getDate(),prevDays=new Date(selectedYear,selectedMonth,0).getDate();
    const items=plannerItems(),byDate={};items.forEach(i=>(byDate[i.date]=byDate[i.date]||[]).push(i));
    const weekdays=data.profile.weekStart==='Monday'?['Mon','Tue','Wed','Thu','Fri','Sat','Sun']:['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
    const today=todayISO();let calendar='';
    for(let i=0;i<42;i++){
      let n=i-startOffset+1,mo=selectedMonth,yr=selectedYear,other=false;
      if(n<1){n=prevDays+n;mo=selectedMonth-1;other=true;if(mo<0){mo=11;yr--;}}else if(n>daysInMonth){n-=daysInMonth;mo=selectedMonth+1;other=true;if(mo>11){mo=0;yr++;}}
      const iso=`${yr}-${String(mo+1).padStart(2,'0')}-${String(n).padStart(2,'0')}`,list=byDate[iso]||[];
      calendar+=`<button type="button" class="calendar-day ${other?'other':''} ${iso===today?'today':''} ${iso===selectedDay?'selected':''}" data-action="select-day" data-date="${iso}" aria-pressed="${iso===selectedDay}" aria-label="${esc(fmtLong(iso))}, ${list.length} item${list.length===1?'':'s'}"><span class="day-num">${n}</span><span class="cal-chips">${list.slice(0,1).map(x=>`<span class="cal-chip ${x.type} ${x.done?'done':''}">${esc(x.title)}</span>`).join('')}${list.length>1?`<span class="cal-more">+${list.length-1} more</span>`:''}</span><span class="cal-dots">${list.slice(0,4).map(x=>`<i class="${x.type}"></i>`).join('')}</span></button>`;
    }
    const monthLabel=new Date(selectedYear,selectedMonth,1).toLocaleDateString(undefined,{month:'long',year:'numeric'});
    const dayItems=byDate[selectedDay]||[];
    const upcoming=items.filter(e=>e.date>=today&&!e.done).slice(0,8);
    const sessions=data.sessions.slice().sort((a,b)=>(b.date||'').localeCompare(a.date||''));
    const generatedCount=data.sessions.filter(s=>s.generated).length;
    const dayPanel=`<section class="panel day-panel"><div class="panel-header"><div><h2>${esc(fmtLong(selectedDay))}</h2><p>${dayItems.length?`${dayItems.length} item${dayItems.length===1?'':'s'} on this day`:'Nothing scheduled yet'}</p></div></div>${timetableForDate(selectedDay).length?`<div class="school-day-schedule"><div class="school-day-heading"><strong>School timetable</strong><span>${timetableForDate(selectedDay).filter(x=>x.subject!=='Break').length} lessons</span></div><div class="school-day-lessons">${timetableForDate(selectedDay).map(x=>`<div class="school-day-lesson ${x.subject==='Break'?'is-break':''}"><span>${esc(x.time)}</span><strong>${esc(x.subject)}</strong></div>`).join('')}</div></div>`:''}${dayItems.length?`<div class="day-list">${dayItems.map(i=>{const m=TYPE_META[i.type];return `<div class="day-item"><span class="type-dot ${i.type}"></span><div class="day-item-main"><strong class="${i.done?'is-done':''}">${esc(i.title)}</strong><small>${m.label} · ${esc(subjectName(i.subjectId))}${i.time?` · ${esc(i.time)}`:''}${i.minutes?` · ${i.minutes} min`:''}${i.generated?' · Revision plan':''}</small></div><div class="row-actions"><button type="button" class="mini-action" data-action="${m.edit}" data-id="${esc(i.id)}">Edit</button><button type="button" class="mini-action danger-action" data-action="${m.del}" data-id="${esc(i.id)}" aria-label="Delete ${esc(i.title)}">Delete</button></div></div>`;}).join('')}</div>`:`<div class="muted day-empty">Add something to this day with the buttons below.</div>`}<div class="day-add"><button type="button" class="button tonal small" data-action="add-task" data-date="${selectedDay}">＋ Task</button><button type="button" class="button tonal small" data-action="add-exam" data-date="${selectedDay}">＋ Exam</button><button type="button" class="button tonal small" data-action="add-session" data-date="${selectedDay}">◷ Log study</button></div></section>`;
    return `${heading('PLAN WITH PURPOSE','Planner','See what is coming, then give your study time a plan.',button('＋ Add exam','add-exam'))}<div class="grid planner-grid"><section class="panel calendar-panel"><div class="calendar-head"><h2>${monthLabel}</h2><div class="calendar-nav"><button type="button" class="icon-button small" data-action="month-prev" aria-label="Previous month">‹</button><button type="button" class="button outline small" data-action="month-today">Today</button><button type="button" class="icon-button small" data-action="month-next" aria-label="Next month">›</button></div></div><div class="calendar-grid">${weekdays.map(d=>`<div class="calendar-weekday">${d}</div>`).join('')}${calendar}</div><div class="tag-row" style="margin-top:15px"><span class="tag"><i class="legend exam"></i>Exams</span><span class="tag"><i class="legend task"></i>Assignments</span><span class="tag"><i class="legend study"></i>Study logs</span></div></section><div>${dayPanel}<section class="panel"><div class="panel-header"><div><h2>Coming up</h2><p>Tap an item to jump to its day</p></div></div>${upcoming.length?`<div class="agenda-list">${upcoming.map(e=>`<button type="button" class="agenda-item agenda-link" data-action="select-day" data-date="${e.date}"><div class="agenda-time">${esc(fmtDate(e.date,{month:'short',day:'numeric'}))}</div><div><strong>${esc(e.title)}</strong><small>${TYPE_META[e.type].label} · ${esc(subjectName(e.subjectId))}</small></div></button>`).join('')}</div>`:emptyState('▦','Nothing scheduled','Add an exam, task, or study session.')}</section><section class="panel"><div class="panel-header"><div><h2>Study sessions</h2><p>Log focused time</p></div></div><button type="button" class="button primary" data-action="add-session" style="width:100%">◷ Log study session</button>${sessions.length?`<div class="divider"></div><div class="session-history-head"><strong>Study log (${sessions.length})</strong><small>Edit or delete any log below.</small></div><div class="session-history">${sessions.map(s=>`<div class="agenda-item session-history-item"><div class="agenda-time">${esc(fmtDate(s.date,{month:'short',day:'numeric',year:'numeric'}))}</div><div class="session-history-main"><strong>${esc(s.title||subjectName(s.subjectId))}</strong><small>${esc(subjectName(s.subjectId))} · ${Number(s.minutes)||0} minutes${s.generated?' · Revision plan':''}</small></div><div class="row-actions"><button type="button" class="mini-action" data-action="edit-session" data-id="${esc(s.id)}">Edit</button><button type="button" class="mini-action danger-action" data-action="delete-session" data-id="${esc(s.id)}" aria-label="Delete study log ${esc(s.title||subjectName(s.subjectId))}">Delete</button></div></div>`).join('')}</div><div class="session-clear">${generatedCount?`<button type="button" class="button outline small" data-action="clear-generated">Remove revision plan (${generatedCount})</button>`:''}<button type="button" class="button danger small" data-action="clear-logs">Clear all logs</button></div>`:''}</section><section class="panel"><div class="panel-header"><div><h2>Smart revision planner</h2><p>Generate local study sessions from exam dates, topics, and subject performance.</p></div></div><div class="field"><label for="revisionMinutes">Session length</label><select id="revisionMinutes" class="select-control"><option value="25">25 minutes</option><option value="40" selected>40 minutes</option><option value="60">60 minutes</option></select></div><div class="field"><label for="revisionDays">Plan window</label><select id="revisionDays" class="select-control"><option value="7">Next 7 days</option><option value="14" selected>Next 14 days</option><option value="30">Next 30 days</option></select></div><button type="button" class="button primary" data-action="generate-revision" style="width:100%">✦ Generate revision plan</button><div class="inline-note" style="margin-top:12px">Suggestions are editable after creation. Existing sessions are preserved; matching generated sessions are not duplicated.</div></section></div></div>`;
  }
  function renderPastPapers() {
    const papers=[...data.pastPapers].sort((a,b)=>(b.date||'').localeCompare(a.date||''));
    const scored=papers.filter(p=>Number.isFinite(Number(p.score))&&Number(p.maxScore)>0&&p.score!==''&&p.score!==null);
    const avg=scored.length?scored.reduce((n,p)=>n+(Number(p.score)/Number(p.maxScore))*100,0)/scored.length:null;
    const totalMinutes=papers.reduce((n,p)=>n+(Number(p.minutes)||0),0);
    const editing=pastPaperEditingId?data.pastPapers.find(p=>p.id===pastPaperEditingId):null;
    const subjectOptions=data.subjects.map(x=>`<option value="${esc(x.id)}" ${editing?.subjectId===x.id?'selected':''}>${esc(x.name)}</option>`).join('');
    return `${heading('PRACTICE WITH PURPOSE','Past Papers','Track attempts, marks, timing, and the topics that need another pass.',`<span class="tag">${papers.length} attempts</span>`)}
      <div class="grid stats-grid past-paper-stats"><div class="stat-card"><div class="stat-top">Papers attempted</div><div class="stat-value">${papers.length}</div><div class="stat-foot">All recorded attempts</div></div><div class="stat-card"><div class="stat-top">Average score</div><div class="stat-value">${avg===null?'—':Math.round(avg*10)/10+'%'}</div><div class="stat-foot">Across attempts with marks</div></div><div class="stat-card"><div class="stat-top">Practice time</div><div class="stat-value">${Math.floor(totalMinutes/60)}h ${totalMinutes%60}m</div><div class="stat-foot">Time recorded on papers</div></div></div>
      <section class="panel past-paper-form-panel"><div class="panel-header"><div><h2>${editing?'Edit attempt':'Record a past paper'}</h2><p>Keep practice results separate from official grades.</p></div></div>
        <form id="pastPaperForm"><input type="hidden" name="id" value="${editing?esc(editing.id):''}">
          <div class="field-row"><div class="field"><label for="ppTitle">Paper title</label><input id="ppTitle" name="title" required maxlength="100" placeholder="e.g. Mathematics Paper 2" value="${esc(editing?.title||'')}"></div><div class="field"><label for="ppSubject">Subject</label><select id="ppSubject" name="subjectId" required>${subjectOptions || '<option value="">Add a subject first</option>'}</select></div></div>
          <div class="field-row"><div class="field"><label for="ppBoard">Exam board</label><input id="ppBoard" name="board" maxlength="60" placeholder="e.g. Cambridge / Edexcel" value="${esc(editing?.board||'')}"></div><div class="field"><label for="ppQualification">Qualification</label><input id="ppQualification" name="qualification" maxlength="50" placeholder="e.g. IGCSE / O Level" value="${esc(editing?.qualification||'')}"></div></div>
          <div class="field-row"><div class="field"><label for="ppYear">Paper year</label><input id="ppYear" name="year" inputmode="numeric" maxlength="4" placeholder="2025" value="${esc(editing?.year||'')}"></div><div class="field"><label for="ppSession">Session</label><select id="ppSession" name="session"><option ${!editing?.session?'selected':''} value="">Select session</option>${['March','May/June','October/November','Specimen','Other'].map(x=>`<option ${editing?.session===x?'selected':''}>${x}</option>`).join('')}</select></div><div class="field"><label for="ppCode">Paper code</label><input id="ppCode" name="paperCode" maxlength="30" placeholder="0580/22" value="${esc(editing?.paperCode||'')}"></div></div>
          <div class="field-row"><div class="field"><label for="ppDate">Attempt date</label><input id="ppDate" name="date" type="date" value="${esc(editing?.date||todayISO())}" required></div><div class="field"><label for="ppMinutes">Time taken (minutes)</label><input id="ppMinutes" name="minutes" type="number" min="0" max="1000" value="${editing?.minutes??''}" placeholder="90"></div></div>
          <div class="field-row"><div class="field"><label for="ppScore">Score (optional)</label><input id="ppScore" name="score" type="number" min="0" step="any" value="${editing?.score??''}" placeholder="e.g. 72"></div><div class="field"><label for="ppMax">Maximum marks</label><input id="ppMax" name="maxScore" type="number" min="1" step="any" value="${editing?.maxScore??80}" required></div><div class="field"><label for="ppDifficulty">Difficulty</label><select id="ppDifficulty" name="difficulty">${['Easy','Moderate','Hard','Very hard'].map(x=>`<option ${editing?.difficulty===x?'selected':''}>${x}</option>`).join('')}</select></div></div>
          <div class="field"><label for="ppTopics">Topics to revisit</label><input id="ppTopics" name="topics" maxlength="240" placeholder="e.g. quadratic graphs, vectors" value="${esc(editing?.topics||'')}"></div>
          <div class="field"><label for="ppReflection">Reflection / mistakes</label><textarea id="ppReflection" name="reflection" rows="2" maxlength="1200" placeholder="What went well? What should you practise next?">${esc(editing?.reflection||'')}</textarea></div>
          <div class="toolbar"><button class="button primary" type="submit">${editing?'Save changes':'Save attempt'}</button>${editing?'<button class="button outline" type="button" data-action="cancel-edit-paper">Cancel</button>':''}</div>
        </form>
      </section>
      <section class="panel"><div class="panel-header"><div><h2>Attempt history</h2><p>Your practice record, newest first.</p></div><div class="field" style="margin:0;min-width:160px"><select id="paperSubjectFilter" aria-label="Filter by subject"><option value="all">All subjects</option>${data.subjects.map(x=>`<option value="${esc(x.id)}">${esc(x.name)}</option>`).join('')}</select></div></div>
      ${papers.length?`<div class="past-paper-list">${papers.map((p,pi)=>{const valid=p.score!==''&&p.score!==null&&Number(p.maxScore)>0&&Number.isFinite(Number(p.score)),score=valid?Number(p.score)/Number(p.maxScore)*100:null;return `<article class="past-paper-row" data-paper-row data-subject="${esc(p.subjectId)}" style="--paper-i:${Math.min(pi,12)}"><div class="paper-icon">▤</div><div class="paper-main"><strong>${esc(p.title)}</strong><small>${esc(subjectName(p.subjectId))} · ${esc([p.board,p.qualification,p.year,p.session,p.paperCode].filter(Boolean).join(' · ')||'Paper details not specified')}</small><small>${esc(fmtDate(p.date,{month:'short',day:'numeric',year:'numeric'}))}${p.minutes?` · ${Number(p.minutes)} min`:''} · ${esc(p.difficulty||'Moderate')}</small>${p.topics?`<div class="paper-topics">Revisit: ${esc(p.topics)}</div>`:''}${p.reflection?`<details class="paper-reflection"><summary>Review reflection</summary><p>${esc(p.reflection)}</p></details>`:''}</div><div class="paper-score">${score===null?'<strong>—</strong><small>Not scored</small>':`<strong>${Math.round(score*10)/10}%</strong><small>${Number(p.score)} / ${Number(p.maxScore)}</small>`}<div class="row-actions"><button type="button" class="mini-action" data-action="edit-past-paper" data-id="${esc(p.id)}">Edit</button><button type="button" class="mini-action danger-action" data-action="delete-past-paper" data-id="${esc(p.id)}">Delete</button></div></div></article>`;}).join('')}</div>`:emptyState('▤','No past papers yet','Record your first attempt to start tracking marks, timing, and weak topics.')}</section>`;
  }
  function renderTools() {
    const graded=data.subjects.map(s=>({s,g:gradeFor(s)})).filter(x=>x.g!==null);
    const avg=average(graded.map(x=>x.g));
    const weak=[...graded].sort((a,b)=>a.g-b.g).slice(0,3);
    const upcoming=[...data.exams].filter(e=>e.date>=todayISO()).sort((a,b)=>a.date.localeCompare(b.date));
    const dueCards=data.flashcards.filter(c=>!c.nextReview||c.nextReview<=todayISO());
    const search=esc($('#toolSearch')?.value||'');
    const bytes=new Blob([JSON.stringify(data)]).size;
    const recommendations=[];
    weak.forEach(({s,g})=>recommendations.push({title:`Prioritize ${s.name}`,detail:`Current grade ${g.toFixed(1)}% is below your ${s.target??90}% target. Review a weak topic and complete a timed practice set.`}));
    const overdue=activeTasks().filter(t=>t.due&&daysUntil(t.due)<0);
    if(overdue.length)recommendations.push({title:'Clear overdue work',detail:`${overdue.length} active assignment${overdue.length===1?' is':'s are'} overdue. Resolve or reschedule these before adding more work.`});
    const nextExam=upcoming[0];
    if(nextExam)recommendations.push({title:`Prepare for ${nextExam.title}`,detail:`${daysUntil(nextExam.date)} day${daysUntil(nextExam.date)===1?'':'s'} remain. Use the exam topic list to generate short revision sessions.`});
    const unmastered=data.topics.filter(t=>t.status!=='Mastered');
    if(unmastered.length)recommendations.push({title:'Build topic mastery',detail:`${unmastered.length} syllabus topic${unmastered.length===1?'':'s'} are not marked mastered. Focus on the hardest topic first.`});
    if(!data.sessions.some(x=>x.date>=addDays(-6)&&x.date<=todayISO()))recommendations.push({title:'Start a study log',detail:'No sessions are recorded in the last seven days. Use Study Space or log a session to make your study rhythm visible.'});
    const integrity=[['Subjects',data.subjects.length],['Assessments',data.assessments.length],['Tasks',data.tasks.length],['Exams',data.exams.length],['Study logs',data.sessions.length],['Past papers',data.pastPapers.length],['Mistakes',data.mistakes.length],['Flashcards',data.flashcards.length],['Formulas',data.formulas.length],['Mind maps',data.mindMaps.length]];
    const mmThumb=mp=>{if(!mp.nodes.length)return '';let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;mp.nodes.forEach(n=>{x0=Math.min(x0,n.x);x1=Math.max(x1,n.x);y0=Math.min(y0,n.y);y1=Math.max(y1,n.y);});const w=Math.max(1,x1-x0),h=Math.max(1,y1-y0),s=Math.min(128/w,56/h,1),ox=(150-w*s)/2-x0*s,oy=(76-h*s)/2-y0*s,P=n=>[n.x*s+ox,n.y*s+oy],ix=mmIndex(mp);let ln='',dt='';mp.nodes.forEach(n=>{const p=P(n);if(n.parent&&ix.byId.get(n.parent)){const q=P(ix.byId.get(n.parent));ln+=`<line x1="${q[0].toFixed(1)}" y1="${q[1].toFixed(1)}" x2="${p[0].toFixed(1)}" y2="${p[1].toFixed(1)}" style="stroke:var(--mm-t${ix.tone[n.id]}-ln)"/>`;}dt+=`<rect x="${(p[0]-(n.parent?7:11)).toFixed(1)}" y="${(p[1]-3.5).toFixed(1)}" width="${n.parent?14:22}" height="7" rx="3.5" style="fill:${n.parent?`var(--mm-t${ix.tone[n.id]}-ln)`:'var(--primary)'}"/>`;});return `<svg viewBox="0 0 150 76" aria-hidden="true">${ln}${dt}</svg>`;};
    const mmPanel=`<section class="panel mm-tools-panel"><div class="panel-header"><div><h2>Mind Maps</h2><p>Plan essays, map chapters and connect ideas on an infinite canvas.</p></div><button type="button" class="button tonal small" data-mm="new">${icon('plus',15)} New map</button></div>${data.mindMaps.length?`<div class="mm-cards">${[...data.mindMaps].sort((a,b)=>(b.updated||0)-(a.updated||0)).map(mp=>`<button type="button" class="mm-card" data-view="mindmap" data-map-id="${esc(mp.id)}"><span class="mm-card-thumb">${mmThumb(mp)}</span><strong>${esc(mp.title)}</strong><small>${plural(mp.nodes.length,'node')} · ${esc(new Date(mp.updated||Date.now()).toLocaleDateString(undefined,{month:'short',day:'numeric'}))}</small></button>`).join('')}</div>`:`<div class="mm-tools-empty"><span class="mm-tools-icon">${icon('mindmap',26)}</span><div><strong>No mind maps yet</strong><small>Start one from scratch or from a subject’s syllabus topics.</small></div><button type="button" class="button primary small" data-mm="new">Create a map</button></div>`}</section>`;
    return `${heading('YOUR ACADEMIC CONTROL ROOM','StudyOS Tools','Performance, revision, knowledge capture, and data management — stored on this device.',button('＋ Add mistake','add-mistake'))}
      <section class="panel"><div class="panel-header"><div><h2>Command Center</h2><p>Search your workspace and jump straight to an action.</p></div></div><div class="field"><label for="toolSearch">Search StudyOS</label><input id="toolSearch" placeholder="Search subjects, tasks, exams, formulas, mistakes…" value="${search}"></div><div id="toolSearchResults" class="tool-results">${renderToolSearch(search)}</div><div class="toolbar"><button class="button tonal" data-view="studyspace">Start Study Space</button><button class="button outline" data-view="mindmap">Open Mind Map</button><button class="button outline" data-view="planner">Open planner</button><button class="button outline" data-action="quick-add">Quick add</button></div></section>
      ${mmPanel}
      <div class="grid stats-grid"><div class="stat-card"><div class="stat-top">Academic average</div><div class="stat-value">${avg===null?'—':avg.toFixed(1)+'%'}</div><div class="stat-foot">Official gradebook only</div></div><div class="stat-card"><div class="stat-top">Weak-topic queue</div><div class="stat-value">${data.topics.filter(t=>t.status!=='Mastered').length}</div><div class="stat-foot">Topics not yet mastered</div></div><div class="stat-card"><div class="stat-top">Cards due</div><div class="stat-value">${dueCards.length}</div><div class="stat-foot">Ready for spaced review</div></div><div class="stat-card"><div class="stat-top">Exam countdowns</div><div class="stat-value">${upcoming.length}</div><div class="stat-foot">Upcoming scheduled exams</div></div></div>
      <section class="panel"><div class="panel-header"><div><h2>StudyOS Insights</h2><p>Recommendations generated from your saved academic records — no remote AI or cloud processing.</p></div></div>${recommendations.length?`<div class="tool-list">${recommendations.slice(0,6).map(r=>`<article class="tool-item"><div><strong>${esc(r.title)}</strong><p>${esc(r.detail)}</p></div></article>`).join('')}</div>`:emptyState('✧','Your workspace looks on track','Keep recording assessments, sessions, and topic mastery to improve these insights.')}</section>
      <div class="grid insights-grid">
      <section class="panel"><div class="panel-header"><div><h2>Academic Performance Center</h2><p>Official assessment history, target gaps, and trends.</p></div><button class="panel-link" data-view="insights">Full insights ↗</button></div>${graded.length?`<div class="subject-list">${graded.map(({s,g})=>{const history=data.assessments.filter(a=>a.subjectId===s.id).sort((a,b)=>(a.date||'').localeCompare(b.date||''));const first=history[0],last=history.at(-1);const delta=first&&last&&history.length>1?(last.score/last.maxScore-first.score/first.maxScore)*100:null;return `<div class="subject-row"><div class="subject-icon" style="background:${esc(s.color)}20;color:${esc(s.color)}">${esc((s.code||s.name).slice(0,2))}</div><div><div class="subject-name">${esc(s.name)}</div><div class="subject-sub">${history.length} assessments · Target ${s.target??90}% · ${delta===null?'Trend unavailable':`${delta>=0?'+':''}${delta.toFixed(1)} percentage points since first recorded mark`}</div><div class="progress-track"><div class="progress-fill" style="width:${Math.max(0,Math.min(100,g))}%"></div></div></div><div class="subject-grade">${g.toFixed(1)}%</div></div>`}).join('')}</div>`:emptyState('％','No grade history yet','Record assessments in Academics to populate performance analytics.',button('Open gradebook','subject-details','tonal'))}<div class="inline-note">Trend compares the first and latest recorded assessment for each subject; it is descriptive, not a prediction.</div></section>
      <section class="panel"><div class="panel-header"><div><h2>Examination Center</h2><p>Countdowns, syllabus coverage, and revision readiness.</p></div><button class="panel-link" data-view="planner">Planner ↗</button></div>${upcoming.length?upcoming.map(e=>{const d=daysUntil(e.date),parts=(e.topics||'').split(/[,;\n]+/).map(x=>x.trim()).filter(Boolean),topicRows=parts.map(t=>data.topics.find(x=>x.subjectId===e.subjectId&&x.title.toLowerCase()===t.toLowerCase())),mastered=topicRows.filter(t=>t?.status==='Mastered').length;return `<div class="exam-row"><div class="date-tile"><strong>${d}</strong><small>DAYS</small></div><div class="exam-main"><strong>${esc(e.title)}</strong><small>${esc(subjectName(e.subjectId))} · ${fmtDate(e.date)} ${e.time?`· ${esc(e.time)}`:''}</small><div class="subject-sub">${parts.length?`${mastered}/${parts.length} listed topics marked mastered`:'Add exam topics to track syllabus readiness'}</div></div><button class="mini-action" data-action="edit-exam" data-id="${esc(e.id)}">Edit</button></div>`}).join(''):emptyState('▦','No upcoming exams','Add exams with topic lists to use the examination center.',button('Add exam','add-exam','tonal'))}<div class="toolbar"><button class="button tonal" data-action="generate-revision">Generate revision sessions</button></div></section>
      <section class="panel"><div class="panel-header"><div><h2>Mistake Bank</h2><p>Capture what went wrong and revisit it deliberately.</p></div><button class="button primary small" data-action="add-mistake">＋ Add mistake</button></div>${data.mistakes.length?`<div class="tool-list">${data.mistakes.slice().sort((a,b)=>(b.createdAt||'').localeCompare(a.createdAt||'')).map(m=>`<article class="tool-item"><div><strong>${esc(m.title)}</strong><div class="subject-sub">${esc(subjectName(m.subjectId))} · ${esc(m.topic||'General')} · ${esc(m.status||'Review')}</div><p>${esc(m.reason||'No error reason recorded.')}</p><details><summary>View correction</summary><p><strong>My answer:</strong> ${esc(m.wrong||'Not recorded')}</p><p><strong>Correct approach:</strong> ${esc(m.correct||'Not recorded')}</p></details></div><button class="mini-action danger-action" data-action="delete-mistake" data-id="${esc(m.id)}">Delete</button></article>`).join('')}</div>`:emptyState('↺','No mistakes captured','Add a question you got wrong, why it happened, and the correct method.')}</section>
      <section class="panel"><div class="panel-header"><div><h2>Flashcard Studio</h2><p>Spaced repetition with due dates and self-rated recall.</p></div><button class="button primary small" data-action="add-flashcard">＋ Create card</button></div>${dueCards.length?dueCards.slice(0,5).map(c=>`<article class="tool-item"><div><strong>${esc(c.front)}</strong><div class="subject-sub">${esc(subjectName(c.subjectId))} · ${esc(c.deck||'General deck')}</div><details><summary>Reveal answer</summary><p>${esc(c.back)}</p><div class="toolbar"><button class="button tonal small" data-action="review-card" data-id="${esc(c.id)}" data-rating="again">Again</button><button class="button tonal small" data-action="review-card" data-id="${esc(c.id)}" data-rating="hard">Hard</button><button class="button primary small" data-action="review-card" data-id="${esc(c.id)}" data-rating="good">Good</button></div></details></div><span class="tag">Due ${esc(c.nextReview||'today')}</span></article>`).join(''):emptyState('▤','No cards due','Create flashcards; reviewed cards will be scheduled for later.')}${data.flashcards.length?`<div class="inline-note">${data.flashcards.length} cards in your library · ${data.flashcards.filter(c=>c.nextReview>todayISO()).length} scheduled for later</div>`:''}</section>
      <section class="panel"><div class="panel-header"><div><h2>Formula Library</h2><p>Searchable personal reference for equations and definitions.</p></div><button class="button primary small" data-action="add-formula">＋ Add formula</button></div>${BUILTIN_FORMULAS.map(f=>`<article class="tool-item"><div><strong>${esc(f.title)}</strong><div class="subject-sub">Built-in · ${esc(f.subject)} · ${esc(f.topic)}</div><div class="formula-expression">${esc(f.expression)}</div><p>${esc(f.notes)}</p></div></article>`).join('')}${data.formulas.length?`<div class="tool-list">${data.formulas.map(f=>`<article class="tool-item"><div><strong>${esc(f.title)}</strong><div class="subject-sub">${esc(subjectName(f.subjectId))} · ${esc(f.topic||'Reference')}</div><div class="formula-expression">${esc(f.expression)}</div><p>${esc(f.notes||'')}</p></div><button class="mini-action danger-action" data-action="delete-formula" data-id="${esc(f.id)}">Delete</button></article>`).join('')}</div>`:emptyState('∑','No custom formulas yet','Built-in reference formulas are listed above. Add your own equations and notes here.')}</section>
      <section class="panel"><div class="panel-header"><div><h2>Smart Revision Scheduler</h2><p>Build local study sessions from upcoming exams and unmastered topics.</p></div></div><div class="field-row"><div class="field"><label for="revisionDays">Planning window (days)</label><input id="revisionDays" type="number" min="1" max="30" value="14"></div><div class="field"><label for="revisionMinutes">Session length (minutes)</label><input id="revisionMinutes" type="number" min="15" max="120" value="40"></div></div><div class="inline-note">Suggestions use exam dates, topic lists, topic mastery, and current subject performance. Generated sessions are saved to Planner; inspect and edit them before relying on the schedule.</div><button class="button primary" data-action="generate-revision">Generate suggested sessions</button><button class="button outline" data-view="planner">Review planner</button></section>
      <section class="panel"><div class="panel-header"><div><h2>Backup & Data Management</h2><p>All records stay in this browser profile. Export before clearing browser data.</p></div></div><div class="grid stats-grid">${integrity.map(([k,v])=>`<div class="stat-card"><div class="stat-top">${k}</div><div class="stat-value">${v}</div></div>`).join('')}</div><div class="inline-note">Approximate serialized data size: ${(bytes/1024).toFixed(1)} KB. This is a size estimate, not a browser quota measurement.</div><div class="toolbar"><button class="button primary" data-action="export-data">Export full backup</button><button class="button outline" data-action="import-data">Restore backup</button><button class="button outline" data-action="validate-data">Check data integrity</button><input id="importFile" type="file" accept="application/json,.json" hidden></div><p class="hint">A backup includes your profile, grades, papers, flashcards, mistakes, formulas, and planner data. Keep a copy outside this device.</p></section></div>`;
  }
  function renderToolSearch(q) {
    if(!q.trim())return '<div class="hint">Search results will appear here as you type.</div>';
    const n=q.toLowerCase(),items=[];
    const add=(type,title,sub,view='tools')=>items.push(`<button class="tool-search-result" data-view="${view}"><strong>${esc(title)}</strong><small>${esc(type)} · ${esc(sub)}</small></button>`);
    data.subjects.filter(x=>x.name.toLowerCase().includes(n)).forEach(x=>add('Subject',x.name,'Open Academics','academics'));
    data.tasks.filter(x=>x.title.toLowerCase().includes(n)).forEach(x=>add('Assignment',x.title,subjectName(x.subjectId),'tasks'));
    data.exams.filter(x=>x.title.toLowerCase().includes(n)).forEach(x=>add('Exam',x.title,fmtDate(x.date),'planner'));
    data.mindMaps.filter(x=>x.title.toLowerCase().includes(n)||x.nodes.some(nd=>nd.text.toLowerCase().includes(n))).forEach(x=>add('Mind map',x.title,plural(x.nodes.length,'node'),'mindmap'));
    BUILTIN_FORMULAS.filter(x=>(x.title+' '+x.expression+' '+x.topic+' '+x.subject).toLowerCase().includes(n)).forEach(x=>add('Built-in formula',x.title,x.expression));
    data.formulas.filter(x=>(x.title+' '+x.expression+' '+x.topic).toLowerCase().includes(n)).forEach(x=>add('Custom formula',x.title,x.expression));
    data.mistakes.filter(x=>(x.title+' '+x.topic).toLowerCase().includes(n)).forEach(x=>add('Mistake',x.title,x.topic));
    return items.length?items.slice(0,12).join(''):'<div class="hint">No matching records found.</div>';
  }
  function openToolForm(type) {
    const sub=subjectOptions('');
    if(type==='mistake')modal('Add to Mistake Bank','Save the error and the correct reasoning.',`<div class="field"><label>Question / title *</label><input name="title" required maxlength="160"></div><div class="field"><label>Subject</label><select name="subjectId">${sub}</select></div><div class="field"><label>Topic</label><input name="topic" maxlength="100"></div><div class="field"><label>My incorrect answer</label><textarea name="wrong" maxlength="2000"></textarea></div><div class="field"><label>Correct answer / method *</label><textarea name="correct" required maxlength="3000"></textarea></div><div class="field"><label>Why did I get it wrong?</label><textarea name="reason" maxlength="1000"></textarea></div>`,'Save mistake','mistakeForm');
    if(type==='flashcard')modal('Create flashcard','Write one prompt and one answer. Review scheduling starts after your first rating.',`<div class="field"><label>Front / question *</label><textarea name="front" required maxlength="1000"></textarea></div><div class="field"><label>Back / answer *</label><textarea name="back" required maxlength="2000"></textarea></div><div class="field"><label>Subject</label><select name="subjectId">${sub}</select></div><div class="field"><label>Deck / chapter</label><input name="deck" maxlength="100"></div>`,'Create card','flashcardForm');
    if(type==='formula')modal('Add formula','Save an equation with its topic and variable notes.',`<div class="field"><label>Formula name *</label><input name="title" required maxlength="120" placeholder="e.g. Speed"></div><div class="field"><label>Subject</label><select name="subjectId">${sub}</select></div><div class="field"><label>Topic</label><input name="topic" maxlength="100"></div><div class="field"><label>Expression *</label><textarea name="expression" required maxlength="500" placeholder="speed = distance / time"></textarea></div><div class="field"><label>Notes / variable meanings</label><textarea name="notes" maxlength="1000"></textarea></div>`,'Save formula','formulaForm');
  }
  let insightRange=30;
  /* Daily study duration + Consistency & productivity. Moved from Insights to Home (one instance each, not duplicated). */
  function analyticsBlocks() {
    const today=todayISO(),ws=weekStartISO(),doneAll=doneSessions(),ds=dayStats(),streak=studyStreak(ds);
    const R=insightRange,from=shiftISO(today,-(R-1)),inRange=doneAll.filter(s=>s.date>=from&&s.date<=today);
    const rangeMin=inRange.reduce((n,s)=>n+(Number(s.minutes)||0),0),activeDays=Object.keys(ds).filter(d=>d>=from&&d<=today).length;
    const dailyItems=Array.from({length:R},(_,i)=>{const d=shiftISO(from,i),e=ds[d]||{min:0,n:0};return{label:R<=7?dayLabel(d):dayLabel(d,{month:'short',day:'numeric'}),value:e.min,current:d===today,tip:tipHTML(longDay(d),e.n?`${fmtMin(e.min)} · ${plural(e.n,'session')}`:'No study logged')};});
    const best=dailyItems.reduce((a,b)=>b.value>a.value?b:a,{value:0});
    // Heat map (12 weeks)
    const hmWeeks=12,hmStart=shiftISO(ws,-7*(hmWeeks-1)),hmMax=Math.max(1,...Object.entries(ds).filter(([d])=>d>=hmStart).map(([,e])=>e.min));
    let heat='';for(let c=0;c<hmWeeks;c++)for(let r=0;r<7;r++){const d=shiftISO(hmStart,c*7+r),e=ds[d],lv=d>today?-1:!e?0:Math.min(4,Math.max(1,Math.ceil(e.min/hmMax*4)));heat+=`<i class="hm-cell lv${lv<0?'x':lv}${d===today?' today':''}"${lv<0?'':` data-tip="${esc(tipHTML(longDay(d),e?`${fmtMin(e.min)} · ${plural(e.n,'session')}`:'No study logged'))}"`}></i>`;}
    const rangeBtns=[7,30,90].map(n=>`<button type="button" class="seg-btn ${R===n?'on':''}" data-action="insight-range" data-range="${n}" aria-pressed="${R===n}">${n===7?'7 days':n===30?'30 days':'90 days'}</button>`).join('');
    const emptyStudy=emptyState('◷','No completed sessions in this period','Finish a focus session in Study Space or log one manually and the chart will fill in.',button('Log a session','add-session','tonal'));
    const hasRange=inRange.length>0;
    const daily=`<section class="panel chart-card wide"><div class="panel-header"><div><h2>Daily study duration</h2><p>Minutes per day over the last ${R} days</p></div><div class="dsd-side"><div class="seg" role="group" aria-label="Time range">${rangeBtns}</div><div class="tag-row"><span class="tag">Total ${fmtMin(rangeMin)}</span><span class="tag">Avg/day ${fmtMin(rangeMin/R)}</span>${best.value?`<span class="tag">Best ${fmtMin(best.value)}</span>`:''}</div></div></div>${hasRange?chartBox({type:'line',kind:'min',h:220,items:dailyItems,label:`Minutes studied per day, last ${R} days`}):emptyStudy}</section>`;
    const consistency=`<section class="panel chart-card wide"><div class="panel-header"><div><h2>Consistency &amp; productivity</h2><p>Your study rhythm over the last 12 weeks</p></div></div>
          <div class="cons-grid"><div class="cons-tiles"><div class="cons-tile"><span>Current streak</span><strong class="cons-streak" style="${streakStyle(streak.cur)}">${streakFlame(streak.cur,18)}${streakX(streak.cur)}</strong></div><div class="cons-tile"><span>Longest streak</span><strong>${streakX(streak.best)}</strong></div><div class="cons-tile"><span>Active days · ${R}d</span><strong>${activeDays}<small>/${R}</small></strong></div><div class="cons-tile"><span>Avg session</span><strong>${inRange.length?fmtMin(rangeMin/inRange.length):'—'}</strong></div></div>
          <div class="heat-wrap"><div class="heat" style="--cols:${hmWeeks}">${heat}</div><div class="heat-legend"><span>Less</span><i class="hm-cell lv0"></i><i class="hm-cell lv1"></i><i class="hm-cell lv2"></i><i class="hm-cell lv3"></i><i class="hm-cell lv4"></i><span>More</span></div></div></div></section>`;
    return {daily,consistency};
  }
  function renderInsights() {
    chartSpecs={};
    const today=todayISO(),ws=weekStartISO(),we=shiftISO(ws,6),prevWs=shiftISO(ws,-7),prevToday=shiftISO(today,-7);
    const grades=data.subjects.map(s=>({name:s.name,g:gradeFor(s),target:s.target??90,color:s.color}));
    const scored=grades.filter(s=>s.g!==null), avg=average(scored.map(s=>s.g));
    const doneAll=doneSessions(),ds=dayStats(),streak=studyStreak(ds);
    const weekN=countSessions(ws,we,doneAll),weekMin=sumMinutes(ws,we,doneAll),prevN=countSessions(prevWs,prevToday,doneAll),prevMin=sumMinutes(prevWs,prevToday,doneAll);
    const doneTasks=data.tasks.filter(t=>['Submitted','Graded'].includes(t.status)).length;
    const complete=data.tasks.length?Math.round(doneTasks/data.tasks.length*100):0;
    const R=insightRange,from=shiftISO(today,-(R-1)),inRange=doneAll.filter(s=>s.date>=from&&s.date<=today);
    const rangeMin=inRange.reduce((n,s)=>n+(Number(s.minutes)||0),0),activeDays=Object.keys(ds).filter(d=>d>=from&&d<=today).length;
    const goal=Number(data.profile.weeklyGoal)||0;
    const targetsMet=scored.filter(s=>s.g>=s.target).length;
    const mastered=data.topics.filter(t=>t.status==='Mastered').length;
    // Weekly activity (current week)
    const weekDays=Array.from({length:7},(_,i)=>shiftISO(ws,i));
    const weekItems=weekDays.map(d=>{const e=ds[d]||{min:0,n:0};return{label:dayLabel(d),value:d>today?0:e.min,current:d===today,future:d>today,tip:tipHTML(longDay(d),d>today?'Upcoming':e.n?`${fmtMin(e.min)} · ${plural(e.n,'session')}`:'No study logged')};});
    // Daily study duration over the selected range
    const dailyItems=Array.from({length:R},(_,i)=>{const d=shiftISO(from,i),e=ds[d]||{min:0,n:0};return{label:R<=7?dayLabel(d):dayLabel(d,{month:'short',day:'numeric'}),value:e.min,current:d===today,tip:tipHTML(longDay(d),e.n?`${fmtMin(e.min)} · ${plural(e.n,'session')}`:'No study logged')};});

    // Weekly series (last 8 weeks) for frequency + productivity trend
    const weeks=Array.from({length:8},(_,i)=>{const s=shiftISO(ws,-7*(7-i)),e=shiftISO(s,6),min=sumMinutes(s,e,doneAll),n=countSessions(s,e,doneAll),days=Object.keys(ds).filter(d=>d>=s&&d<=e).length;const lab=dayLabel(s,{month:'short',day:'numeric'});return{s,min,n,days,label:lab,current:i===7,tip:tipHTML(`Week of ${lab}`,`${plural(n,'session')} · ${fmtMin(min)} · ${plural(days,'active day')}`)};});
    const freqItems=weeks.map(w=>({label:w.label,value:w.n,current:w.current,tip:w.tip}));
    const trendItems=weeks.map(w=>({label:w.label,value:w.min,current:w.current,tip:w.tip}));
    const last4=weeks.slice(4).reduce((n,w)=>n+w.min,0),prev4=weeks.slice(0,4).reduce((n,w)=>n+w.min,0);
    const hasWeeks=weeks.some(w=>w.n>0),hasRange=inRange.length>0;
    // Subject distribution
    const bySub={};inRange.forEach(s=>{const k=s.subjectId||'';bySub[k]=(bySub[k]||0)+(Number(s.minutes)||0);});
    const dist=Object.entries(bySub).map(([id,min])=>({id,min,name:id?subjectName(id):'Unassigned',color:id?subjectColor(id):'#8a8292'})).sort((a,b)=>b.min-a.min);
    dist.forEach(d=>{d.pct=rangeMin?Math.round(d.min/rangeMin*100):0;d.tip=tipHTML(d.name,`${fmtMin(d.min)} · ${d.pct}% of study time`);});
    // Month comparison (same elapsed days)
    const td=atNoon(today),mStart=isoOf(new Date(td.getFullYear(),td.getMonth(),1)),pmStartD=new Date(td.getFullYear(),td.getMonth()-1,1),pmStart=isoOf(pmStartD),pmLen=new Date(td.getFullYear(),td.getMonth(),0).getDate(),pmEnd=isoOf(new Date(pmStartD.getFullYear(),pmStartD.getMonth(),Math.min(td.getDate(),pmLen)));
    const mMin=sumMinutes(mStart,today,doneAll),pmMin=sumMinutes(pmStart,pmEnd,doneAll),mN=countSessions(mStart,today,doneAll),pmN=countSessions(pmStart,pmEnd,doneAll);
    const mDays=Object.keys(ds).filter(d=>d>=mStart&&d<=today).length,pmDays=Object.keys(ds).filter(d=>d>=pmStart&&d<=pmEnd).length;
    const prevDays=Object.keys(ds).filter(d=>d>=prevWs&&d<=prevToday).length,thisDays=Object.keys(ds).filter(d=>d>=ws&&d<=today).length;
    const cmp=(label,a,b,fmt)=>{const m=Math.max(a,b,1);return `<div class="cmp-row"><div class="cmp-label">${label}</div><div class="cmp-bars"><div class="cmp-bar"><div class="cmp-track"><span style="width:${a/m*100}%"></span></div><b>${fmt(a)}</b></div><div class="cmp-bar prev"><div class="cmp-track"><span style="width:${b/m*100}%"></span></div><b>${fmt(b)}</b></div></div><div class="cmp-delta">${deltaChip(a,b)}</div></div>`;};
    const rangeBtns=[7,30,90].map(n=>`<button type="button" class="seg-btn ${R===n?'on':''}" data-action="insight-range" data-range="${n}" aria-pressed="${R===n}">${n===7?'7 days':n===30?'30 days':'90 days'}</button>`).join('');
    const max=Math.max(100,...scored.map(s=>s.g||0));
    const emptyStudy=emptyState('◷','No completed sessions in this period','Finish a focus session in Study Space or log one manually and the chart will fill in.',button('Log a session','add-session','tonal'));
    return `${heading('MAKE PROGRESS VISIBLE','Insights','Understand your results and study habits. Every chart is drawn from your own records.',`<div class="seg" role="group" aria-label="Time range">${rangeBtns}</div>`)}
      <div class="grid stats-grid"><div class="stat-card"><div class="stat-top">Current average <span class="stat-icon">${icon('percent',17)}</span></div><div class="stat-value">${avg===null?'—':Math.round(avg*10)/10+'%'}</div><div class="stat-foot">Mean across graded subjects</div></div><div class="stat-card"><div class="stat-top">Targets met <span class="stat-icon">${icon('flag',17)}</span></div><div class="stat-value">${targetsMet}/${data.subjects.length}</div><div class="stat-foot">Subjects at target or higher</div></div><div class="stat-card"><div class="stat-top">Study sessions this week <span class="stat-icon">${icon('clock',17)}</span></div><div class="stat-value">${weekN}</div><div class="stat-foot">${weekN?`${fmtMin(weekMin)} across completed sessions`:'No completed sessions yet this week'}</div></div><div class="stat-card"><div class="stat-top">Tasks completed <span class="stat-icon">${icon('tasks',17)}</span></div><div class="stat-value">${complete}%</div><div class="stat-foot">Submitted or graded across all tasks</div></div></div>
      <div class="grid insights-grid">
        <section class="panel chart-card"><div class="panel-header"><div><h2>Weekly study activity</h2><p>Minutes studied each day this week</p></div><span class="tag">${fmtMin(weekMin)}</span></div>${weekMin>0?chartBox({type:'bars',kind:'min',h:200,items:weekItems,label:'Minutes studied per day this week'}):emptyStudy}</section>
        <section class="panel chart-card"><div class="panel-header"><div><h2>Goal completion</h2><p>Progress toward your targets</p></div></div><div class="ring-grid">${ringSVG(goal>0?weekMin/goal*100:0,'Weekly study goal',goal>0?`${fmtMin(weekMin)} of ${fmtMin(goal)}`:'No goal set')}${ringSVG(complete,'Assignments done',`${doneTasks} of ${data.tasks.length} submitted`,'var(--c-study)')}${ringSVG(data.subjects.length?targetsMet/data.subjects.length*100:0,'Grade targets',`${targetsMet} of ${data.subjects.length} subjects`,'var(--c-task)')}${ringSVG(data.topics.length?mastered/data.topics.length*100:0,'Topic mastery',`${mastered} of ${data.topics.length} topics`,'var(--c-exam)')}</div>
          <form id="weeklyGoalForm" class="goal-form"><label for="goalMinutes">Weekly study goal (minutes)</label><div class="goal-form-row"><input id="goalMinutes" name="goal" type="number" min="0" max="10080" step="5" value="${goal}" inputmode="numeric"><button class="button tonal small" type="submit">Save goal</button></div><div class="hint">Set to 0 to hide the goal.</div></form></section>
        <section class="panel chart-card"><div class="panel-header"><div><h2>Study session frequency</h2><p>Completed sessions per week</p></div><span class="tag">${hasWeeks?`Avg ${(weeks.reduce((n,w)=>n+w.n,0)/8).toFixed(1)}/wk`:'—'}</span></div>${hasWeeks?chartBox({type:'bars',kind:'n',h:200,items:freqItems,label:'Sessions per week, last 8 weeks'}):emptyStudy}</section>
        <section class="panel chart-card"><div class="panel-header"><div><h2>Subject distribution</h2><p>Where your study time went · last ${R} days</p></div></div>${hasRange?`<div class="dist-wrap">${chartBox({type:'donut',size:184,items:dist.map(d=>({value:d.min,color:d.color,tip:d.tip})),center:{big:fmtMin(rangeMin),small:'studied'},label:'Study time by subject'},'donut-box')}<div class="dist-legend">${dist.map(d=>`<div class="dist-row" data-tip="${esc(d.tip)}"><i style="background:${esc(d.color)}"></i><span>${esc(d.name)}</span><b>${fmtMin(d.min)}</b><small>${d.pct}%</small></div>`).join('')}</div></div>`:emptyStudy}</section>
        <section class="panel chart-card"><div class="panel-header"><div><h2>Productivity trend</h2><p>Weekly study time · last 8 weeks</p></div>${hasWeeks?(prev4>0?`<span class="delta ${last4>=prev4?'up':'down'}">${icon(last4>=prev4?'arrowUp':'arrowDown',12)}${Math.abs(Math.round((last4-prev4)/prev4*100))}% vs prior 4 wks</span>`:'<span class="delta flat">Not enough history to compare</span>'):''}</div>${hasWeeks?chartBox({type:'line',kind:'min',h:200,items:trendItems,label:'Weekly study minutes, last 8 weeks'}):emptyStudy}</section>
        <section class="panel chart-card"><div class="panel-header"><div><h2>Comparisons</h2><p>Same elapsed days, so partial periods compare fairly</p></div><div class="cmp-key"><span><i></i>Current</span><span class="prev"><i></i>Previous</span></div></div>
          <h3 class="cmp-title">This week vs last week</h3>${cmp('Study time',weekMin,sumMinutes(prevWs,prevToday,doneAll),fmtMin)}${cmp('Sessions',countSessions(ws,today,doneAll),prevN,v=>String(v))}${cmp('Active days',thisDays,prevDays,v=>String(v))}
          <h3 class="cmp-title">This month vs last month</h3>${cmp('Study time',mMin,pmMin,fmtMin)}${cmp('Sessions',mN,pmN,v=>String(v))}${cmp('Active days',mDays,pmDays,v=>String(v))}</section>
        <section class="panel chart-card"><div class="panel-header"><div><h2>Current grades by subject</h2><p>Compared with your target</p></div></div>${scored.length?`<div class="bar-chart">${scored.map((s,i)=>`<div class="bar-group" style="--b:${i}"><div class="bar-value">${Math.round(s.g)}%</div><div class="bar ${s.g===Math.max(...scored.map(x=>x.g))?'current':''}" style="height:${Math.max(4,s.g/max*100)}%;background:${esc(s.color)}"></div><div class="bar-label">${esc(s.name)}</div></div>`).join('')}</div><div class="tag-row" style="margin-top:13px"><span class="tag">● Bar height represents current grade</span></div>`:emptyState('⌁','Not enough grade data','Record marks to see subject performance.')}</section>
        <section class="panel chart-card"><div class="panel-header"><div><h2>Target gaps</h2><p>Subjects to prioritize next</p></div></div>${grades.length?`<div class="subject-list">${grades.map(s=>{const gap=s.g===null?null:Math.round((s.target-s.g)*10)/10;return `<div><div class="subject-row"><div class="subject-icon" style="background:${esc(s.color)}20;color:${esc(s.color)}">${esc(s.name.slice(0,2).toUpperCase())}</div><div><div class="subject-name">${esc(s.name)}</div><div class="subject-sub">Target ${s.target}%</div></div><div class="subject-grade" style="font-size:12px">${gap===null?'No grades':gap<=0?'<span style="color:var(--green)">On target</span>':`+${gap}% needed`}</div></div></div>`}).join('')}</div>`:emptyState('◎','No subjects','Add subjects to set targets.')}</section>
        <section class="panel chart-card"><div class="panel-header"><div><h2>Workload snapshot</h2><p>Assignments by current state</p></div></div>${[['Not started',data.tasks.filter(t=>t.status==='Not started').length],['In progress',data.tasks.filter(t=>t.status==='In progress').length],['Submitted',data.tasks.filter(t=>t.status==='Submitted').length],['Graded',data.tasks.filter(t=>t.status==='Graded').length]].map(([name,count])=>`<div style="margin:13px 0"><div style="display:flex;justify-content:space-between;font-size:11px"><span>${name}</span><strong>${count}</strong></div><div class="progress-track"><div class="progress-fill" style="width:${data.tasks.length?count/data.tasks.length*100:0}%"></div></div></div>`).join('')}<div class="inline-note" style="margin-top:13px">Study charts count completed sessions only: logged manually or by the focus timer. Planned revision slots are not counted until you log them.</div></section>
        <section class="panel chart-card"><div class="panel-header"><div><h2>Grade target simulator</h2><p>Test a hypothetical final assessment without changing official grades.</p></div></div><form id="targetSimulator"><div class="field"><label for="simSubject">Subject</label><select id="simSubject" name="subjectId">${data.subjects.map(s=>`<option value="${s.id}">${esc(s.name)}</option>`).join('')}</select></div><div class="field-row"><div class="field"><label for="simCurrent">Current grade (%)</label><input id="simCurrent" name="current" type="number" min="0" max="100" step="any" value="${data.subjects[0]&&gradeFor(data.subjects[0])!==null?Math.round(gradeFor(data.subjects[0])*10)/10:''}" required></div><div class="field"><label for="simTarget">Target final (%)</label><input id="simTarget" name="target" type="number" min="0" max="100" step="any" value="90" required></div></div><div class="field"><label for="simCompleted">Final grade already completed (%)</label><input id="simCompleted" name="completed" type="number" min="0" max="99.9" step="any" value="60" required><div class="hint">Estimate how much of the final grade is already determined. This is separate from category weights in the gradebook.</div></div><button class="button primary" type="submit">Calculate required mark</button></form><div id="simResult" class="inline-note" style="margin-top:13px" aria-live="polite">Enter your assumptions to calculate the score required on the remaining assessment(s).</div></section>
      </div>`;
  }
  /* ===== StudyOS 4.3.6 · Mind Map =====
     Maps live in data.mindMaps (saved with every backup). A node is {id,parent,text,x,y,color,collapsed};
     parent/child links form the tree, data.mindMaps[i].links holds extra cross-links. */
  function mmClean(m){
    const nodes=(Array.isArray(m.nodes)?m.nodes:[]).filter(n=>n&&typeof n==='object').map(n=>({id:String(n.id||uid()),parent:n.parent?String(n.parent):null,text:String(n.text==null?'':n.text).slice(0,160),x:Number.isFinite(+n.x)?+n.x:0,y:Number.isFinite(+n.y)?+n.y:0,color:Number.isInteger(n.color)&&n.color>=0&&n.color<=5?n.color:null,collapsed:!!n.collapsed}));
    const byId=new Map(nodes.map(n=>[n.id,n]));
    nodes.forEach(n=>{if(n.parent&&(!byId.has(n.parent)||n.parent===n.id))n.parent=null;});
    nodes.forEach(n=>{const seen=new Set([n.id]);let p=n.parent;while(p){if(seen.has(p)){n.parent=null;break;}seen.add(p);p=byId.get(p)?.parent||null;}});
    const links=(Array.isArray(m.links)?m.links:[]).filter(l=>l&&byId.has(l.from)&&byId.has(l.to)&&l.from!==l.to).map(l=>({id:String(l.id||uid()),from:l.from,to:l.to}));
    const v=m.view;const view=v&&Number.isFinite(+v.x)&&Number.isFinite(+v.y)&&Number.isFinite(+v.k)&&+v.k>0?{x:+v.x,y:+v.y,k:Math.max(0.2,Math.min(3,+v.k))}:null;
    return{id:String(m.id||uid()),title:String(m.title||'Untitled mind map').slice(0,80),subjectId:String(m.subjectId||''),created:Number(m.created)||Date.now(),updated:Number(m.updated)||Date.now(),view,nodes,links};
  }
  const MM={id:'',sel:null,selLink:null,linking:null,editing:null,hist:[],redo:[],disp:{},size:{},els:new Map(),edgeEls:new Map(),tw:null,vtw:null,saveT:null,root:null,cv:null,world:null,svg:null,drag:null,ptrs:new Map(),lastTap:null,help:false,zoomT:null};
  const MM_MAX=60;
  const mmCur=()=>{const list=data.mindMaps;if(!list.length)return null;return list.find(m=>m.id===MM.id)||list.find(m=>m.id===data.settings?.mmActive)||list[0];};
  const mmNode=id=>mmCur()?.nodes.find(n=>n.id===id);
  const mmEst=n=>{const root=!n.parent;return{w:Math.min(root?280:240,Math.max(root?110:72,(n.text.length||8)*(root?9.4:7.6)+(root?44:34))),h:root?54:42};};
  function mmIndex(m){
    const byId=new Map(m.nodes.map(n=>[n.id,n])),kids=new Map(),roots=[];
    m.nodes.forEach(n=>{if(n.parent&&byId.has(n.parent)){if(!kids.has(n.parent))kids.set(n.parent,[]);kids.get(n.parent).push(n);}else roots.push(n);});
    const depth={},tone={},hidden=new Set(),rootOf={};
    const walk=(n,d,t,hid,rt,bi)=>{depth[n.id]=d;rootOf[n.id]=rt;const own=n.color!==null&&n.color!==undefined?n.color:(d===0?0:t);tone[n.id]=own;if(hid)hidden.add(n.id);(kids.get(n.id)||[]).forEach((k,i)=>walk(k,d+1,d===0?(i%5)+1:own,hid||n.collapsed,rt,i));};
    roots.forEach(r=>walk(r,0,0,false,r.id,0));
    return{byId,kids,roots,depth,tone,hidden,rootOf};
  }
  const mmDesc=(ix,id,acc=[])=>{(ix.kids.get(id)||[]).forEach(k=>{acc.push(k.id);mmDesc(ix,k.id,acc);});return acc;};
  const mmSnapshot=m=>JSON.stringify({nodes:m.nodes,links:m.links});
  function mmPush(){const m=mmCur();if(!m)return;MM.hist.push(mmSnapshot(m));if(MM.hist.length>MM_MAX)MM.hist.shift();MM.redo=[];mmCtx();}
  function mmRestore(str){const m=mmCur();const s=JSON.parse(str);m.nodes=s.nodes;m.links=s.links;if(MM.sel&&!mmNode(MM.sel))MM.sel=null;MM.selLink=null;MM.linking=null;mmReconcile(true);mmSaveSoon();mmCtx();}
  function mmUndo(){const m=mmCur();if(!m||!MM.hist.length){toast('Nothing to undo.');return;}mmCommitEdit();MM.redo.push(mmSnapshot(m));mmRestore(MM.hist.pop());}
  function mmRedo(){const m=mmCur();if(!m||!MM.redo.length){toast('Nothing to redo.');return;}MM.hist.push(mmSnapshot(m));mmRestore(MM.redo.pop());}
  function mmSaveSoon(viewOnly){clearTimeout(MM.saveT);MM.saveT=setTimeout(()=>mmFlush(viewOnly),viewOnly?700:250);}
  function mmFlush(viewOnly){clearTimeout(MM.saveT);MM.saveT=null;const m=mmCur();if(!m)return;if(!viewOnly)m.updated=Date.now();if(data.settings)data.settings.mmActive=m.id;save();}
  window.addEventListener('pagehide',()=>{if(MM.saveT)mmFlush();});
  document.addEventListener('visibilitychange',()=>{if(document.hidden&&MM.saveT)mmFlush();});

  function renderMindMap(){
    const maps=data.mindMaps,m=mmCur();
    if(m)MM.id=m.id;
    const head=`<div class="mm-head"><div class="mm-head-title"><button type="button" class="icon-button small" data-view="tools" aria-label="Back to StudyOS Tools" title="Back to Tools">←</button><div><div class="eyebrow">STUDYOS TOOLS</div><h1>Mind Map</h1></div></div>${m?`<div class="mm-head-actions"><label class="mm-select-wrap"><span class="sr-only">Mind map</span><select id="mmSelect" aria-label="Choose mind map">${maps.map(x=>`<option value="${esc(x.id)}" ${x.id===m.id?'selected':''}>${esc(x.title)}</option>`).join('')}</select></label><button type="button" class="icon-button small" data-mm="rename" title="Rename map" aria-label="Rename map">${icon('edit',16)}</button><button type="button" class="icon-button small" data-mm="duplicate" title="Duplicate map" aria-label="Duplicate map">${icon('copy',16)}</button><button type="button" class="icon-button small danger-ic" data-mm="delete-map" title="Delete map" aria-label="Delete map">${icon('trash',16)}</button><button type="button" class="button primary small" data-mm="new">${icon('plus',15)} New map</button></div>`:''}</div>`;
    if(!m)return `<div class="mm-page">${head}<section class="panel mm-empty">${emptyState(icon('mindmap',30),'Create your first mind map','Plan an essay, break down a chapter or connect ideas across subjects. Your maps are saved automatically on this device.',button(`${icon('plus',15)} New mind map`,'mm-new-map'))}</section></div>`.replace('data-action="mm-new-map"','data-mm="new"');
    return `<div class="mm-page">${head}<div class="mm-shell" id="mmShell" tabindex="-1">
      <div class="mm-canvas" id="mmCanvas" aria-label="Mind map canvas"><div class="mm-world" id="mmWorld"><svg class="mm-edges" id="mmEdges" width="1" height="1"></svg></div></div>
      <div class="mm-bar mm-bar-left" role="toolbar" aria-label="Map tools"><button type="button" data-mm="undo" title="Undo (Ctrl+Z)" aria-label="Undo">${icon('undo',17)}</button><button type="button" data-mm="redo" title="Redo (Ctrl+Shift+Z)" aria-label="Redo">${icon('redo',17)}</button><span class="mm-sep"></span><button type="button" data-mm="tidy" title="Tidy layout" aria-label="Tidy layout">${icon('layout',17)}</button><button type="button" data-mm="add-root" title="Add a new topic" aria-label="Add a new topic">${icon('plus',17)}</button></div>
      <div class="mm-bar mm-bar-right" role="toolbar" aria-label="Zoom"><button type="button" data-mm="zoom-out" title="Zoom out" aria-label="Zoom out">${icon('minus',17)}</button><button type="button" class="mm-zoom-val" data-mm="zoom-reset" id="mmZoomVal" title="Reset zoom" aria-label="Reset zoom">100%</button><button type="button" data-mm="zoom-in" title="Zoom in" aria-label="Zoom in">${icon('plus',17)}</button><span class="mm-sep"></span><button type="button" data-mm="fit" title="Fit map to screen" aria-label="Fit to screen">${icon('fit',17)}</button><button type="button" data-mm="help" title="Shortcuts" aria-label="Help and shortcuts">${icon('help',17)}</button></div>
      <div class="mm-ctx" id="mmCtx" role="toolbar" aria-label="Selected node"></div>
      <div class="mm-help" id="mmHelp" hidden><strong>Quick guide</strong><ul><li><b>Double-click</b> the canvas to add a topic, a node to rename it</li><li><b>Tab</b> adds a child, <b>Enter</b> adds a sibling</li><li>Drag the <b>＋</b> handle onto another node to link them, or onto empty space to branch</li><li><b>Space</b> collapses or expands · <b>Delete</b> removes</li><li>Scroll to zoom, drag the background to pan, pinch on touch screens</li><li><b>Ctrl+Z</b> undo · <b>Ctrl+Shift+Z</b> redo · arrows move selection</li></ul></div>
      <div class="mm-save" id="mmSave" aria-live="polite">Saved</div></div></div>`;
  }

  function mmMount(){
    MM.root=$('#mmShell');if(!MM.root)return;
    MM.cv=$('#mmCanvas');MM.world=$('#mmWorld');MM.svg=$('#mmEdges');
    MM.els=new Map();MM.edgeEls=new Map();MM.disp={};MM.size={};MM.hist=[];MM.redo=[];MM.drag=null;MM.ptrs=new Map();MM.editing=null;MM.linking=null;MM.selLink=null;
    const m=mmCur();if(!m)return;
    if(MM.sel&&!mmNode(MM.sel))MM.sel=null;
    MM.world.querySelectorAll('.mm-node').forEach(n=>n.remove());
    mmReconcile(false,true);
    if(m.view)mmApplyView();else mmFit(false);
    mmCtx();
    const cv=MM.cv;
    cv.addEventListener('pointerdown',mmDown);cv.addEventListener('pointermove',mmMove);cv.addEventListener('pointerup',mmUp);cv.addEventListener('pointercancel',mmUp);
    cv.addEventListener('wheel',mmWheel,{passive:false});
    cv.addEventListener('contextmenu',e=>e.preventDefault());
  }

  function mmApplyView(){const m=mmCur();if(!m||!MM.world)return;const v=m.view||{x:0,y:0,k:1};MM.world.style.transform=`translate(${v.x}px,${v.y}px) scale(${v.k})`;MM.cv.style.setProperty('--vx',v.x+'px');MM.cv.style.setProperty('--vy',v.y+'px');MM.cv.style.setProperty('--vk',v.k);const z=$('#mmZoomVal');if(z)z.textContent=Math.round(v.k*100)+'%';}
  function mmSetView(v,animate){
    const m=mmCur();if(!m)return;const to={x:v.x,y:v.y,k:Math.max(0.2,Math.min(2.5,v.k))};
    cancelAnimationFrame(MM.vtw);
    if(!animate||reduceMotion()){m.view=to;mmApplyView();mmSaveSoon(true);return;}
    const from={...(m.view||{x:0,y:0,k:1})},t0=performance.now(),dur=360;
    const step=now=>{const p=Math.min(1,(now-t0)/dur),e=1-Math.pow(1-p,3);m.view={x:from.x+(to.x-from.x)*e,y:from.y+(to.y-from.y)*e,k:from.k+(to.k-from.k)*e};mmApplyView();if(p<1)MM.vtw=requestAnimationFrame(step);else mmSaveSoon(true);};
    MM.vtw=requestAnimationFrame(step);
  }
  function mmZoomAt(factor,cx,cy,animate){const m=mmCur();if(!m)return;const v=m.view||{x:0,y:0,k:1},k=Math.max(0.2,Math.min(2.5,v.k*factor)),f=k/v.k;mmSetView({x:cx-(cx-v.x)*f,y:cy-(cy-v.y)*f,k},animate);}
  function mmFit(animate){
    const m=mmCur();if(!m||!MM.cv)return;const r=MM.cv.getBoundingClientRect(),vis=m.nodes.filter(n=>!MM.hiddenSet?.has(n.id));
    const nodes=vis.length?vis:m.nodes;
    if(!nodes.length){mmSetView({x:r.width/2,y:r.height/2,k:1},animate);return;}
    let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;nodes.forEach(n=>{const p=MM.disp[n.id]||{x:n.x,y:n.y},s=MM.size[n.id]||mmEst(n);x0=Math.min(x0,p.x-s.w/2);x1=Math.max(x1,p.x+s.w/2);y0=Math.min(y0,p.y-s.h/2);y1=Math.max(y1,p.y+s.h/2);});
    const pad=Math.min(70,r.width*0.1),bw=Math.max(1,x1-x0),bh=Math.max(1,y1-y0),k=Math.max(0.3,Math.min(1.25,Math.min((r.width-pad*2)/bw,(r.height-pad*2-60)/bh)));
    mmSetView({x:r.width/2-((x0+x1)/2)*k,y:(r.height-40)/2-((y0+y1)/2)*k,k},animate);
  }

  function mmMakeNode(n){const el=document.createElement('div');el.className='mm-node';el.dataset.id=n.id;el.innerHTML='<div class="mm-body"><span class="mm-text"></span></div><button type="button" class="mm-fold" tabindex="-1" aria-label="Collapse or expand branch"></button><button type="button" class="mm-plus" tabindex="-1" aria-label="Add child. Drag to connect." title="Click to add a child · drag to connect"></button>';el.querySelector('.mm-plus').innerHTML=icon('plus',14);return el;}
  const mmPlace=id=>{const el=MM.els.get(id),p=MM.disp[id];if(el&&p){el.style.setProperty('--x',p.x.toFixed(1));el.style.setProperty('--y',p.y.toFixed(1));}};
  function mmMeasure(){MM.els.forEach((el,id)=>{const b=el.firstElementChild;MM.size[id]={w:b.offsetWidth,h:b.offsetHeight};});}
  function mmEdgeD(a,b){
    const pa=MM.disp[a],pb=MM.disp[b];if(!pa||!pb)return '';const sa=MM.size[a]||{w:100,h:40},sb=MM.size[b]||{w:100,h:40},dx=pb.x-pa.x,dy=pb.y-pa.y,gapX=Math.abs(dx)-(sa.w+sb.w)/2;
    if(gapX>6||Math.abs(dx)>Math.abs(dy)*1.4){const s=dx>=0?1:-1,x1=pa.x+s*sa.w/2,x2=pb.x-s*sb.w/2,k=Math.max(36,Math.abs(x2-x1)*0.5);return `M${x1.toFixed(1)} ${pa.y.toFixed(1)}C${(x1+s*k).toFixed(1)} ${pa.y.toFixed(1)} ${(x2-s*k).toFixed(1)} ${pb.y.toFixed(1)} ${x2.toFixed(1)} ${pb.y.toFixed(1)}`;}
    const s=dy>=0?1:-1,y1=pa.y+s*sa.h/2,y2=pb.y-s*sb.h/2,k=Math.max(30,Math.abs(y2-y1)*0.5);return `M${pa.x.toFixed(1)} ${y1.toFixed(1)}C${pa.x.toFixed(1)} ${(y1+s*k).toFixed(1)} ${pb.x.toFixed(1)} ${(y2-s*k).toFixed(1)} ${pb.x.toFixed(1)} ${y2.toFixed(1)}`;
  }
  function mmEdges(){MM.edgeEls.forEach((p,key)=>{const a=p.dataset.a,b=p.dataset.b,d=mmEdgeD(a,b);p.setAttribute('d',d);if(p._hit)p._hit.setAttribute('d',d);});}
  const svgEl=(tag,cls)=>{const e=document.createElementNS('http://www.w3.org/2000/svg',tag);if(cls)e.setAttribute('class',cls);return e;};

  function mmReconcile(animate,initial){
    const m=mmCur();if(!m||!MM.world)return;const ix=mmIndex(m);MM.hiddenSet=ix.hidden;
    const seen=new Set();
    m.nodes.forEach(n=>{
      seen.add(n.id);let el=MM.els.get(n.id);
      if(!el){el=mmMakeNode(n);MM.els.set(n.id,el);MM.world.appendChild(el);const par=n.parent&&MM.disp[n.parent];MM.disp[n.id]=!initial&&par?{x:par.x,y:par.y}:{x:n.x,y:n.y};if(!initial){el.classList.add('mm-enter');el.addEventListener('animationend',()=>el.classList.remove('mm-enter'),{once:true});}}
      const t=ix.tone[n.id];el.style.setProperty('--nbg',`var(--mm-t${t}-bg)`);el.style.setProperty('--nfg',`var(--mm-t${t}-fg)`);el.style.setProperty('--nln',`var(--mm-t${t}-ln)`);
      const kids=ix.kids.get(n.id)||[],rx=ix.byId.get(ix.rootOf[n.id])?.x??0,left=!!n.parent&&n.x<rx-1;
      el.classList.toggle('root',!n.parent);el.classList.toggle('sel',MM.sel===n.id);el.classList.toggle('away',ix.hidden.has(n.id));el.classList.toggle('has-kids',kids.length>0);el.classList.toggle('collapsed',!!n.collapsed&&kids.length>0);el.classList.toggle('side-l',left);
      el.classList.toggle('d1',ix.depth[n.id]===1);
      const tx=el.querySelector('.mm-text');if(!(MM.editing&&MM.editing.id===n.id))tx.textContent=n.text;tx.dataset.ph='New idea';
      const f=el.querySelector('.mm-fold');f.textContent=n.collapsed&&kids.length?String(mmDesc(ix,n.id).length):'−';f.title=n.collapsed?'Expand branch':'Collapse branch';
      mmPlace(n.id);
    });
    MM.els.forEach((el,id)=>{if(!seen.has(id)){MM.els.delete(id);delete MM.disp[id];delete MM.size[id];el.classList.add('mm-exit');setTimeout(()=>el.remove(),200);}});
    mmMeasure();
    // edges
    const want=new Map();
    m.nodes.forEach(n=>{if(n.parent&&ix.byId.has(n.parent))want.set('e'+n.id,{a:n.parent,b:n.id,kind:'tree'});});
    m.links.forEach(l=>want.set('l'+l.id,{a:l.from,b:l.to,kind:'link',id:l.id}));
    MM.edgeEls.forEach((p,key)=>{if(!want.has(key)){p.remove();if(p._hit)p._hit.remove();MM.edgeEls.delete(key);}});
    want.forEach((w,key)=>{let p=MM.edgeEls.get(key);
      if(!p){p=svgEl('path',w.kind==='link'?'mm-link':'mm-edge');p.dataset.a=w.a;p.dataset.b=w.b;MM.svg.appendChild(p);MM.edgeEls.set(key,p);
        if(w.kind==='link'){const hit=svgEl('path','mm-linkhit');hit.dataset.link=w.id;MM.svg.appendChild(hit);p._hit=hit;if(!initial){p.setAttribute('d',mmEdgeD(w.a,w.b));p.style.setProperty('--len',(p.getTotalLength()||300)+'');p.classList.add('draw');p.addEventListener('animationend',()=>p.classList.remove('draw'),{once:true});}}}
      p.dataset.a=w.a;p.dataset.b=w.b;
      const child=w.kind==='tree'?w.b:w.a;
      if(w.kind==='tree'){p.style.stroke=`var(--mm-t${ix.tone[w.b]}-ln)`;p.style.strokeWidth=ix.depth[w.b]<=1?3:2.2;}
      p.classList.toggle('away',ix.hidden.has(w.b)||(w.kind==='link'&&(ix.hidden.has(w.a)||ix.hidden.has(w.b))));
      p.classList.toggle('flow',!!MM.sel&&(w.a===MM.sel||w.b===MM.sel)&&w.kind==='tree');
      p.classList.toggle('picked',w.kind==='link'&&MM.selLink===w.id);
    });
    mmGoTo(mmTargets(m,ix),animate&&!reduceMotion()?380:0);
  }
  function mmTargets(m,ix){const t={};const resolve=n=>{if(!ix.hidden.has(n.id))return{x:n.x,y:n.y};let p=n;while(p&&ix.hidden.has(p.id))p=ix.byId.get(p.parent);return p?{x:p.x,y:p.y}:{x:n.x,y:n.y};};m.nodes.forEach(n=>{t[n.id]=resolve(n);});return t;}
  function mmGoTo(targets,dur){
    cancelAnimationFrame(MM.tw);const ids=Object.keys(targets).filter(id=>MM.disp[id]);
    if(!dur){ids.forEach(id=>{MM.disp[id]={x:targets[id].x,y:targets[id].y};mmPlace(id);});mmEdges();return;}
    const from={};ids.forEach(id=>{from[id]={...MM.disp[id]};});const t0=performance.now();
    const step=now=>{const p=Math.min(1,(now-t0)/dur),e=1-Math.pow(1-p,3);ids.forEach(id=>{if(!MM.disp[id])return;MM.disp[id]={x:from[id].x+(targets[id].x-from[id].x)*e,y:from[id].y+(targets[id].y-from[id].y)*e};mmPlace(id);});mmEdges();if(p<1)MM.tw=requestAnimationFrame(step);};
    MM.tw=requestAnimationFrame(step);
  }

  function mmSelect(id,linkId){
    MM.sel=id||null;MM.selLink=linkId||null;
    const m=mmCur();if(!m)return;
    MM.els.forEach((el,nid)=>el.classList.toggle('sel',nid===MM.sel));
    MM.edgeEls.forEach((p,key)=>{const a=p.dataset.a,b=p.dataset.b,link=key[0]==='l';p.classList.toggle('flow',!!MM.sel&&!link&&(a===MM.sel||b===MM.sel));p.classList.toggle('picked',link&&MM.selLink===key.slice(1));});
    if(id){const el=MM.els.get(id);if(el)MM.world.appendChild(el);}
    mmCtx();
  }
  function mmCtx(){
    const box=$('#mmCtx'),m=mmCur();if(!box||!m)return;
    const u=$('[data-mm="undo"]'),r=$('[data-mm="redo"]');if(u)u.disabled=!MM.hist.length;if(r)r.disabled=!MM.redo.length;
    if(MM.linking){box.innerHTML=`<span class="mm-hint">Click another node to link it · click an existing link to remove it</span><button type="button" class="mm-pill" data-mm="cancel-link">Cancel</button>`;box.classList.add('show');return;}
    if(MM.selLink){box.innerHTML=`<span class="mm-hint">Cross-link selected</span><button type="button" class="mm-pill danger" data-mm="delete-link">${icon('trash',15)} Remove link</button>`;box.classList.add('show');return;}
    const n=MM.sel&&mmNode(MM.sel);
    if(!n){box.innerHTML=`<span class="mm-hint">Select a node to edit it · double-click the canvas to add a topic</span>`;box.classList.add('show','idle');return;}
    box.classList.remove('idle');
    const ix=mmIndex(m),kids=(ix.kids.get(n.id)||[]).length,cur=n.color;
    box.innerHTML=`<button type="button" class="mm-pill" data-mm="child">${icon('plus',15)} Child</button><button type="button" class="mm-pill" data-mm="sibling" ${n.parent?'':'disabled'}>Sibling</button><button type="button" class="mm-pill" data-mm="edit">${icon('edit',15)} Edit</button><span class="mm-sep"></span><div class="mm-swatches" role="group" aria-label="Node colour">${[0,1,2,3,4,5].map(i=>`<button type="button" class="mm-sw ${cur===i?'on':''}" data-mm="color" data-c="${i}" style="--sw:var(--mm-t${i}-ln)" aria-label="Colour ${i+1}" title="Colour ${i+1}"></button>`).join('')}<button type="button" class="mm-sw auto ${cur===null?'on':''}" data-mm="color" data-c="auto" aria-label="Automatic colour" title="Automatic colour (follows the branch)">A</button></div><span class="mm-sep"></span><button type="button" class="mm-pill" data-mm="link">${icon('link',15)} Link</button>${kids?`<button type="button" class="mm-pill" data-mm="fold">${n.collapsed?'Expand':'Collapse'}</button>`:''}<button type="button" class="mm-pill danger" data-mm="delete">${icon('trash',15)}</button>`;
    box.classList.add('show');
  }
  function mmSavedFlash(){const s=$('#mmSave');if(!s)return;s.textContent='Saved';s.classList.add('on');clearTimeout(MM.zoomT);MM.zoomT=setTimeout(()=>s.classList.remove('on'),1200);}

  // ---- creating, editing, deleting ----
  function mmReveal(id){const m=mmCur(),n=mmNode(id);if(!m||!MM.cv)return;const r=MM.cv.getBoundingClientRect(),v=m.view||{x:0,y:0,k:1},sz=MM.size[id]||mmEst(n),mx=70,top=70,bot=90;const sx=v.x+n.x*v.k,sy=v.y+n.y*v.k,hw=sz.w*v.k/2,hh=sz.h*v.k/2;let dx=0,dy=0;if(sx-hw<mx)dx=mx-(sx-hw);else if(sx+hw>r.width-mx)dx=r.width-mx-(sx+hw);if(sy-hh<top)dy=top-(sy-hh);else if(sy+hh>r.height-bot)dy=r.height-bot-(sy+hh);if(dx||dy)mmSetView({x:v.x+dx,y:v.y+dy,k:v.k},true);}
  function mmChildPos(m,p){
    const ix=mmIndex(m),root=ix.byId.get(ix.rootOf[p.id])||p,sz=MM.size[p.id]||mmEst(p);
    let dir;if(p.parent)dir=p.x<root.x-1?-1:1;else{const r=m.nodes.filter(n=>n.parent===p.id&&n.x>p.x).length,l=m.nodes.filter(n=>n.parent===p.id&&n.x<=p.x).length;dir=l<r?-1:1;}
    const sibs=m.nodes.filter(n=>n.parent===p.id&&(dir>0?n.x>p.x:n.x<=p.x));let y=sibs.length?Math.max(...sibs.map(n=>n.y))+58:p.y;const x=p.x+dir*(sz.w/2+70+64);
    for(let g=0;g<40&&m.nodes.some(n=>Math.abs(n.x-x)<150&&Math.abs(n.y-y)<48);g++)y+=58;
    return{x,y};
  }
  function mmAddChild(parentId,pos){
    const m=mmCur(),p=mmNode(parentId);if(!m||!p)return;mmCommitEdit();mmPush();
    if(p.collapsed)p.collapsed=false;
    const at=pos||mmChildPos(m,p),n={id:uid(),parent:parentId,text:'',x:at.x,y:at.y,color:null,collapsed:false};
    m.nodes.push(n);MM.sel=n.id;mmReconcile(true);mmSelect(n.id);mmEdit(n.id,true);mmReveal(n.id);mmSaveSoon();
  }
  function mmAddRoot(pos){
    const m=mmCur();if(!m)return;mmCommitEdit();mmPush();
    let at=pos;if(!at){const r=MM.cv.getBoundingClientRect(),v=m.view||{x:0,y:0,k:1};at={x:(r.width/2-v.x)/v.k,y:(r.height/2-v.y)/v.k};let g=0;while(g++<30&&m.nodes.some(n=>Math.abs(n.x-at.x)<160&&Math.abs(n.y-at.y)<60))at.y+=64;}
    const n={id:uid(),parent:null,text:'',x:at.x,y:at.y,color:null,collapsed:false};m.nodes.push(n);MM.sel=n.id;mmReconcile(true);mmSelect(n.id);mmEdit(n.id,true);mmSaveSoon();
  }
  function mmEdit(id,isNew){
    const el=MM.els.get(id),n=mmNode(id);if(!el||!n)return;mmCommitEdit();
    const tx=el.querySelector('.mm-text');MM.editing={id,isNew:!!isNew,orig:n.text};el.classList.add('editing');
    try{tx.contentEditable='plaintext-only';}catch{}if(tx.contentEditable!=='plaintext-only')tx.contentEditable='true';
    tx.focus();const rg=document.createRange();rg.selectNodeContents(tx);const sel=getSelection();sel.removeAllRanges();sel.addRange(rg);
    tx.onkeydown=e=>{e.stopPropagation();if(e.key==='Enter'){e.preventDefault();mmCommitEdit();}else if(e.key==='Escape'){e.preventDefault();mmCancelEdit();}else if(e.key==='Tab'){e.preventDefault();const cid=id;mmCommitEdit();if(mmNode(cid))mmAddChild(cid);}};
    tx.oninput=()=>{if(tx.textContent.length>160)tx.textContent=tx.textContent.slice(0,160);mmMeasure();mmEdges();};
    tx.onpaste=e=>{e.preventDefault();const t=(e.clipboardData||window.clipboardData).getData('text').replace(/\s+/g,' ');document.execCommand('insertText',false,t);};
    tx.onblur=()=>{if(MM.editing&&MM.editing.id===id)mmCommitEdit();};
  }
  function mmFinishEditDom(id){const el=MM.els.get(id);if(!el)return;const tx=el.querySelector('.mm-text');tx.contentEditable='false';tx.removeAttribute('contenteditable');tx.onkeydown=tx.oninput=tx.onpaste=tx.onblur=null;el.classList.remove('editing');}
  function mmCommitEdit(){
    const ed=MM.editing;if(!ed)return;MM.editing=null;const el=MM.els.get(ed.id),n=mmNode(ed.id);if(!el||!n)return;
    const tx=el.querySelector('.mm-text'),val=tx.textContent.replace(/\s+/g,' ').trim().slice(0,160);mmFinishEditDom(ed.id);
    if(!val){if(ed.isNew){MM.hist.pop();const m=mmCur();m.nodes=m.nodes.filter(x=>x.id!==ed.id);m.links=m.links.filter(l=>l.from!==ed.id&&l.to!==ed.id);MM.sel=n.parent||null;mmReconcile(true);mmSelect(MM.sel);mmCtx();mmSaveSoon();return;}tx.textContent=n.text;mmMeasure();mmEdges();return;}
    if(val!==n.text){if(!ed.isNew)mmPush();n.text=val;mmSaveSoon();}tx.textContent=n.text;mmMeasure();mmEdges();window.getSelection()?.removeAllRanges();
  }
  function mmCancelEdit(){const ed=MM.editing;if(!ed)return;const el=MM.els.get(ed.id),n=mmNode(ed.id);if(el)el.querySelector('.mm-text').textContent='';if(ed.isNew){MM.editing=null;mmFinishEditDom(ed.id);MM.hist.pop();const m=mmCur();m.nodes=m.nodes.filter(x=>x.id!==ed.id);MM.sel=n?.parent||null;mmReconcile(true);mmSelect(MM.sel);mmSaveSoon();return;}if(el&&n)el.querySelector('.mm-text').textContent=n.text;MM.editing=null;mmFinishEditDom(ed.id);mmMeasure();mmEdges();}
  function mmDelete(id){
    const m=mmCur(),n=mmNode(id);if(!m||!n)return;const ix=mmIndex(m),gone=[id,...mmDesc(ix,id)];
    const run=()=>{mmPush();const set=new Set(gone);m.nodes=m.nodes.filter(x=>!set.has(x.id));m.links=m.links.filter(l=>!set.has(l.from)&&!set.has(l.to));MM.sel=n.parent&&!set.has(n.parent)?n.parent:null;mmReconcile(true);mmSelect(MM.sel);mmSaveSoon();};
    if(gone.length>1)confirmDialog(`Delete this node and its ${plural(gone.length-1,'sub-node')}? You can undo this with Ctrl+Z while the map is open.`,'Delete',run);else run();
  }
  function mmToggleFold(id){const m=mmCur(),n=mmNode(id);if(!m||!n)return;if(!m.nodes.some(x=>x.parent===id))return;mmPush();n.collapsed=!n.collapsed;if(n.collapsed&&MM.sel&&mmDesc(mmIndex(m),id).includes(MM.sel))MM.sel=id;mmReconcile(true);mmSelect(MM.sel);mmSaveSoon();}
  function mmAddLink(a,b){
    const m=mmCur();if(!m||a===b)return;const A=mmNode(a),B=mmNode(b);if(!A||!B)return;
    if(A.parent===b||B.parent===a){toast('Those nodes are already connected.');return;}
    const ex=m.links.find(l=>(l.from===a&&l.to===b)||(l.from===b&&l.to===a));if(ex){toast('Those nodes are already linked.');return;}
    mmPush();m.links.push({id:uid(),from:a,to:b});mmReconcile(true);mmSaveSoon();toast('Nodes linked.');
  }
  function mmSetColor(id,c){const n=mmNode(id);if(!n)return;mmPush();n.color=c==='auto'?null:Number(c);mmReconcile(false);mmCtx();mmSaveSoon();}

  // ---- layout ----
  function mmTidy(){
    const m=mmCur();if(!m||!m.nodes.length)return;mmCommitEdit();mmPush();mmMeasure();const ix=mmIndex(m),GX=76,GY=16,memo={};
    const sz=id=>MM.size[id]||mmEst(ix.byId.get(id));
    const H=id=>{if(memo[id]!==undefined)return memo[id];const k=ix.kids.get(id)||[],own=sz(id).h+GY;return memo[id]=k.length?Math.max(own,k.reduce((a,c)=>a+H(c.id),0)):own;};
    const place=(id,x,y,dir)=>{const n=ix.byId.get(id);n.x=x;n.y=y;const k=ix.kids.get(id)||[],tot=k.reduce((a,c)=>a+H(c.id),0);let cy=y-tot/2;k.forEach(c=>{const hk=H(c.id);place(c.id,x+dir*(sz(id).w/2+GX+sz(c.id).w/2),cy+hk/2,dir);cy+=hk;});};
    ix.roots.forEach(r=>{const k=ix.kids.get(r.id)||[],right=[],left=[];let hr=0,hl=0;k.forEach(c=>{if(hr<=hl){right.push(c);hr+=H(c.id);}else{left.push(c);hl+=H(c.id);}});
      const ax=r.x,ay=r.y;const side=(list,dir,tot)=>{let cy=ay-tot/2;list.forEach(c=>{const hk=H(c.id);place(c.id,ax+dir*(sz(r.id).w/2+GX+sz(c.id).w/2),cy+hk/2,dir);cy+=hk;});};side(right,1,hr);side(left,-1,hl);});
    mmReconcile(true);setTimeout(()=>mmFit(true),60);mmSaveSoon();
  }

  // ---- pointer handling ----
  const mmWorldPt=(e)=>{const m=mmCur(),r=MM.cv.getBoundingClientRect(),v=m.view||{x:0,y:0,k:1};return{x:(e.clientX-r.left-v.x)/v.k,y:(e.clientY-r.top-v.y)/v.k,sx:e.clientX-r.left,sy:e.clientY-r.top};};
  function mmDown(e){
    const m=mmCur();if(!m)return;const t=e.target;
    if(MM.editing){if(t.closest('.mm-text[contenteditable]'))return;mmCommitEdit();}
    if(e.pointerType==='mouse'&&e.button===2)return;
    MM.ptrs.set(e.pointerId,{x:e.clientX,y:e.clientY});
    try{MM.cv.setPointerCapture(e.pointerId);}catch{}
    cancelAnimationFrame(MM.vtw);if(MM.root&&document.activeElement!==MM.root)MM.root.focus({preventScroll:true});
    if(MM.ptrs.size===2){const [a,b]=[...MM.ptrs.values()],v=m.view||{x:0,y:0,k:1},r=MM.cv.getBoundingClientRect();MM.drag={type:'pinch',d0:Math.hypot(a.x-b.x,a.y-b.y)||1,k0:v.k,cx0:(a.x+b.x)/2-r.left,cy0:(a.y+b.y)/2-r.top,v0:{...v},moved:true};return;}
    const nodeEl=t.closest('.mm-node'),w=mmWorldPt(e),base={sx:e.clientX,sy:e.clientY,moved:false,id:e.pointerId,t0:performance.now()};
    if(t.closest('.mm-plus')&&nodeEl){MM.drag={...base,type:'connect',from:nodeEl.dataset.id};mmSelect(nodeEl.dataset.id);return;}
    if(t.closest('.mm-fold')&&nodeEl){MM.drag={...base,type:'fold',id2:nodeEl.dataset.id};return;}
    if(nodeEl){const id=nodeEl.dataset.id,ix=mmIndex(m),ids=[id,...mmDesc(ix,id)];MM.drag={...base,type:'node',nid:id,w0:w,origin:ids.map(i=>{const n=mmNode(i);return{id:i,x:n.x,y:n.y};}),pushed:false};if(!MM.linking)mmSelect(id);return;}
    const hit=t.closest('.mm-linkhit');if(hit){MM.drag={...base,type:'linkpick',link:hit.dataset.link};return;}
    MM.drag={...base,type:'pan',v0:{...(m.view||{x:0,y:0,k:1})}};
  }
  function mmMove(e){
    const m=mmCur(),d=MM.drag;if(!m)return;
    if(MM.ptrs.has(e.pointerId))MM.ptrs.set(e.pointerId,{x:e.clientX,y:e.clientY});
    if(!d)return;
    if(d.type==='pinch'&&MM.ptrs.size>=2){const [a,b]=[...MM.ptrs.values()],r=MM.cv.getBoundingClientRect(),dist=Math.hypot(a.x-b.x,a.y-b.y)||1,k=Math.max(0.2,Math.min(2.5,d.k0*dist/d.d0)),f=k/d.k0,cx=(a.x+b.x)/2-r.left,cy=(a.y+b.y)/2-r.top;m.view={x:cx-(d.cx0-d.v0.x)*f,y:cy-(d.cy0-d.v0.y)*f,k};mmApplyView();return;}
    if(e.pointerId!==d.id)return;
    const dx=e.clientX-d.sx,dy=e.clientY-d.sy;if(!d.moved&&Math.hypot(dx,dy)>4)d.moved=true;
    if(!d.moved)return;
    if(d.type==='pan'){m.view={x:d.v0.x+dx,y:d.v0.y+dy,k:d.v0.k};mmApplyView();MM.cv.classList.add('panning');}
    else if(d.type==='node'){
      if(!d.pushed){mmPush();d.pushed=true;cancelAnimationFrame(MM.tw);d.origin.forEach(o=>MM.els.get(o.id)?.classList.add('dragging'));}
      const k=(m.view||{k:1}).k,ddx=dx/k,ddy=dy/k;d.origin.forEach(o=>{const n=mmNode(o.id);if(!n)return;n.x=o.x+ddx;n.y=o.y+ddy;MM.disp[o.id]={x:n.x,y:n.y};mmPlace(o.id);});mmEdges();
    }else if(d.type==='connect'){
      const a=MM.disp[d.from],w=mmWorldPt(e);let tmp=MM.svg.querySelector('.mm-temp');if(!tmp){tmp=svgEl('path','mm-temp');MM.svg.appendChild(tmp);}
      const sz=MM.size[d.from]||{w:80,h:40},y0=a.y+sz.h/2;tmp.setAttribute('d',`M${a.x.toFixed(1)} ${y0.toFixed(1)}C${a.x.toFixed(1)} ${(y0+50).toFixed(1)} ${w.x.toFixed(1)} ${(w.y-50).toFixed(1)} ${w.x.toFixed(1)} ${w.y.toFixed(1)}`);
      const under=document.elementFromPoint(e.clientX,e.clientY)?.closest?.('.mm-node');MM.els.forEach((el,id)=>el.classList.toggle('link-target',!!under&&under.dataset.id===id&&id!==d.from));
    }
  }
  function mmUp(e){
    const m=mmCur(),d=MM.drag;MM.ptrs.delete(e.pointerId);try{MM.cv.releasePointerCapture(e.pointerId);}catch{}
    if(!m||!d)return;
    if(d.type==='pinch'){if(MM.ptrs.size<2){MM.drag=null;mmSaveSoon(true);}return;}
    if(e.pointerId!==d.id)return;MM.drag=null;MM.cv.classList.remove('panning');
    if(d.type==='pan'){if(d.moved){mmSaveSoon(true);return;}mmTap(e,null);return;}
    if(d.type==='node'){MM.els.forEach(el=>el.classList.remove('dragging'));if(d.moved){mmSaveSoon();mmMeasure();return;}mmTap(e,d.nid);return;}
    if(d.type==='fold'){if(!d.moved)mmToggleFold(d.id2);return;}
    if(d.type==='linkpick'){if(!d.moved){if(MM.linking){const l=m.links.find(x=>x.id===d.link);if(l){mmPush();m.links=m.links.filter(x=>x.id!==d.link);mmReconcile(false);mmSaveSoon();toast('Link removed.');}}else mmSelect(null,d.link);}return;}
    if(d.type==='connect'){
      MM.svg.querySelector('.mm-temp')?.remove();MM.els.forEach(el=>el.classList.remove('link-target'));
      if(!d.moved){mmAddChild(d.from);return;}
      const under=document.elementFromPoint(e.clientX,e.clientY)?.closest?.('.mm-node');
      if(under&&under.dataset.id!==d.from)mmAddLink(d.from,under.dataset.id);
      else if(!under){const w=mmWorldPt(e);mmAddChild(d.from,{x:w.x,y:w.y});}
    }
  }
  function mmTap(e,nid){
    const now=performance.now(),lt=MM.lastTap,dbl=lt&&now-lt.t<340&&Math.hypot(e.clientX-lt.x,e.clientY-lt.y)<14&&lt.nid===nid;MM.lastTap={t:now,x:e.clientX,y:e.clientY,nid};
    if(nid){
      if(MM.linking){const from=MM.linking;MM.linking=null;if(from!==nid)mmAddLink(from,nid);mmCtx();mmSelect(nid);return;}
      if(dbl){MM.lastTap=null;mmEdit(nid,false);}
    }else{
      if(MM.linking){MM.linking=null;mmCtx();return;}
      if(dbl){MM.lastTap=null;mmAddRoot(mmWorldPt(e));return;}
      mmSelect(null);
    }
  }
  function mmWheel(e){e.preventDefault();const m=mmCur();if(!m)return;const r=MM.cv.getBoundingClientRect(),f=Math.exp(-e.deltaY*(e.ctrlKey?0.012:0.0016)*(e.deltaMode===1?16:1));mmZoomAt(f,e.clientX-r.left,e.clientY-r.top,false);}

  function mmNav(dir){
    const m=mmCur();if(!m)return;const cur=MM.sel&&mmNode(MM.sel);if(!cur){const r=m.nodes.find(n=>!n.parent);if(r)mmSelect(r.id);return;}
    const ix=mmIndex(m);let best=null,bs=1e9;m.nodes.forEach(n=>{if(n.id===cur.id||ix.hidden.has(n.id))return;const dx=n.x-cur.x,dy=n.y-cur.y,main=dir==='left'?-dx:dir==='right'?dx:dir==='up'?-dy:dy,cross=dir==='left'||dir==='right'?Math.abs(dy):Math.abs(dx);if(main<=4)return;const s=main+cross*2.2;if(s<bs){bs=s;best=n;}});
    if(best)mmSelect(best.id);
  }
  document.addEventListener('keydown',e=>{
    if(currentView!=='mindmap'||!MM.root||!MM.root.isConnected)return;
    if(document.getElementById('confirmRoot')||$('#modalRoot .modal'))return;
    const tg=e.target;if(tg.closest&&tg.closest('input,textarea,select,[contenteditable]'))return;
    if(tg.closest&&tg.closest('button')&&(e.key==='Enter'||e.key===' '))return;
    const m=mmCur();if(!m)return;const k=e.key,mod=e.ctrlKey||e.metaKey;
    if(mod&&k.toLowerCase()==='z'){e.preventDefault();e.shiftKey?mmRedo():mmUndo();return;}
    if(mod&&k.toLowerCase()==='y'){e.preventDefault();mmRedo();return;}
    if(mod||e.altKey)return;
    const id=MM.sel;
    if(k==='Tab'&&id){e.preventDefault();mmAddChild(id);}
    else if(k==='Enter'&&id){e.preventDefault();const n=mmNode(id);if(n&&n.parent)mmAddChild(n.parent);else mmAddChild(id);}
    else if(k==='F2'&&id){e.preventDefault();mmEdit(id,false);}
    else if((k==='Delete'||k==='Backspace')){if(MM.selLink){e.preventDefault();const l=MM.selLink;mmPush();m.links=m.links.filter(x=>x.id!==l);MM.selLink=null;mmReconcile(false);mmCtx();mmSaveSoon();}else if(id){e.preventDefault();mmDelete(id);}}
    else if(k===' '&&id){e.preventDefault();mmToggleFold(id);}
    else if(k==='Escape'){if(MM.linking){MM.linking=null;mmCtx();}else mmSelect(null);}
    else if(k.startsWith('Arrow')){e.preventDefault();mmNav(k.slice(5).toLowerCase());}
    else if(k==='+'||k==='='){const r=MM.cv.getBoundingClientRect();mmZoomAt(1.2,r.width/2,r.height/2,true);}
    else if(k==='-'||k==='_'){const r=MM.cv.getBoundingClientRect();mmZoomAt(1/1.2,r.width/2,r.height/2,true);}
    else if(k==='0'){mmFit(true);}
  });

  // ---- map management & toolbar clicks ----
  function mmNewMap(){modal('New mind map','Name it, and optionally start from one of your subjects.',`<div class="field"><label for="mmTitle">Title *</label><input id="mmTitle" name="title" required maxlength="80" placeholder="e.g. Cell biology revision"></div><div class="field"><label for="mmSubject">Subject (optional)</label><select id="mmSubject" name="subjectId">${subjectOptions('')}</select></div><label class="check-row"><input type="checkbox" name="topics" checked> <span>Add that subject’s syllabus topics as branches</span></label>`,'Create map','mmNewForm');}
  function mmCreate(title,subjectId,withTopics){
    const sub=subjectId?subject(subjectId):null,root={id:uid(),parent:null,text:(title||sub?.name||'Main idea').trim().slice(0,160),x:0,y:0,color:null,collapsed:false};
    const nodes=[root];
    if(sub&&withTopics)data.topics.filter(t=>t.subjectId===subjectId).slice(0,16).forEach(t=>nodes.push({id:uid(),parent:root.id,text:String(t.title).slice(0,160),x:0,y:0,color:null,collapsed:false}));
    const map=mmClean({id:uid(),title:title||sub?.name||'Untitled mind map',subjectId:subjectId||'',created:Date.now(),updated:Date.now(),view:null,nodes,links:[]});
    // lay out with estimated sizes so the starter map looks tidy before it is first rendered
    const GX=76,GY=16,r=map.nodes[0],kids=map.nodes.slice(1),est=n=>mmEst(n),hs=kids.map(k=>est(k).h+GY),half=Math.ceil(kids.length/2);
    const side=(list,dir)=>{const tot=list.reduce((a,k)=>a+est(k).h+GY,0);let cy=-tot/2;list.forEach(k=>{const e=est(k);k.x=dir*(est(r).w/2+GX+e.w/2);k.y=cy+(e.h+GY)/2;cy+=e.h+GY;});};
    side(kids.slice(0,half),1);side(kids.slice(half),-1);void hs;
    data.mindMaps.push(map);data.settings.mmActive=map.id;MM.id=map.id;MM.sel=root.id;save();return map;
  }
  function mmSwitch(id){mmFlush();MM.id=id;MM.sel=null;data.settings.mmActive=id;save();render();}
  document.addEventListener('click',e=>{
    const b=e.target.closest('[data-mm]');if(!b)return;const a=b.dataset.mm,m=mmCur();
    if(a==='new'){e.preventDefault();mmNewMap();return;}
    if(!m)return;
    switch(a){
      case 'rename':modal('Rename mind map','',`<div class="field"><label for="mmRen">Title *</label><input id="mmRen" name="title" required maxlength="80" value="${esc(m.title)}"></div>`,'Save','mmRenameForm');break;
      case 'duplicate':{mmFlush();const c=mmClean(JSON.parse(JSON.stringify(m)));const idMap={};c.nodes.forEach(n=>{idMap[n.id]=uid();});c.nodes.forEach(n=>{n.id=idMap[n.id];if(n.parent)n.parent=idMap[n.parent];});c.links=c.links.map(l=>({id:uid(),from:idMap[l.from],to:idMap[l.to]}));c.id=uid();c.title=(m.title+' (copy)').slice(0,80);c.created=c.updated=Date.now();data.mindMaps.push(c);MM.id=c.id;MM.sel=null;data.settings.mmActive=c.id;save();render();toast('Mind map duplicated.');break;}
      case 'delete-map':confirmDialog(`Delete “${m.title}” and all of its nodes? This cannot be undone.`,'Delete map',()=>{data.mindMaps=data.mindMaps.filter(x=>x.id!==m.id);MM.id='';MM.sel=null;data.settings.mmActive=data.mindMaps[0]?.id||'';save();render();toast('Mind map deleted.');});break;
      case 'undo':mmUndo();break;case 'redo':mmRedo();break;case 'tidy':mmTidy();break;case 'add-root':mmAddRoot();break;
      case 'zoom-in':{const r=MM.cv.getBoundingClientRect();mmZoomAt(1.25,r.width/2,r.height/2,true);break;}
      case 'zoom-out':{const r=MM.cv.getBoundingClientRect();mmZoomAt(0.8,r.width/2,r.height/2,true);break;}
      case 'zoom-reset':{const r=MM.cv.getBoundingClientRect(),v=m.view||{x:0,y:0,k:1};mmZoomAt(1/v.k,r.width/2,r.height/2,true);break;}
      case 'fit':mmFit(true);break;
      case 'help':{MM.help=!MM.help;const h=$('#mmHelp');if(h)h.hidden=!MM.help;break;}
      case 'child':if(MM.sel)mmAddChild(MM.sel);break;
      case 'sibling':{const n=MM.sel&&mmNode(MM.sel);if(n&&n.parent)mmAddChild(n.parent);break;}
      case 'edit':if(MM.sel)mmEdit(MM.sel,false);break;
      case 'color':if(MM.sel)mmSetColor(MM.sel,b.dataset.c);break;
      case 'link':if(MM.sel){MM.linking=MM.sel;mmCtx();toast('Click another node to link it.');}break;
      case 'cancel-link':MM.linking=null;mmCtx();break;
      case 'delete-link':{const l=MM.selLink;if(l){mmPush();m.links=m.links.filter(x=>x.id!==l);MM.selLink=null;mmReconcile(false);mmCtx();mmSaveSoon();}break;}
      case 'fold':if(MM.sel)mmToggleFold(MM.sel);break;
      case 'delete':if(MM.sel)mmDelete(MM.sel);break;
    }
  });
  document.addEventListener('submit',e=>{
    const f=e.target,id=f.getAttribute('id');
    if(id==='mmNewForm'){e.preventDefault();const fd=new FormData(f);mmCreate(String(fd.get('title')||'').trim(),String(fd.get('subjectId')||''),!!fd.get('topics'));closeModal();currentView='mindmap';playNext=true;render();toast('Mind map created.');}
    else if(id==='mmRenameForm'){e.preventDefault();const m=mmCur(),t=String(new FormData(f).get('title')||'').trim();if(m&&t){m.title=t.slice(0,80);m.updated=Date.now();save();closeModal();render();toast('Mind map renamed.');}}
    else if(id==='weeklyGoalForm'){e.preventDefault();const v=Math.max(0,Math.min(10080,Math.round(Number(new FormData(f).get('goal'))||0)));data.profile.weeklyGoal=v;save();render();toast(v?`Weekly goal set to ${fmtMin(v)}.`:'Weekly goal turned off.');}
  });
  document.addEventListener('change',e=>{if(e.target.id==='mmSelect')mmSwitch(e.target.value);});
  function openTopic(){modal('Add syllabus topic','Add a chapter or skill to track your progress.',`<div class="field"><label for="topicTitle">Topic name *</label><input id="topicTitle" name="title" required maxlength=120 placeholder="e.g. Quadratic equations"></div><div class="field"><label for="topicSubject">Subject *</label><select id="topicSubject" name="subjectId" required>${subjectOptions('')}</select></div><div class="field-row"><div class="field"><label for="topicDifficulty">Difficulty</label><select id="topicDifficulty" name="difficulty"><option>Easy</option><option selected>Medium</option><option>Hard</option></select></div><div class="field"><label for="topicStatus">Mastery</label><select id="topicStatus" name="status"><option>Not started</option><option>Learning</option><option selected>Practising</option><option>Mastered</option></select></div></div>`,'Add topic','topicForm');}
  function generateRevisionPlan(){const days=Math.max(1,Math.min(30,Number($('#revisionDays')?.value)||14)),minutes=Math.max(15,Math.min(120,Number($('#revisionMinutes')?.value)||40));const exams=data.exams.filter(e=>e.date>=todayISO()&&daysUntil(e.date)<=days).sort((a,b)=>a.date.localeCompare(b.date));if(!exams.length){toast('Add an upcoming exam within your selected planning window first.');return;}let created=0;const today=new Date(`${todayISO()}T12:00:00`);for(const exam of exams){const s=subject(exam.subjectId);const grade=s?gradeFor(s):null;let topics=(exam.topics||'').split(/[,;\n]+/).map(x=>x.trim()).filter(Boolean);if(!topics.length)topics=data.topics.filter(t=>t.subjectId===exam.subjectId&&t.status!=='Mastered').map(t=>t.title);if(!topics.length)topics=[`Review ${s?.name||'exam'} notes`,`Practice ${s?.name||'exam'} questions`];const weak=grade===null||grade<(s?.target??90);const until=Math.max(1,daysUntil(exam.date));const slots=Math.min(topics.length,Math.max(1,Math.min(6,until)));for(let i=0;i<slots;i++){const topic=topics[i];let date=new Date(`${exam.date}T12:00:00`);date.setDate(date.getDate()-Math.max(1,Math.round((slots-i)*(until/(slots+1)))));if(date<today)date=new Date(today);const iso=`${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`;const title=`${weak?'Priority revision':'Revision'}: ${topic}`;const duplicate=data.sessions.some(x=>x.generatedFor===exam.id&&x.title===title&&x.date===iso);if(duplicate)continue;data.sessions.push({id:uid(),title,subjectId:exam.subjectId||'',date:iso,minutes,reflection:`Generated from ${exam.title}. Topic: ${topic}. Adjust this session to fit your schedule.`,generatedFor:exam.id,generated:true});created++;}}save();render();toast(created?`${created} revision session${created===1?'':'s'} added to your local planner.`:'Matching revision sessions already exist.');}
  function renderSettings() {
    return `${heading('MAKE IT YOURS','Settings','Manage your academic profile, preferences, and data portability.') }<div class="grid settings-grid"><section class="panel settings-card"><h2>Academic profile</h2><p>These details personalize your workspace.</p><form id="profileForm"><div class="profile-editor"><div class="avatar profile-preview" id="profilePreview">${data.profile.avatar?`<img src="${data.profile.avatar}" alt="Profile picture">`:esc(initials(data.profile.name))}</div><div class="profile-editor-copy"><strong>Profile picture</strong><small>Choose a photo to personalize StudyOS. Stored locally on this device.</small><div class="profile-editor-actions"><label class="button tonal small" for="prefPfp">Choose photo</label><input id="prefPfp" type="file" accept="image/*" class="hidden"><button type="button" class="button outline small" data-action="remove-pfp" ${data.profile.avatar?'':'disabled'}>Remove</button></div></div></div><div class="field"><label for="prefName">Display name</label><input id="prefName" name="name" value="${esc(data.profile.name)}" maxlength="80" /></div><div class="field-row"><div class="field"><label for="prefYear">Year / level</label><input id="prefYear" name="year" value="${esc(data.profile.year)}" maxlength="60" /></div><div class="field"><label for="prefSchoolYear">Academic year</label><input id="prefSchoolYear" name="schoolYear" value="${esc(data.profile.schoolYear)}" maxlength="40" /></div></div><div class="field"><label for="prefTerm">Current term</label><input id="prefTerm" name="term" value="${esc(data.profile.term)}" maxlength="40" /></div><div class="field"><label for="prefTarget">Default target (%)</label><input id="prefTarget" name="target" type="number" min="0" max="100" step="1" value="${Number(data.profile.target)||90}" /></div><button class="button primary" type="submit">Save profile</button></form></section><section class="panel settings-card about-os"><div class="about-brand"><div class="brand-mark" data-logo></div><div><h2>StudyOS</h2><p>Academic productivity and study-planning workspace</p></div></div><div class="about-version"><span>Version</span><strong>4.4.0</strong></div><div class="developer-row"><a class="developer-profile-link" href="https://github.com/hunterHzl" target="_blank" rel="noopener noreferrer" aria-label="Visit HunterHz on GitHub"><img src="https://github.com/hunterHzl.png" alt="HunterHz GitHub profile picture"></a><div><small>Developed by</small><strong><a class="developer-name-link" href="https://github.com/hunterHzl" target="_blank" rel="noopener noreferrer">HunterHz</a></strong><small>GitHub profile</small></div></div><div class="divider"></div><div class="switch-row"><div><strong>Local workspace</strong><small>${data.subjects.length} subjects · ${data.tasks.length} tasks · ${data.exams.length} exams</small></div><span class="tag">v4.4.0</span></div></section><section class="panel settings-card"><h2>App preferences</h2><p>Keep StudyOS comfortable for your workflow.</p><div class="field"><label for="prefTheme">Appearance</label><select id="prefTheme"><option value="system" ${data.profile.theme==='system'?'selected':''}>System default</option><option value="light" ${data.profile.theme==='light'?'selected':''}>Light</option><option value="dark" ${data.profile.theme==='dark'?'selected':''}>Dark Moon</option></select><div class="hint">Dark Moon applies a full dark Material You palette across the app.</div></div><div class="field"><label>Adaptive accent palette</label><div class="swatch-grid" role="group" aria-label="Accent colour">${Object.entries(ACCENTS).map(([k,a])=>`<button type="button" class="swatch ${data.profile.accent===k?'active':''}" data-action="set-accent" data-accent="${k}" style="--sw:${hslHex(a.h,a.s+18,48)}" title="${esc(a.label)}" aria-label="${esc(a.label)}" aria-pressed="${data.profile.accent===k}"></button>`).join('')}<label class="swatch custom ${data.profile.accent==='custom'?'active':''}" title="Pick any colour" style="--sw:${esc(data.profile.customColor)}"><input type="color" id="prefCustom" value="${esc(data.profile.customColor)}" aria-label="Custom accent colour"><span aria-hidden="true">＋</span></label></div><div class="hint">Choose a preset or pick any colour. StudyOS derives coordinated light/dark surfaces, text contrast, cards and navigation colours from your accent.</div></div><div class="pref-sub">Animations</div><div class="switch-row"><div><strong>Disable Animations</strong><small>Turn off interface animations and transitions to improve responsiveness on lower-end devices.</small>${osReduceMotion()?'<small>Your device’s reduced-motion setting is on, so animations stay off.</small>':''}</div><label class="switch"><input id="prefAnimOff" type="checkbox" ${userAnimOff||osReduceMotion()?'checked':''} ${osReduceMotion()?'disabled':''}><span class="switch-track"></span></label></div><div class="switch-row"><div><strong>Pure black dark mode</strong><small>Deep black backgrounds for OLED screens (used in dark mode).</small></div><label class="switch"><input id="prefBlack" type="checkbox" ${data.profile.black?'checked':''}><span class="switch-track"></span></label></div><div class="field"><label for="prefWeek">Week starts on</label><select id="prefWeek"><option ${data.profile.weekStart==='Monday'?'selected':''}>Monday</option><option ${data.profile.weekStart==='Sunday'?'selected':''}>Sunday</option></select></div><div class="switch-row"><div><strong>Reminder preference</strong><small>Preference only; push notifications are not configured in this MVP.</small></div><label class="switch"><input id="prefReminders" type="checkbox" ${data.profile.reminders?'checked':''}><span class="switch-track"></span></label></div><div class="divider"></div><h2>Data & backup</h2><p>Your data is stored in this browser/device. Keep a backup before clearing browser data.</p><div class="grid" style="grid-template-columns:1fr 1fr;gap:9px"><button class="button tonal" data-action="export-data">↓ Export backup</button><button class="button outline" data-action="import-data">↑ Import backup</button></div><input type="file" id="importFile" accept="application/json,.json" class="hidden" /><div class="divider"></div><button class="button outline" data-action="reset-demo">Reset to sample data</button><button class="button danger" data-action="clear-data" style="margin-top:8px">Delete all local data</button></section><section class="panel settings-card"><h2>Storage and sync</h2><p>Current implementation status.</p><div class="switch-row"><div><strong>Local persistence</strong><small>Changes save automatically in this browser.</small></div><span class="status-pill graded">Active</span></div><div class="switch-row"><div><strong>Offline app shell</strong><small>Available after the service worker has cached the app.</small></div><span class="status-pill in-progress">PWA</span></div><div class="switch-row"><div><strong>Cloud account sync</strong><small>Intentionally excluded: StudyOS is local-only by design.</small></div><span class="status-pill">Local only</span></div><div class="switch-row"><div><strong>Push notifications</strong><small>Not implemented yet.</small></div><span class="status-pill">Not connected</span></div></section>
<section class="panel settings-card patch-notes"><h2>Patch Notes</h2><p>StudyOS · Version 4.4.0</p><div class="patch-group"><span class="patch-label">New · 4.4.0</span><ul><li>Disable Animations (Settings → App preferences): one switch for low-end devices that turns off every animation and transition immediately.</li><li>The timetable now starts blank and is fully editable: add, rename and remove periods and type your own lessons.</li><li>Streaks show as x7, x30… with a real flame whose colour changes at milestones.</li><li>New installs start with the Black + Grey palette (System light/dark). Existing palettes are untouched.</li></ul></div><div class="patch-group"><span class="patch-label">Improved · 4.4.0</span><ul><li>Home order: Daily study duration, Consistency &amp; productivity, then This week. The first two moved here from Insights.</li><li>Now Playing: the lyric window stays centred on the line being sung and the player keeps a fixed size (long lines end with …).</li><li>Phones: every section is reachable from the bottom bar’s More menu, nothing hides behind the bar, no sideways scrolling.</li><li>Sections reveal smoothly as you scroll down, once.</li></ul></div><div class="patch-group"><span class="patch-label">New · 4.3.6</span><ul><li>Mind Map tool in StudyOS Tools: infinite canvas, draggable nodes, animated links, collapsible branches, zoom and pan, undo/redo and automatic saving.</li><li>Insights now charts weekly activity, daily duration, session frequency, subject distribution, streaks, comparisons and goal completion from your own study logs.</li><li>Weekly study goal with progress rings.</li><li>The StudyOS logo adapts to your accent palette and favicon.</li></ul></div><div class="patch-group"><span class="patch-label">Improved · 4.3.6</span><ul><li>Home dashboard rebuilt: Study time this week now lives on Home, with a weekly activity chart and study streak. The 👋 emoji is gone.</li><li>Insights now shows Study sessions this week in place of study time.</li><li>Refreshed Material You surfaces, icons, spacing, shadows and micro-interactions across light and dark themes.</li></ul></div><div class="patch-group"><span class="patch-label">New</span><ul><li>Minimal Study Space with a distraction-free countdown timer.</li><li>Personalized loading screen with local-time greeting and profile.</li><li>About StudyOS page with version and developer credit.</li><li>Past Papers tracker with editable attempts, marks, timing, and review notes.</li></ul></div><div class="patch-group"><span class="patch-label">Improved</span><ul><li>Smoother navigation and reduced-motion-aware transitions.</li><li>Planner and personalization presentation consistency.</li><li>Clearer focus controls and responsive layout.</li><li>Past-paper attempt history with marks, timing, and topic reflections.</li><li>Consistent page, panel, button, and form micro-interactions.</li></ul></div><div class="patch-group"><span class="patch-label">Fixed</span><ul><li>Focus timer controls prevent duplicate intervals and reset reliably.</li><li>Past-paper scores are validated against maximum marks and kept separate from official grades.</li></ul></div><div class="patch-group"><span class="patch-label">New · 4.3</span><ul><li>StudyOS Tools Command Center with workspace search and shortcuts.</li><li>Academic Performance Center with assessment history and subject trends.</li><li>Examination Center with exam countdowns and syllabus mastery coverage.</li><li>Mistake Bank for incorrect answers, corrections, and error analysis.</li><li>Flashcard Studio with self-rated spaced-repetition scheduling.</li><li>Built-in and custom Formula Library.</li><li>Backup & Data Management dashboard with collection counts and integrity checks.</li></ul></div><div class="patch-group"><span class="patch-label">Improved · 4.3</span><ul><li>Revision generation controls now sit alongside exam-readiness information.</li><li>New records migrate safely into existing local data and are included in JSON backups.</li></ul></div><div class="patch-group"><span class="patch-label">Fixed · 4.3</span><ul><li>Backward-compatible defaults prevent older saved workspaces from missing new collections.</li></ul></div><div class="patch-group"><span class="patch-label">Improved · 4.3.2</span><ul><li>Hybrid HyperOS × ColorOS visual refinement across navigation, cards, controls and spacing.</li><li>Adaptive accent palette applies coordinated colours throughout light and dark themes.</li><li>Removed the “Saved on this device” sidebar banner so Settings remains accessible at shorter screen heights.</li><li>Animated focus timer ring, live progress, subtle digit transitions and completion feedback.</li></ul></div><div class="patch-group"><span class="patch-label">Improved · 4.3.2</span><ul><li>StudyOS brand in the top-left sidebar now returns directly to Home.</li><li>Study duration is user-adjustable from 1 to 180 minutes.</li><li>Break duration automatically follows a 1:3 ratio: 15 minutes of study gives 5 minutes of break; 30 gives 10.</li></ul></div><div class="patch-group"><span class="patch-label">New · 4.3.4</span><ul><li>Weekly Year 10 Engineering timetable with editable lesson cells.</li><li>Planner calendar now previews each weekday’s school subjects and shows the full lesson schedule for the selected date.</li></ul></div><div class="patch-group"><span class="patch-label">New · 4.3.3</span><ul><li>Compact Now Playing widget in the top bar, independent of Workspace navigation.</li><li>Floating lyrics panel with LRCLIB synced-lyrics support and online album artwork lookup.</li><li>Playback controls for foobar2000 through the optional local StudyOS bridge and Beefweb component.</li></ul></div></section></div>`;
  }
  function modal(title,subtitle,body,submitLabel='Save',formId='recordForm',wide=false) { $('#modalRoot').innerHTML=`<div class="modal-backdrop"><section class="modal" role="dialog" aria-modal="true" aria-label="${esc(title)}" style="${wide?'width:min(680px,100%)':''}"><div class="modal-header"><div><h2>${title}</h2><p>${subtitle||''}</p></div><button class="icon-button small" type="button" data-action="close-modal" aria-label="Close">×</button></div><form id="${formId}"><div class="modal-body">${body}</div><div class="modal-footer"><button type="button" class="button outline" data-action="close-modal">Cancel</button><button type="submit" class="button primary">${submitLabel}</button></div></form></section></div>`; const first=$('input:not([type=hidden]),select,textarea',$('#modalRoot')); if(first)setTimeout(()=>first.focus(),60); }
  const subjectOptions = selected => `<option value="">Choose a subject</option>${data.subjects.map(s=>`<option value="${s.id}" ${s.id===selected?'selected':''}>${esc(s.name)}</option>`).join('')}`;
  const subjectField = (selected='',required=true) => `<div class="field"><label for="fSubject">Subject${required?' *':''}</label><select id="fSubject" name="subjectId" ${required?'required':''}>${subjectOptions(selected)}</select></div>`;
  function openTask(id='',date='') { const t=data.tasks.find(x=>x.id===id)||{title:'',subjectId:'',due:date||todayISO(),priority:'Medium',status:'Not started',estimate:30,description:''};modal(id?'Edit assignment':'New assignment','Track the deadline, status, and effort.',`${id?`<input type="hidden" name="id" value="${id}">`:''}<div class="field"><label for="fTitle">Assignment title *</label><input id="fTitle" name="title" required maxlength="160" value="${esc(t.title)}" placeholder="e.g. Chapter 4 practice" /></div>${subjectField(t.subjectId,false)}<div class="field-row"><div class="field"><label for="fDue">Due date</label><input id="fDue" name="due" type="date" value="${esc(t.due||'')}" /></div><div class="field"><label for="fEstimate">Estimated minutes</label><input id="fEstimate" name="estimate" type="number" min="0" max="10080" value="${Number(t.estimate)||''}" /></div></div><div class="field-row"><div class="field"><label for="fPriority">Priority</label><select id="fPriority" name="priority">${['High','Medium','Low'].map(x=>`<option ${t.priority===x?'selected':''}>${x}</option>`).join('')}</select></div><div class="field"><label for="fStatus">Status</label><select id="fStatus" name="status">${['Not started','In progress','Submitted','Graded','Cancelled'].map(x=>`<option ${t.status===x?'selected':''}>${x}</option>`).join('')}</select></div></div><div class="field"><label for="fDesc">Instructions / notes</label><textarea id="fDesc" name="description" maxlength="3000" placeholder="What needs to be done?">${esc(t.description||'')}</textarea></div>`,id?'Save changes':'Add assignment'); }
  function openSubject(id='') { const s=data.subjects.find(x=>x.id===id)||{name:'',code:'',color:'#6750a4',target:Number(data.profile.target)||90,categories:[{name:'Exams',weight:60},{name:'Coursework',weight:25},{name:'Quizzes',weight:15}]};modal(id?'Edit subject':'Add subject','Set the target and assessment weighting for this subject.',`${id?`<input type="hidden" name="id" value="${id}">`:''}<div class="field"><label for="fName">Subject name *</label><input id="fName" name="name" required maxlength="100" value="${esc(s.name)}" placeholder="e.g. Mathematics" /></div><div class="field-row"><div class="field"><label for="fCode">Short code</label><input id="fCode" name="code" maxlength="12" value="${esc(s.code||'')}" placeholder="MATH" /></div><div class="field"><label for="fTarget">Target percentage</label><input id="fTarget" name="target" type="number" min="0" max="100" step="1" value="${Number(s.target)||90}" /></div></div><div class="field"><label for="fColor">Subject color</label><input id="fColor" name="color" type="color" value="${esc(s.color||'#6750a4')}" style="height:44px;padding:5px" /></div><div class="inline-note">After creating the subject, configure assessment categories from <strong>Academics → Grade settings</strong>. Categories without graded work are excluded from the current average rather than treated as zero.</div>`,id?'Save subject':'Add subject'); }
  function openAssessment(id='',presetSubject='') { const a=data.assessments.find(x=>x.id===id)||{title:'',subjectId:presetSubject,category:'Exams',score:'',maxScore:100,date:todayISO(),weight:1};modal(id?'Edit assessment':'Record a grade','Enter the mark exactly as it was awarded.',`${id?`<input type="hidden" name="id" value="${id}">`:''}<div class="field"><label for="fTitle">Assessment name *</label><input id="fTitle" name="title" required maxlength="160" value="${esc(a.title)}" placeholder="e.g. Unit test" /></div>${subjectField(a.subjectId)}<div class="field"><label for="fCategory">Category *</label><select id="fCategory" name="category" required>${(()=>{const s=subject(a.subjectId),cats=s?.categories||[{name:'Exams'},{name:'Coursework'},{name:'Quizzes'}];const names=[...new Set([...cats.map(c=>c.name),a.category].filter(Boolean))];return names.map(c=>`<option ${a.category===c?'selected':''}>${esc(c)}</option>`).join('')})()}</select><div class="hint">If you change the subject, choose a category configured for that subject.</div></div><div class="field-row"><div class="field"><label for="fScore">Score earned *</label><input id="fScore" name="score" required type="number" min="0" step="any" value="${esc(a.score)}" /></div><div class="field"><label for="fMax">Maximum score *</label><input id="fMax" name="maxScore" required type="number" min="0.01" step="any" value="${esc(a.maxScore)}" /></div></div><div class="field"><label for="fDate">Assessment date</label><input id="fDate" name="date" type="date" value="${esc(a.date||todayISO())}" /></div><div class="inline-note">Current grades use your subject's configured category weights. This mark is saved to the official gradebook; hypothetical marks belong in a separate simulator (not included in this MVP).</div>`,id?'Save grade':'Record grade'); }
  function openExam(id='',date='') { const e=data.exams.find(x=>x.id===id)||{title:'',subjectId:'',date:date||addDays(7),time:'09:00',topics:'',notes:''};modal(id?'Edit exam':'Add exam','Keep the date and revision topics together.',`${id?`<input type="hidden" name="id" value="${id}">`:''}<div class="field"><label for="fTitle">Exam title *</label><input id="fTitle" name="title" required maxlength="160" value="${esc(e.title)}" placeholder="e.g. Physics end-of-unit test" /></div>${subjectField(e.subjectId,false)}<div class="field-row"><div class="field"><label for="fDate">Exam date *</label><input id="fDate" name="date" type="date" required value="${esc(e.date)}" /></div><div class="field"><label for="fTime">Start time</label><input id="fTime" name="time" type="time" value="${esc(e.time||'')}" /></div></div><div class="field"><label for="fTopics">Topics / syllabus</label><textarea id="fTopics" name="topics" maxlength="3000" placeholder="List topics to revise">${esc(e.topics||'')}</textarea></div><div class="field"><label for="fNotes">Materials and notes</label><textarea id="fNotes" name="notes" maxlength="2000" placeholder="Calculator, formula sheet, room…">${esc(e.notes||'')}</textarea></div>`,id?'Save exam':'Add exam'); }
  function openSession(id='',date='') { const s=data.sessions.find(x=>x.id===id)||{title:'',subjectId:'',date:date||todayISO(),minutes:25,reflection:''};modal(id?'Edit study log':'Log a study session','Record focused time for your academic review.',`${id?`<input type="hidden" name="id" value="${esc(id)}">`:''}<div class="field"><label for="fTitle">Session title</label><input id="fTitle" name="title" maxlength="120" value="${esc(s.title||'')}" placeholder="e.g. Revise algebra" /></div>${subjectField(s.subjectId||'',false)}<div class="field-row"><div class="field"><label for="fDate">Date *</label><input id="fDate" name="date" type="date" required value="${esc(s.date||todayISO())}" /></div><div class="field"><label for="fMinutes">Minutes studied *</label><input id="fMinutes" name="minutes" type="number" min="1" max="1440" required value="${Number(s.minutes)||25}" /></div></div><div class="field"><label for="fReflection">Reflection (optional)</label><textarea id="fReflection" name="reflection" maxlength="1000" placeholder="What did you cover? What needs another review?">${esc(s.reflection||'')}</textarea></div>`,id?'Save changes':'Save session'); }
  function openScheme(id) { const s=subject(id);if(!s)return; const cats=s.categories||[];modal(`Grade settings · ${esc(s.name)}`,'Set the weighting used by this subject’s current-grade calculation.',`<input type="hidden" name="id" value="${id}"><div class="inline-note">Category weights should total 100%. The current grade is normalized over categories with graded marks. Categories with no graded marks are excluded.</div><div id="categoryFields" style="margin-top:16px">${cats.map((c,i)=>`<div class="field-row category-row"><div class="field"><label>Category ${i+1}</label><input name="catName${i}" required maxlength="50" value="${esc(c.name)}"></div><div class="field"><label>Weight (%)</label><input name="catWeight${i}" required type="number" min="0" max="100" step="any" value="${Number(c.weight)}"></div></div>`).join('')}</div><button class="button outline small" type="button" data-action="add-category-row">＋ Add category</button><div class="field" style="margin-top:14px"><label for="fUnweighted">Calculation mode</label><select id="fUnweighted" name="scheme"><option value="weighted" ${s.scheme!=='unweighted'?'selected':''}>Weighted categories</option><option value="unweighted" ${s.scheme==='unweighted'?'selected':''}>Unweighted average of all assessments</option></select></div>`, 'Save settings','schemeForm'); }
  function openQuickAdd() { modal('Quick add','What do you want to add?',`<div class="grid" style="grid-template-columns:1fr 1fr;gap:10px"><button type="button" class="button tonal" data-action="quick-modal" data-kind="add-task">✓ Assignment</button><button type="button" class="button tonal" data-action="quick-modal" data-kind="add-assessment">％ Grade</button><button type="button" class="button tonal" data-action="quick-modal" data-kind="add-exam">▦ Exam</button><button type="button" class="button tonal" data-action="quick-modal" data-kind="add-subject">▤ Subject</button><button type="button" class="button tonal" data-action="quick-modal" data-kind="add-session">◷ Study session</button></div>`,'','quickForm'); $('#quickForm .modal-footer').classList.add('hidden'); }
  function closeModal(){ $('#modalRoot').innerHTML=''; }
  function editProfileModal(){ currentView='settings';render();$('#prefName')?.focus(); }
  function setView(view){closeModal();currentView=view;playNext=true;window.scrollTo(0,0);render();$('#content').focus({preventScroll:true});if(window.innerWidth<=760)$('#sidebarOverlay')?.remove();}
  function cycleTask(id){const t=data.tasks.find(x=>x.id===id);if(!t)return;const order=['Not started','In progress','Submitted','Graded'];t.status=order[(order.indexOf(t.status)+1)%order.length];save();render();toast(`Task marked ${t.status.toLowerCase()}.`);}
  function confirmDialog(message,confirmLabel,onConfirm,danger=true){
    const old=document.getElementById('confirmRoot');if(old)old.remove();
    const root=document.createElement('div');root.id='confirmRoot';root.className='modal-backdrop confirm-backdrop';
    root.innerHTML=`<section class="modal confirm-modal" role="alertdialog" aria-modal="true" aria-label="Please confirm"><div class="modal-body"><h2 class="confirm-title">Are you sure?</h2><p class="confirm-text">${esc(message)}</p></div><div class="modal-footer"><button type="button" class="button outline" data-confirm="no">Cancel</button><button type="button" class="button ${danger?'danger':'primary'}" data-confirm="yes">${esc(confirmLabel||'Confirm')}</button></div></section>`;
    document.body.appendChild(root);
    const onKey=e=>{if(e.key==='Escape'){e.stopPropagation();close();}};
    const close=()=>{root.remove();document.removeEventListener('keydown',onKey,true);};
    root.addEventListener('click',e=>{e.stopPropagation();const b=e.target.closest('[data-confirm]');if(b){const yes=b.dataset.confirm==='yes';close();if(yes)onConfirm();}else if(e.target===root)close();});
    document.addEventListener('keydown',onKey,true);
    setTimeout(()=>{const n=root.querySelector('[data-confirm="no"]');if(n)n.focus();},30);
  }
  function countUp(){
    if(reduceMotion())return;
    $$('#content .stat-value,#content .subject-card-grade,#content .subject-grade').forEach(el=>{
      const n=el.firstChild;if(!n||n.nodeType!==3)return;
      const m=n.textContent.trim().match(/^(\d+(?:\.\d+)?)(%?)$/);if(!m)return;
      const end=parseFloat(m[1]),dec=(m[1].split('.')[1]||'').length,suf=m[2],t0=performance.now(),dur=950;
      n.textContent=(0).toFixed(dec)+suf;
      const step=now=>{const p=Math.min(1,(now-t0)/dur),e=1-Math.pow(1-p,3);if(!n.isConnected)return;if(p<1){n.textContent=(end*e).toFixed(dec)+suf;requestAnimationFrame(step);}else n.textContent=m[1]+suf;};
      requestAnimationFrame(step);
    });
  }
  function playEnter(){
    if(reduceMotion())return;
    const c=$('#content');if(!c)return;let i=0;
    $$('.page-heading,.stat-card,.panel,.subject-card,.toolbar,.table-wrap',c).forEach(el=>el.style.setProperty('--i',Math.min(i++,10)));
    revealSetup(c);c.classList.remove('anim');void c.offsetWidth;c.classList.add('anim');countUp();
  }
  /* Scroll reveal: blocks that start below the fold stay hidden until they scroll into view, then play the same entrance
     animation once. No timers, nothing re-triggers on scroll back, keyboard focus reveals instantly, printing shows everything. */
  function revealSetup(c){
    if(revealIO){revealIO.disconnect();revealIO=null;}
    if(animationsOff()||!('IntersectionObserver' in window))return;
    const sel='.page-heading,.stat-card,.panel,.subject-card,.toolbar,.table-wrap,.dash-hero';
    const vh=window.innerHeight||document.documentElement.clientHeight;
    const pend=$$(sel,c).filter(el=>!el.parentElement.closest(sel)&&el.getBoundingClientRect().top>vh*.9);
    if(!pend.length)return;
    const show=el=>{if(!el.classList.contains('rv'))return;revealIO&&revealIO.unobserve(el);revealPend=revealPend.filter(x=>x!==el);el.style.setProperty('--i',0);el.classList.remove('rv');};
    revealIO=new IntersectionObserver(es=>{es.forEach(en=>{if(en.isIntersecting)show(en.target);});},{rootMargin:'0px 0px -6% 0px',threshold:.04});
    revealPend=pend.slice();
    pend.forEach(el=>{el.classList.add('rv');revealIO.observe(el);});
    if(!revealWired){revealWired=true;
      let raf=0;const sweep=()=>{raf=0;const lim=(window.innerHeight||0)*.94;revealPend.slice().forEach(el=>{if(el.getBoundingClientRect().top<lim)show(el);});};
      window.addEventListener('scroll',()=>{if(revealPend.length&&!raf)raf=requestAnimationFrame(sweep);},{passive:true});
      c.addEventListener('focusin',e=>{const t=e.target.closest&&e.target.closest('.rv');if(t)show(t);});
      window.addEventListener('beforeprint',clearReveal);}
    revealShow=show;
  }
  function endSplash(){
    if(!splashActive)return;splashActive=false;playNext=false;
    const sp=$('#splash');if(sp){sp.classList.add('leaving');setTimeout(()=>sp.remove(),700);}
    playEnter();
  }
  function deleteItem(kind,id){const names={task:'assignment',assessment:'assessment',exam:'exam',subject:'subject',session:'study log'},label=names[kind]||'item';
    if(kind==='subject'&&(data.assessments.some(x=>x.subjectId===id)||data.tasks.some(x=>x.subjectId===id)||data.exams.some(x=>x.subjectId===id))){toast('This subject has linked records. Reassign or remove those records first.');return;}
    confirmDialog(`Delete this ${label}? This cannot be undone.`,'Delete',()=>{
      if(kind==='task')data.tasks=data.tasks.filter(x=>x.id!==id);
      if(kind==='assessment')data.assessments=data.assessments.filter(x=>x.id!==id);
      if(kind==='exam')data.exams=data.exams.filter(x=>x.id!==id);
      if(kind==='session')data.sessions=data.sessions.filter(x=>x.id!==id);
      if(kind==='subject')data.subjects=data.subjects.filter(x=>x.id!==id);
      save();render();toast(`${label[0].toUpperCase()+label.slice(1)} deleted.`);
    });
  }
  function downloadBlob(blob,name){const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);}
  function exportData(){downloadBlob(new Blob([JSON.stringify({...data,exportedAt:new Date().toISOString(),format:'StudyOS backup v1'},null,2)],{type:'application/json'}),`studyos-backup-${todayISO()}.json`);toast('Backup exported. Keep it somewhere safe.');}
  function importData(file){const r=new FileReader();r.onload=()=>{try{const parsed=JSON.parse(r.result);if(!parsed||!Array.isArray(parsed.subjects)||!Array.isArray(parsed.tasks)||!parsed.profile)throw Error('This does not look like a StudyOS backup.');confirmDialog('Replace the current local StudyOS data with this backup? Export your current data first if you need it.','Replace data',()=>{data={...defaultData(),...parsed};delete data.exportedAt;delete data.format;normalize();save();render();toast('Backup imported successfully.');});}catch(e){toast(e.message||'Could not import that file.');}};r.readAsText(file);}
  function handleAction(el){const a=el.dataset.action,id=el.dataset.id;
    switch(a){case 'insight-range':insightRange=[7,30,90].includes(Number(el.dataset.range))?Number(el.dataset.range):30;playNext=false;render();break;case 'close-modal':closeModal();break;case 'remove-pfp':data.profile.avatar='';save();render();toast('Profile picture removed.');break;case 'quick-add':openQuickAdd();break;case 'add-task':closeModal();openTask('',el.dataset.date||'');break;case 'edit-task':openTask(id);break;case 'delete-task':deleteItem('task',id);break;case 'cycle-task':cycleTask(id);break;case 'add-subject':closeModal();openSubject();break;case 'edit-subject':openSubject(id);break;case 'add-assessment':closeModal();openAssessment('',el.dataset.subject||'');break;case 'edit-assessment':openAssessment(id);break;case 'delete-assessment':deleteItem('assessment',id);break;case 'add-exam':closeModal();openExam('',el.dataset.date||'');break;case 'edit-exam':openExam(id);break;case 'delete-exam':deleteItem('exam',id);break;case 'add-session':closeModal();openSession('',el.dataset.date||'');break;case 'edit-session':openSession(id);break;case 'delete-session':deleteItem('session',id);break;
    case 'edit-past-paper':pastPaperEditingId=id;currentView='pastpapers';playNext=true;render();$('#ppTitle')?.focus();break;case 'cancel-edit-paper':pastPaperEditingId='';render();break;case 'delete-past-paper':{const p=data.pastPapers.find(x=>x.id===id);if(!p)break;confirmDialog(`Delete the ${p.title||'past paper'} attempt?`,'Delete attempt',()=>{data.pastPapers=data.pastPapers.filter(x=>x.id!==id);if(pastPaperEditingId===id)pastPaperEditingId='';save();render();toast('Past paper attempt deleted.');});break;}
    case 'add-mistake':closeModal();openToolForm('mistake');break;case 'add-flashcard':closeModal();openToolForm('flashcard');break;case 'add-formula':closeModal();openToolForm('formula');break;
    case 'delete-mistake':confirmDialog('Delete this mistake-bank entry?','Delete',()=>{data.mistakes=data.mistakes.filter(x=>x.id!==id);save();render();toast('Mistake removed.');});break;
    case 'delete-formula':confirmDialog('Delete this formula?','Delete',()=>{data.formulas=data.formulas.filter(x=>x.id!==id);save();render();toast('Formula removed.');});break;
    case 'review-card':{const c=data.flashcards.find(x=>x.id===id);if(!c)break;const rating=el.dataset.rating;let interval=Number(c.interval)||0,ease=Number(c.ease)||2.5,reps=Number(c.repetitions)||0;if(rating==='again'){interval=1;reps=0;}else if(rating==='hard'){interval=Math.max(1,Math.round((interval||1)*1.2));ease=Math.max(1.3,ease-0.15);reps++;}else{interval=reps===0?1:reps===1?3:Math.max(1,Math.round((interval||3)*ease));ease=Math.min(3,ease+0.05);reps++;}const d=new Date(`${todayISO()}T12:00:00`);d.setDate(d.getDate()+interval);c.interval=interval;c.ease=ease;c.repetitions=reps;c.nextReview=d.toISOString().slice(0,10);save();render();toast(`Card scheduled for ${fmtDate(c.nextReview)}.`);break;}
    case 'validate-data':{const checks=['subjects','assessments','tasks','exams','sessions','topics','pastPapers','mistakes','flashcards','formulas'];const bad=checks.filter(k=>!Array.isArray(data[k]));const dup=checks.flatMap(k=>{const ids=data[k].map(x=>x.id).filter(Boolean);return ids.length!==new Set(ids).size?[k]:[];});toast(bad.length||dup.length?`Check found issues: ${[...bad,...dup].join(', ')}`:'Data check passed. Collections and record IDs look consistent.');break;}
    case 'open-menu':openNavMenu();break;case 'toggle-timetable-edit':timetableEditing=!timetableEditing;render();break;case 'timetable-add-period':{const n=data.schoolTimetable.slots.length;data.schoolTimetable.slots.push({time:'',subjects:data.schoolTimetable.days.map(()=>'')});timetableEditing=true;save();render();const t=document.querySelector(`[data-timetable-time="${n}"]`);if(t)t.focus();break;}case 'timetable-remove-period':{const idx=Number(id);if(!data.schoolTimetable.slots[idx])break;confirmDialog('Remove this period and its lessons from your timetable?','Remove',()=>{data.schoolTimetable.slots.splice(idx,1);save();render();});break;}
    case 'select-day':{const d=el.dataset.date;if(!d)break;selectedDay=d;const p=d.split('-').map(Number);selectedYear=p[0];selectedMonth=p[1]-1;render();const cell=$(`.calendar-day[data-date="${d}"]`);if(cell)cell.focus({preventScroll:true});break;}
    case 'clear-logs':if(!data.sessions.length){toast('There are no logs to clear.');break;}confirmDialog(`Delete all ${data.sessions.length} study log${data.sessions.length===1?'':'s'}? This cannot be undone.`,'Clear all logs',()=>{data.sessions=[];save();render();toast('All study logs cleared.');});break;
    case 'clear-generated':{const n=data.sessions.filter(x=>x.generated).length;if(!n){toast('No revision plan sessions to remove.');break;}confirmDialog(`Remove ${n} generated revision session${n===1?'':'s'}? Sessions you logged yourself are kept.`,'Remove plan',()=>{data.sessions=data.sessions.filter(x=>!x.generated);save();render();toast('Revision plan removed.');});break;}
    case 'set-accent':{const k=el.dataset.accent;if(ACCENTS[k]){data.profile.accent=k;save();applyAppearance();render();toast(`${ACCENTS[k].label} accent applied.`);}break;}case 'add-topic':closeModal();openTopic();break;case 'delete-topic':confirmDialog('Remove this syllabus topic?','Remove',()=>{data.topics=data.topics.filter(t=>t.id!==id);save();render();toast('Topic removed.');});break;case 'generate-revision':generateRevisionPlan();break;case 'academic-tab':academicTab=el.dataset.tab;playNext=true;render();break;case 'edit-scheme':openScheme(id);break;case 'add-category-row':{const wrap=$('#categoryFields');const n=$$('.category-row',wrap).length;const row=document.createElement('div');row.className='field-row category-row';row.innerHTML=`<div class="field"><label>Category ${n+1}</label><input name="catName${n}" required maxlength="50" placeholder="Category name"></div><div class="field"><label>Weight (%)</label><input name="catWeight${n}" required type="number" min="0" max="100" step="any" value="0"></div>`;wrap.appendChild(row);break;}case 'quick-modal':{const k=el.dataset.kind;closeModal();if(k==='add-task')openTask();if(k==='add-assessment')openAssessment();if(k==='add-exam')openExam();if(k==='add-subject')openSubject();if(k==='add-session')openSession();break;}case 'subject-details':academicTab='grades';currentView='academics';playNext=true;render();break;case 'month-prev':selectedMonth--;if(selectedMonth<0){selectedMonth=11;selectedYear--;}render();break;case 'month-next':selectedMonth++;if(selectedMonth>11){selectedMonth=0;selectedYear++;}render();break;case 'month-today':selectedMonth=new Date().getMonth();selectedYear=new Date().getFullYear();selectedDay=todayISO();render();break;case 'export-data':exportData();break;case 'import-data':$('#importFile')?.click();break;case 'reset-demo':confirmDialog('Replace all local data with the original sample workspace?','Restore sample',()=>{data=defaultData();normalize();save();render();toast('Sample workspace restored.');});break;case 'clear-data':confirmDialog('Permanently delete all StudyOS data saved in this browser? Export a backup first if needed.','Delete everything',()=>{data={profile:{name:'Student',year:'',schoolYear:'',term:'',grading:'percentage',target:90,theme:'system',weekStart:'Monday',reminders:false},subjects:[],assessments:[],tasks:[],exams:[],sessions:[],notes:[],events:[],flashcards:[],mistakes:[],formulas:[],pastPapers:[],topics:[],settings:{sampleData:false}};normalize();save();render();toast('Local data cleared.');});break;}
  }
  document.addEventListener('click',e=>{
    const nav=e.target.closest('[data-view]');if(nav){e.preventDefault();if(nav.dataset.mapId){MM.id=nav.dataset.mapId;MM.sel=null;if(data.settings)data.settings.mmActive=MM.id;}setView(nav.dataset.view);return;}
    const act=e.target.closest('[data-action]');if(act){e.preventDefault();if(act.dataset.action==='focus-toggle'){toggleFocus();return;}if(act.dataset.action==='focus-reset'){resetFocus();return;}handleAction(act);return;}
    if(e.target.classList.contains('modal-backdrop'))closeModal();
  });
  document.addEventListener('submit',e=>{
    const form=e.target,formId=form.getAttribute('id');if(formId==='pastPaperForm'){e.preventDefault();const fd=new FormData(form),id=String(fd.get('id')||''),scoreRaw=String(fd.get('score')||'').trim(),maxScore=Number(fd.get('maxScore'));if(!Number.isFinite(maxScore)||maxScore<=0){toast('Maximum marks must be greater than zero.');return;}const score=scoreRaw===''?null:Number(scoreRaw);if(score!==null&&(!Number.isFinite(score)||score<0||score>maxScore)){toast('Score must be between zero and the maximum marks.');return;}const obj={id:id||uid(),title:String(fd.get('title')||'').trim(),subjectId:String(fd.get('subjectId')||''),board:String(fd.get('board')||'').trim(),qualification:String(fd.get('qualification')||'').trim(),year:String(fd.get('year')||'').trim(),session:String(fd.get('session')||''),paperCode:String(fd.get('paperCode')||'').trim(),date:String(fd.get('date')||todayISO()),minutes:Math.max(0,Number(fd.get('minutes'))||0),score,maxScore,difficulty:String(fd.get('difficulty')||'Moderate'),topics:String(fd.get('topics')||'').trim(),reflection:String(fd.get('reflection')||'').trim()};if(id)data.pastPapers=data.pastPapers.map(x=>x.id===id?obj:x);else data.pastPapers.push(obj);pastPaperEditingId='';save();render();toast(id?'Past paper attempt updated.':'Past paper attempt saved.');return;}if(formId==='recordForm'){
      e.preventDefault();const fd=new FormData(form),id=fd.get('id');
      if(form.querySelector('#fDue')&&form.querySelector('#fPriority')){const obj={id:id||uid(),title:String(fd.get('title')).trim(),subjectId:fd.get('subjectId')||'',due:fd.get('due')||'',estimate:Number(fd.get('estimate'))||0,priority:fd.get('priority')||'Medium',status:fd.get('status')||'Not started',description:String(fd.get('description')||'').trim(),createdAt:id?(data.tasks.find(x=>x.id===id)?.createdAt||todayISO()):todayISO()};if(id)data.tasks=data.tasks.map(x=>x.id===id?obj:x);else data.tasks.push(obj);save();closeModal();render();toast(id?'Assignment updated.':'Assignment added.');return;}
      if(form.querySelector('#fColor')){const obj={id:id||uid(),name:String(fd.get('name')).trim(),code:String(fd.get('code')||'').trim().toUpperCase(),color:fd.get('color')||'#6750a4',target:Number(fd.get('target'))||90,scheme:'weighted',categories:[{name:'Exams',weight:60},{name:'Coursework',weight:25},{name:'Quizzes',weight:15}]};if(id){const old=subject(id);obj.scheme=old.scheme;obj.categories=old.categories;data.subjects=data.subjects.map(x=>x.id===id?obj:x);}else data.subjects.push(obj);save();closeModal();render();toast(id?'Subject updated.':'Subject added.');return;}
      if(form.querySelector('#fScore')){const score=Number(fd.get('score')),maxScore=Number(fd.get('maxScore'));if(maxScore<=0||score<0||score>maxScore){toast('Enter a score from 0 up to the maximum score.');return;}const obj={id:id||uid(),title:String(fd.get('title')).trim(),subjectId:fd.get('subjectId'),category:fd.get('category'),score,maxScore,date:fd.get('date')||todayISO(),weight:1};if(id)data.assessments=data.assessments.map(x=>x.id===id?obj:x);else data.assessments.push(obj);save();closeModal();render();toast(id?'Grade updated.':'Grade recorded.');return;}
      if(form.querySelector('#fTopics')){const obj={id:id||uid(),title:String(fd.get('title')).trim(),subjectId:fd.get('subjectId')||'',date:fd.get('date'),time:fd.get('time')||'',topics:String(fd.get('topics')||'').trim(),notes:String(fd.get('notes')||'').trim()};if(id)data.exams=data.exams.map(x=>x.id===id?obj:x);else data.exams.push(obj);save();closeModal();render();toast(id?'Exam updated.':'Exam added.');return;}
      if(form.querySelector('#fMinutes')){const obj={id:id||uid(),title:String(fd.get('title')||'').trim(),subjectId:fd.get('subjectId')||'',date:fd.get('date'),minutes:Number(fd.get('minutes')),reflection:String(fd.get('reflection')||'').trim()};if(id)data.sessions=data.sessions.map(x=>x.id===id?{...x,...obj}:x);else data.sessions.push(obj);save();closeModal();render();toast(id?'Study log updated.':'Study session logged.');return;}
    }
    if(formId==='mistakeForm'){e.preventDefault();const fd=new FormData(form);data.mistakes.unshift({id:uid(),title:String(fd.get('title')).trim(),subjectId:fd.get('subjectId')||'',topic:String(fd.get('topic')||'').trim(),wrong:String(fd.get('wrong')||'').trim(),correct:String(fd.get('correct')).trim(),reason:String(fd.get('reason')||'').trim(),status:'Review',createdAt:new Date().toISOString()});save();closeModal();render();toast('Mistake saved to your bank.');return;}
    if(formId==='flashcardForm'){e.preventDefault();const fd=new FormData(form);data.flashcards.push({id:uid(),front:String(fd.get('front')).trim(),back:String(fd.get('back')).trim(),subjectId:fd.get('subjectId')||'',deck:String(fd.get('deck')||'').trim(),interval:0,ease:2.5,repetitions:0,nextReview:todayISO(),createdAt:todayISO()});save();closeModal();render();toast('Flashcard created.');return;}
    if(formId==='formulaForm'){e.preventDefault();const fd=new FormData(form);data.formulas.push({id:uid(),title:String(fd.get('title')).trim(),subjectId:fd.get('subjectId')||'',topic:String(fd.get('topic')||'').trim(),expression:String(fd.get('expression')).trim(),notes:String(fd.get('notes')||'').trim()});save();closeModal();render();toast('Formula saved.');return;}
    if(formId==='topicForm'){e.preventDefault();const fd=new FormData(form);data.topics.push({id:uid(),title:String(fd.get('title')).trim(),subjectId:fd.get('subjectId'),difficulty:fd.get('difficulty')||'Medium',status:fd.get('status')||'Not started'});save();closeModal();academicTab='mastery';render();toast('Syllabus topic added.');return;}
    if(formId==='targetSimulator'){e.preventDefault();const fd=new FormData(form),current=Number(fd.get('current')),target=Number(fd.get('target')),completed=Number(fd.get('completed')),remaining=100-completed,out=$('#simResult');if(!Number.isFinite(current)||!Number.isFinite(target)||!Number.isFinite(completed)||current<0||current>100||target<0||target>100||completed<0||completed>=100){if(out)out.textContent='Enter valid percentages. Completed weight must be from 0 to less than 100.';return;}const required=(target-current*completed/100)/(remaining/100);if(!out)return;if(required<=0)out.innerHTML=`Target already secured under these assumptions. The remaining score needed is 0%.`;else if(required>100)out.innerHTML=`<strong>Target not mathematically reachable.</strong><br>Required remaining mark: ${Math.round(required*10)/10}%. Even 100% on remaining work would produce ${Math.round((current*completed/100+remaining)*10)/10}%.`;else out.innerHTML=`<strong>Required mark: ${Math.round(required*10)/10}%</strong><br>Assuming your current ${Math.round(current*10)/10}% represents the completed ${completed}% of the final grade, you need ${Math.round(required*10)/10}% on the remaining ${remaining}% to finish at ${target}%.<br><span class="muted">This is a hypothetical estimate and does not change your gradebook.</span>`;return;}
    if(formId==='schemeForm') {e.preventDefault();const fd=new FormData(form),id=fd.get('id'),s=subject(id);if(!s)return;const cats=[];for(let i=0;i<100;i++){const name=fd.get(`catName${i}`);if(name===null)break;const weight=Number(fd.get(`catWeight${i}`));if(!String(name).trim()||!Number.isFinite(weight)||weight<0||weight>100){toast('Check category names and weights.');return;}cats.push({name:String(name).trim(),weight});}if(!cats.length){toast('Add at least one category.');return;}const sum=cats.reduce((n,c)=>n+c.weight,0);const commit=()=>{s.categories=cats;s.scheme=fd.get('scheme');save();closeModal();render();toast('Grade settings saved.');};if(fd.get('scheme')!=='unweighted'&&Math.abs(sum-100)>0.01){confirmDialog(`These weights total ${sum}%, not 100%. Save anyway?`,'Save anyway',commit,false);return;}commit();return;}
    if(formId==='profileForm'){e.preventDefault();const fd=new FormData(form);data.profile={...data.profile,name:String(fd.get('name')||'Student').trim()||'Student',year:String(fd.get('year')||'').trim(),schoolYear:String(fd.get('schoolYear')||'').trim(),term:String(fd.get('term')||'').trim(),target:Math.max(0,Math.min(100,Number(fd.get('target'))||90))};save();render();toast('Profile saved.');return;}
  });
  document.addEventListener('input',e=>{if(e.target.id==='toolSearch'){const box=$('#toolSearchResults');if(box)box.innerHTML=renderToolSearch(e.target.value);return;}if(e.target.id==='prefCustom'){data.profile.accent='custom';data.profile.customColor=e.target.value;applyAppearance();$$('.swatch').forEach(x=>x.classList.toggle('active',x.classList.contains('custom')));const sw=e.target.closest('.swatch');if(sw)sw.style.setProperty('--sw',e.target.value);return;}if(e.target.id==='taskSearch'){taskSearch=e.target.value;const pos=e.target.selectionStart;render();const input=$('#taskSearch');if(input){input.focus();input.setSelectionRange(pos,pos);}}if(e.target.id==='assessmentSearch'){const q=e.target.value.toLowerCase();$$('[data-assessment-row]').forEach(row=>row.classList.toggle('hidden',!row.textContent.toLowerCase().includes(q)));}});
  document.addEventListener('change',e=>{if(e.target.matches('[data-timetable-slot]')){const si=Number(e.target.dataset.timetableSlot),di=Number(e.target.dataset.timetableDay);if(data.schoolTimetable.slots[si]&&di>=0&&di<5){data.schoolTimetable.slots[si].subjects[di]=e.target.value.trim();save();toast('Timetable updated.');}return;}if(e.target.matches('[data-timetable-time]')){const si=Number(e.target.dataset.timetableTime);if(data.schoolTimetable.slots[si]){data.schoolTimetable.slots[si].time=e.target.value.trim();save();toast('Timetable updated.');}return;}if(e.target.id==='focusSubject'){focusSubjectId=e.target.value;}if(e.target.id==='focusMode'){focusMode=e.target.value;focusSeconds=focusTotalSeconds();focusRunning=false;clearInterval(focusInterval);focusInterval=null;render();}if(e.target.id==='focusDuration'){const raw=Number(e.target.value);if(!Number.isFinite(raw)||raw<1||raw>180){toast('Choose a study duration from 1 to 180 minutes.');e.target.value=focusMinutes;return;}focusMinutes=Math.round(raw);focusSeconds=focusTotalSeconds();focusRunning=false;clearInterval(focusInterval);focusInterval=null;render();}if(e.target.id==='taskFilter'){taskFilter=e.target.value;render();}if(e.target.id==='paperSubjectFilter'){const v=e.target.value;$$('[data-paper-row]').forEach(r=>r.classList.toggle('hidden',v!=='all'&&r.dataset.subject!==v));}if(e.target.id==='masterySubjectFilter'){const v=e.target.value;$$('[data-topic-row]').forEach(r=>r.classList.toggle('hidden',v!=='all'&&r.dataset.subject!==v));}if(e.target.matches('[data-topic-status]')){const t=data.topics.find(x=>x.id===e.target.dataset.topicStatus);if(t){t.status=e.target.value;save();toast('Topic mastery updated.');}}if(e.target.id==='simSubject'){const s=subject(e.target.value),g=s?gradeFor(s):null;const inp=$('#simCurrent');if(inp&&g!==null)inp.value=Math.round(g*10)/10;}if(e.target.id==='prefTheme'){data.profile.theme=e.target.value;save();applyAppearance();toast(e.target.value==='dark'?'Dark Moon enabled.':'Appearance updated.');}if(e.target.id==='toolSearch'){const box=$('#toolSearchResults');if(box)box.innerHTML=renderToolSearch(e.target.value);return;}if(e.target.id==='prefCustom'){save();toast('Custom colour saved.');}if(e.target.id==='prefBlack'){data.profile.black=e.target.checked;save();applyAppearance();toast(e.target.checked?'Pure black enabled.':'Pure black off.');}if(e.target.id==='prefAnimOff'){setAnimOff(e.target.checked);toast(e.target.checked?'Animations disabled.':'Animations enabled.');return;}if(e.target.id==='prefAccent'){data.profile.accent=e.target.value;save();applyAppearance();toast('Accent color updated.');}if(e.target.id==='prefPfp'&&e.target.files?.[0])processAvatar(e.target.files[0]);if(e.target.id==='prefWeek'){data.profile.weekStart=e.target.value;save();render();}if(e.target.id==='prefReminders'){data.profile.reminders=e.target.checked;save();toast('Reminder preference saved. Push notifications are not connected.');}if(e.target.id==='importFile'&&e.target.files?.[0])importData(e.target.files[0]);if(e.target.id==='fSubject'&&$('#fCategory')){const s=subject(e.target.value),cat=$('#fCategory'),old=cat.value;cat.innerHTML=(s?.categories||[{name:'Exams'},{name:'Coursework'},{name:'Quizzes'}]).map(c=>`<option>${esc(c.name)}</option>`).join('');if([...cat.options].some(o=>o.value===old))cat.value=old;}});
  $('#quickAddBtn').addEventListener('click',openQuickAdd);
  $('#profileEdit').addEventListener('click',editProfileModal);$('#topProfile').addEventListener('click',editProfileModal);
  function openNavMenu(){const views=[['home','Home'],['academics','Academics'],['tasks','Tasks'],['planner','Planner'],['timetable','Timetable'],['pastpapers','Past Papers'],['studyspace','Study Space'],['insights','Insights'],['tools','StudyOS Tools'],['settings','Settings']];modal('Menu','Jump to a section',`<div class="nav-sheet">${views.map(v=>`<button type="button" class="nav-sheet-item ${currentView===v[0]?'on':''}" data-view="${v[0]}">${icon(v[0],22)}<span>${v[1]}</span></button>`).join('')}</div>`,'','menuForm');const f=$('#menuForm .modal-footer');if(f)f.classList.add('hidden');}
  $('#mobileMenu').addEventListener('click',openNavMenu);
  if('serviceWorker' in navigator && (location.protocol==='https:'||location.hostname==='localhost'))window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
  function localGreeting(){const h=new Date().getHours();return h<5?'Good night':h<12?'Good morning':h<17?'Good afternoon':h<21?'Good evening':'Good night';}
  function updateSplashProfile(){const name=data.profile.name||'Student',g=$('#splashGreeting'),n=$('#splashName'),a=$('#splashAvatar');if(g)g.textContent=`${localGreeting()}, ${name.split(' ')[0]}`;if(n)n.textContent=name;if(a){if(data.profile.avatar)a.innerHTML=`<img src="${data.profile.avatar}" alt="">`;else a.textContent=initials(name);}}
  function toggleFocus(){
    if(focusRunning){focusRunning=false;clearInterval(focusInterval);focusInterval=null;updateFocusVisual();render();return;}
    if(focusSeconds<=0)focusSeconds=focusTotalSeconds();
    focusRunning=true;render();updateFocusVisual();
    focusInterval=setInterval(()=>{
      if(!focusRunning)return;
      if(focusSeconds>0){focusSeconds--;const clock=$('#focusClock');if(clock){clock.textContent=`${String(Math.floor(focusSeconds/60)).padStart(2,'0')}:${String(focusSeconds%60).padStart(2,'0')}`;clock.classList.remove('tick');void clock.offsetWidth;clock.classList.add('tick');}updateFocusVisual();}
      if(focusSeconds===0){focusRunning=false;clearInterval(focusInterval);focusInterval=null;updateFocusVisual();if(focusMode==='Focus session'){const now=new Date(),date=`${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}`;data.sessions.push({id:uid(),title:`Focus session · ${subjectName(focusSubjectId)}`,subjectId:focusSubjectId||'',date,minutes:focusMinutes,reflection:'Automatically logged when the focus timer completed.',autoLogged:true});save();toast(`${focusMinutes}-minute study session logged.`);}const state=$('.focus-state');if(state)state.textContent='Session complete';const start=$('[data-action=focus-toggle]');if(start)start.textContent='Start';}
    },1000);
  }
  function resetFocus(){focusRunning=false;clearInterval(focusInterval);focusInterval=null;focusSeconds=focusTotalSeconds();render();updateFocusVisual();}
  // Now Playing: foobar2000 metadata is supplied by the optional local StudyOS bridge.
  const np = {trackKey:'',track:null,lyrics:[],synced:false,lastLookup:0,poll:null,position:0,duration:0,open:false};
  const NP_BRIDGE='http://127.0.0.1:8765';
  const npEls={trigger:$('#nowPlayingTrigger'),popover:$('#nowPlayingPopover'),miniArt:$('#npMiniArt'),miniTitle:$('#npMiniTitle'),miniArtist:$('#npMiniArtist'),miniLyric:$('#npMiniLyric'),equalizer:$('#npEqualizer'),connection:$('#npConnection'),largeArt:$('#npLargeArt'),title:$('#npTrackTitle'),artist:$('#npTrackArtist'),album:$('#npTrackAlbum'),status:$('#npLyricsStatus'),lyrics:$('#npLyrics'),current:$('#npCurrentTime'),duration:$('#npDuration'),fill:$('#npProgressFill')};
  const npTime=v=>{v=Math.max(0,Math.floor(Number(v)||0));return `${Math.floor(v/60)}:${String(v%60).padStart(2,'0')}`;};
  function npSetArt(url){[npEls.miniArt,npEls.largeArt].forEach(el=>{if(!el)return;el.style.backgroundImage=url?`url("${url.replace(/"/g,'%22')}")`:'';el.textContent=url?'':'♫';});}
  function npSetConnection(ok,msg){if(!npEls.connection)return;npEls.connection.textContent=msg|| (ok?'CONNECTED':'OFFLINE');npEls.connection.classList.toggle('connected',!!ok);}
  function npSetLyricsMessage(msg){if(npEls.status)npEls.status.textContent=msg;if(npEls.lyrics)npEls.lyrics.innerHTML=`<p class="np-lyrics-empty">${esc(msg)}</p>`;if(npEls.miniLyric)npEls.miniLyric.textContent=msg;np.lyrics=[];np.synced=false;}
  function npParseLrc(raw){return String(raw||'').split(/\r?\n/).flatMap(line=>{const matches=[...line.matchAll(/\[(\d{1,2}):(\d{2})(?:\.(\d{1,3}))?\]/g)];const text=line.replace(/\[[^\]]+\]/g,'').trim();return matches.map(m=>({time:Number(m[1])*60+Number(m[2])+Number(`0.${m[3]||'0'}`),text}));}).sort((a,b)=>a.time-b.time);}
  async function npLookupLyrics(track){const params=new URLSearchParams({track_name:track.title,artist_name:track.artist});if(track.album)params.set('album_name',track.album);if(track.duration>0)params.set('duration',String(Math.round(track.duration)));try{let r=await fetch(`https://lrclib.net/api/get?${params}`,{headers:{'Accept':'application/json'}});let d;if(r.ok){d=await r.json();}else if(r.status===404){const search=new URLSearchParams({track_name:track.title,artist_name:track.artist});r=await fetch(`https://lrclib.net/api/search?${search}`,{headers:{'Accept':'application/json'}});if(!r.ok)throw new Error('No lyrics found');const matches=await r.json();d=matches.find(x=>x.syncedLyrics)||matches[0];if(!d)throw new Error('No lyrics found');}else throw new Error('Lyrics service unavailable');if(d.syncedLyrics){np.lyrics=npParseLrc(d.syncedLyrics);np.synced=np.lyrics.length>0;}else if(d.plainLyrics){np.lyrics=String(d.plainLyrics).split(/\r?\n/).map(text=>({time:null,text}));np.synced=false;}else throw new Error('No lyrics found');npRenderLyrics();npEls.status.textContent=np.synced?'Synced lyrics · LRCLIB':'Plain lyrics · LRCLIB';}catch(e){npSetLyricsMessage(e.message==='Failed to fetch'?'Could not reach LRCLIB. Check your connection.':e.message);}}
  function npRenderLyrics(){if(!npEls.lyrics)return;if(!np.lyrics.length){npSetLyricsMessage('No lyrics available for this track.');return;}npEls.lyrics.innerHTML=np.lyrics.map((line,i)=>`<p class="np-lyrics-line" data-np-line="${i}">${esc(line.text||'♪')}</p>`).join('');npUpdateLyricsPosition(true);}
  async function npLookupArtwork(track){try{const q=new URLSearchParams({term:`${track.artist} ${track.title}`,entity:'song',limit:'1'});const r=await fetch(`https://itunes.apple.com/search?${q}`);if(!r.ok)return '';const d=await r.json();const item=d.results?.[0];return item?.artworkUrl100?.replace('100x100bb','600x600bb')||'';}catch{return '';}}
  function npUpdateLyricsPosition(force=false){if(!np.synced||!np.lyrics.length||!npEls.lyrics)return;let active=-1;for(let i=0;i<np.lyrics.length;i++){if(np.lyrics[i].time<=np.position)active=i;else break;}$$('[data-np-line]',npEls.lyrics).forEach((el,i)=>el.classList.toggle('active',i===active));const line=active>=0?np.lyrics[active]:null;if(npEls.miniLyric)npEls.miniLyric.textContent=line?.text||'♪';if(line){const el=$(`[data-np-line="${active}"]`,npEls.lyrics);if(el){const box=npEls.lyrics,target=el.getBoundingClientRect().top-box.getBoundingClientRect().top+box.scrollTop-(box.clientHeight-el.offsetHeight)/2;const delta=Math.abs(npEls.lyrics.scrollTop-target);if(force||delta>npEls.lyrics.clientHeight*.22)npEls.lyrics.scrollTo({top:Math.max(0,target),behavior:reduceMotion()?'auto':'smooth'});}}}
  function npRenderTrack(t){const title=t.title||'Unknown title',artist=t.artist||'Unknown artist',album=t.album||'';npEls.miniTitle.textContent=title;npEls.miniArtist.textContent=artist;npEls.title.textContent=title;npEls.artist.textContent=artist;npEls.album.textContent=album;npEls.equalizer.classList.toggle('is-playing',t.playbackState==='playing');npEls.trigger?.setAttribute('aria-label',`Now playing ${title} by ${artist}`);}
  async function npPoll(){try{const r=await fetch(`${NP_BRIDGE}/now-playing`,{cache:'no-store'});if(!r.ok)throw new Error('Bridge unavailable');const d=await r.json();if(!d.connected){npSetConnection(false,'FOOBAR2000 OFF');npEls.miniTitle.textContent='Now Playing';npEls.miniArtist.textContent='Open foobar2000';npEls.title.textContent='Nothing playing';npEls.artist.textContent='Open foobar2000 to begin';npEls.album.textContent='';npSetArt('');npEls.equalizer.classList.remove('is-playing');np.position=0;np.duration=0;npEls.fill.style.width='0%';npEls.current.textContent='0:00';npEls.duration.textContent='0:00';np.trackKey='';npSetLyricsMessage('Waiting for foobar2000 playback.');return;}npSetConnection(true,'FOOBAR2000 CONNECTED');const t=d.track||{};t.playbackState=d.playbackState||'stopped';t.position=Number(d.position)||0;t.duration=Number(d.duration)||0;np.position=t.position;np.duration=t.duration;np.track=t;npRenderTrack(t);npEls.current.textContent=npTime(t.position);npEls.duration.textContent=npTime(t.duration);npEls.fill.style.width=`${t.duration?Math.min(100,t.position/t.duration*100):0}%`;npUpdateLyricsPosition();const key=[t.title,t.artist,t.album].join('|');if(key!==np.trackKey){np.trackKey=key;if(d.artwork)npSetArt(`data:${d.artworkMime||'image/jpeg'};base64,${d.artwork}`);else npSetArt('');np.lyrics=[];np.synced=false;npSetLyricsMessage('Finding lyrics…');npLookupLyrics(t);const art=await npLookupArtwork(t);if(art)npSetArt(art);}}catch{np.trackKey='';npSetConnection(false,'BRIDGE OFFLINE');npEls.miniTitle.textContent='Now Playing';npEls.miniArtist.textContent='Start StudyOS bridge';npEls.equalizer.classList.remove('is-playing');if(!np.trackKey)npSetLyricsMessage('Start the StudyOS bridge and install the foobar2000 Beefweb component to connect.');}}
  async function npControl(action){try{const r=await fetch(`${NP_BRIDGE}/control/${action}`,{method:'POST'});if(!r.ok)throw new Error();setTimeout(npPoll,180);}catch{npSetConnection(false,'BRIDGE OFFLINE');toast('Could not control foobar2000. Check the local bridge.');}}
  if(npEls.trigger){npEls.trigger.addEventListener('click',()=>{np.open=!np.open;npEls.popover.hidden=!np.open;npEls.trigger.setAttribute('aria-expanded',String(np.open));if(np.open){npPoll();npUpdateLyricsPosition(true);}});document.addEventListener('click',e=>{if(np.open&&!$('#nowPlayingWrap')?.contains(e.target)){np.open=false;npEls.popover.hidden=true;npEls.trigger.setAttribute('aria-expanded','false');}});$('#nowPlayingPopover')?.addEventListener('click',e=>{const b=e.target.closest('[data-np-control]');if(b)npControl(b.dataset.npControl);});$('#npRetry')?.addEventListener('click',npPoll);np.poll=setInterval(npPoll,1800);npPoll();}
  updateSplashProfile();
  hydrateIcons();hydrateLogos();
  applyAppearance();
  const splashEl=$('#splash');
  if(splashEl){if(reduceMotion()){splashEl.remove();splashActive=false;}else{setTimeout(endSplash,3000);splashEl.addEventListener('click',endSplash);document.addEventListener('keydown',endSplash,{once:true});}}else splashActive=false;
  render();
})();
