# StudyOS tests

Run from the project root. Needs Python 3 + `pip install playwright pillow` + `playwright install chromium`, and Node 20+.

```
npm test                                   # unit tests: import logic, keystore, web composition, icons, release hygiene
npm run prepare:web                        # builds www/ (needed by the Android-layer tests)
python3 tests/e2e_ui.py                    # timetable, home order, streak colours, animations switch, scroll reveal, palette, mobile layout
python3 tests/e2e_android.py               # media-session widget, permissions UX, lyrics cache, data safety mirror, import assistant (native plugins are TEST DOUBLES)
python3 tests/e2e_lyrics.py www 8151       # lyric window centring + widget size stability (use tests/fixtures/legacy-web-src for the "before" behaviour)
python3 tests/e2e_data.py web-src tests/fixtures/legacy-web-src   # data preservation vs the previous version, backup/restore, timer logging, themes
```
`tests/fixtures/legacy-web-src` is the previous (4.3.6) web app exactly as uploaded, used for before/after comparisons.
The browser tests cannot run the Java code or a real phone: see TESTING.md for what still has to be checked on a device.
