import os
PROJ=os.environ.get('STUDYOS_PROJECT',os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
OUT=os.path.join(PROJ,'tests','out'); os.makedirs(OUT,exist_ok=True)
import json, threading, http.server, socketserver, functools, sys
from playwright.sync_api import sync_playwright
ROOT=PROJ+'/www'
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.TCPServer.allow_reuse_address=True
srv=socketserver.TCPServer(('127.0.0.1',8124),functools.partial(Q,directory=ROOT)); threading.Thread(target=srv.serve_forever,daemon=True).start()
URL='http://127.0.0.1:8124/index.html'

# TEST DOUBLES for the two native plugins (the Java side cannot run here). They only feed the real JS code.
MOCK = """
(() => {
  const store = window.__files = JSON.parse(sessionStorage.getItem('__files')||'{}');
  const save = () => sessionStorage.setItem('__files', JSON.stringify(store));
  window.__calls = [];
  window.__np = { state: {granted:false,hasSession:false,sdk:36,manufacturer:'Xiaomi'}, control:{ok:true}, listeners:[] };
  window.__lrc = {get:0, search:0};
  const Native = {
    safetyWrite: async a=>{store[a.name]={content:a.content,modified:Date.now()};save();window.__calls.push('safetyWrite:'+a.name)},
    safetyRead: async a=>{const f=store[a.name]; return f?{exists:true,content:f.content,modified:f.modified,source:'current'}:{exists:false}},
    safetyArchive: async a=>{if(store[a.name]){store[a.as]={...store[a.name]};save()}return{archived:true}},
    safetyPrune: async()=>{}, safetyList: async()=>({files:Object.entries(store).map(([name,f])=>({name,size:f.content.length,modified:f.modified}))}),
    setChrome: async a=>{window.__calls.push('chrome:'+a.color)}, getStatus: async()=>({sdk:36,versionName:'4.3.6'}),
    exportFile: async a=>{window.__calls.push('export:'+a.filename);return{saved:true}},
  };
  const NowPlaying = {
    getNowPlaying: async()=>JSON.parse(JSON.stringify(window.__np.state)),
    getArtwork: async()=>({id:window.__np.state.artworkId,data:'iVBORw0KGgo=',mime:'image/png'}),
    control: async a=>{window.__calls.push('control:'+a.action+(a.value!==undefined?':'+a.value:'')); const r=window.__np.control[a.action]||window.__np.control; return r.ok===undefined?{ok:true}:r;},
    getAccess: async()=>window.__np.state, openAccessSettings: async()=>{window.__calls.push('openAccessSettings')},
    openAppInfo: async()=>{window.__calls.push('openAppInfo')}, openPlayer: async()=>{window.__calls.push('openPlayer')},
    addListener: (n,cb)=>{window.__np.listeners.push(cb);return{remove(){}}},
  };
  window.Capacitor = {isNativePlatform:()=>true, Plugins:{StudyOSNative:Native, NowPlaying, App:{addListener:()=>{},minimizeApp:async()=>{}}}};
  const of = window.fetch.bind(window);
  window.fetch = (input, init) => {
    const u = typeof input==='string'?input:input.url;
    if (u.includes('lrclib.net/api/get')) { window.__lrc.get++; const t=new URL(u).searchParams.get('track_name');
      return Promise.resolve(t==='Song A'?new Response(JSON.stringify({syncedLyrics:'[00:01.00] line one\\n[00:05.00] line two'}),{status:200}):new Response('{}',{status:404})); }
    if (u.includes('lrclib.net/api/search')) { window.__lrc.search++; return Promise.resolve(new Response('[]',{status:200})); }
    if (u.includes('itunes.apple.com')) { window.__lrc.itunes=(window.__lrc.itunes||0)+1; return Promise.resolve(new Response('{"resultCount":0,"results":[]}',{status:200})); }
    return of(input, init);
  };
})();
"""
def S(**kw):
    s={'granted':True,'hasSession':True,'package':'com.spotify.music','label':'Spotify','title':'Song A','artist':'Artist','album':'Alb','duration':200,'position':12,
       'playbackState':'playing','hasArtwork':True,'artworkId':'id1','caps':{'playPause':True,'next':True,'previous':False,'seek':True},
       'volume':{'supported':True,'remote':False,'level':0.4},'sdk':36,'manufacturer':'Xiaomi','listenerConnected':True}
    s.update(kw); return s
errs=[]
def check(c,msg):
    print(('PASS ' if c else 'FAIL ')+msg)
    if not c: errs.append(msg)

with sync_playwright() as p:
    b=p.chromium.launch()
    ctx=b.new_context(viewport={'width':393,'height':800},has_touch=True,device_scale_factor=2)
    ctx.add_init_script(MOCK)
    pg=ctx.new_page(); logs=[]
    pg.on('console',lambda m: logs.append(m.text) if m.type=='error' else None); pg.on('pageerror',lambda e: logs.append(str(e)))
    def setstate(st, fire=True):
        pg.evaluate("s=>{window.__np.state=s}", st)
        if fire: pg.evaluate("()=>window.__np.listeners.forEach(cb=>cb({granted:true}))")
        pg.wait_for_timeout(700)
    txt=lambda i: pg.evaluate("i=>document.getElementById(i)?.textContent||''", i)
    pg.goto(URL); pg.wait_for_timeout(2600)
    check(pg.evaluate("!!document.querySelector('.mobile-nav')"),'phone: app renders (dashboard intact)')

    # ---- A. access not granted
    check(txt('npConnection')=='ACCESS NEEDED', f"no access: widget says ACCESS NEEDED ({txt('npConnection')!r})")
    panel=pg.evaluate("document.getElementById('aosMusic').innerText")
    check('Notification access' in panel and 'not' in panel and 'contents of your notifications' in panel, 'permission explained before requesting')
    check('Allow restricted settings' in panel and 'Autostart' in panel, 'restricted-settings + HyperOS guidance shown')
    pg.evaluate("document.getElementById('nowPlayingPopover').hidden=false"); pg.wait_for_timeout(200)
    pg.screenshot(path=OUT+'/music_access_phone.png')
    pg.click('[data-aos-m=grant]'); check('openAccessSettings' in pg.evaluate('__calls'),'button opens Android notification-access settings')

    # ---- B. granted + playing, event-driven (no reopen)
    setstate(S())
    check(txt('npConnection')=='SPOTIFY','widget names the active player')
    check(txt('npTrackTitle')=='Song A' and txt('npTrackArtist')=='Artist','title + artist shown')
    check(pg.evaluate("getComputedStyle(document.getElementById('npLargeArt')).backgroundImage.includes('data:image/png')"),'artwork from the media session shown')
    pg.wait_for_timeout(800)
    check('line one' in txt('npLyrics'),'LRCLIB synced lyrics shown')
    check(pg.evaluate('__lrc.get')==1,'one lyrics request for the track')
    check(txt('npDuration')=='3:20','duration shown')
    pg.screenshot(path=OUT+'/music_playing_phone.png')

    # ---- C. controls: real calls, honest failure
    pg.click('[data-np-control=play-pause]'); pg.wait_for_timeout(300)
    check('control:play-pause' in pg.evaluate('__calls'),'play/pause sent to the session')
    pg.evaluate("window.__np.control={previous:{ok:false,reason:'unsupported',label:'Spotify'}}")
    pg.click('[data-np-control=previous]'); pg.wait_for_timeout(300)
    check('control:previous' in pg.evaluate('__calls') and 'does not offer that control' in pg.evaluate('document.body.innerText'),'unsupported control is explained, not faked')
    check('does not offer previous' in pg.evaluate("document.getElementById('aosMusic').innerText"),'panel lists controls the player lacks')

    # ---- D. pause / track change / lyrics cache
    setstate(S(playbackState='paused'))
    check(not pg.evaluate("document.getElementById('npEqualizer').classList.contains('is-playing')"),'pause detected')
    setstate(S(title='Song B',artworkId='id2',hasArtwork=False)); pg.wait_for_timeout(600)
    check(txt('npTrackTitle')=='Song B','track change detected')
    n=pg.evaluate('__lrc.get+__lrc.search')
    check(pg.evaluate('__lrc.itunes||0')>=1,'no player artwork -> existing online cover lookup used')
    setstate(S()); pg.wait_for_timeout(600)
    check('line one' in txt('npLyrics') and pg.evaluate('__lrc.get+__lrc.search')==n,'returning to a known track: lyrics from device cache, no new download')
    setstate(S(title='Song B',artworkId='id2',hasArtwork=False)); pg.wait_for_timeout(600)
    check(pg.evaluate('__lrc.get+__lrc.search')==n,'"no lyrics" remembered: not re-requested')

    # ---- E. nothing playing / revoked
    setstate({'granted':True,'hasSession':False,'sdk':36,'manufacturer':'Xiaomi'})
    check(txt('npConnection')=='NO MUSIC PLAYING' and 'No music app is playing' in pg.evaluate("document.getElementById('aosMusic').innerText"),'no session handled')
    setstate({'granted':False,'hasSession':False,'sdk':36,'manufacturer':'Xiaomi'})
    check('turned off' in pg.evaluate("document.getElementById('aosMusic').innerText"),'revoked access detected and explained')

    # ---- F. volume
    setstate(S()); pg.wait_for_timeout(400)
    pg.evaluate("()=>{const e=document.getElementById('aosVolume');e.value=70;e.dispatchEvent(new Event('input',{bubbles:true}))}"); pg.wait_for_timeout(900)  # drag settles
    check('control:volume:0.7' in pg.evaluate('__calls'),'volume slider sends level to the session/device')
    setstate(S(volume={'supported':False})); pg.wait_for_timeout(300)
    check(pg.evaluate("!document.getElementById('aosVolume')") and 'does not let other apps change its volume' in pg.evaluate("document.getElementById('aosMusic').innerText"),'volume hidden when unsupported')

    # ---- G. offline lyrics from cache
    ctx.set_offline(True); setstate(S(title='Song B',hasArtwork=False),False); setstate(S()); pg.wait_for_timeout(800)
    check('line one' in txt('npLyrics'),'offline: cached lyrics still work')
    check(pg.evaluate("!document.getElementById('aosOffline').hidden"),'offline banner shown'); ctx.set_offline(False)

    # ---- H. tablet layout + screenshot
    pg.set_viewport_size({'width':1280,'height':800}); pg.wait_for_timeout(500)
    check(pg.evaluate("getComputedStyle(document.querySelector('.sidebar')).display!=='none'") and pg.evaluate("getComputedStyle(document.querySelector('.stats-grid')).gridTemplateColumns.split(' ').length")==4,'tablet: sidebar + 4-column dashboard')
    pg.screenshot(path=OUT+'/music_playing_tablet.png')

    # ---- I. data safety + import (unchanged behaviour)
    pg.evaluate("localStorage.setItem('studyos.v1.data', JSON.stringify({subjects:[{id:'a'}],tasks:[],profile:{name:'Mirror'}}))"); pg.wait_for_timeout(1800)
    check('safetyWrite:current.json' in pg.evaluate('__calls'),'saves mirrored to the on-device safety file')
    files=pg.evaluate("sessionStorage.getItem('__files')")
    c2=b.new_context(viewport={'width':393,'height':800}); c2.add_init_script("sessionStorage.setItem('__files',%s);"%json.dumps(files)); c2.add_init_script(MOCK)
    p2=c2.new_page(); p2.goto(URL); p2.wait_for_timeout(1500)
    check(p2.evaluate("document.body.innerText.includes('Restore your StudyOS data?')"),'restore asks before restoring'); c2.close()
    c4=b.new_context(viewport={'width':1280,'height':800}); c4.add_init_script(MOCK); p4=c4.new_page(); p4.goto(URL); p4.wait_for_timeout(2500)
    p4.evaluate("document.querySelector('[data-view=settings]').click()"); p4.wait_for_timeout(800)
    json.dump({"profile":{"name":"Test User"},"subjects":[{"id":"x1","name":"Chem"}],"tasks":[{"id":"tk1","title":"T"}],"futureThing":{"a":1}},open(OUT+'/backup.json','w'))
    p4.set_input_files('#aosFile',OUT+'/backup.json'); p4.wait_for_timeout(500)
    check(p4.evaluate("localStorage.getItem('studyos.v1.data')") is None,'import: nothing written before confirmation')
    p4.click('[data-aos=apply]'); p4.wait_for_timeout(2500)
    d=json.loads(p4.evaluate("localStorage.getItem('studyos.v1.data')") or 'null')
    check(bool(d) and d['tasks'][0]['id']=='tk1' and d.get('futureThing')=={'a':1},'import applied, ids kept, unknown key preserved')
    b.close()
real=[l for l in logs if 'favicon' not in l and 'Failed to load resource' not in l]
check(not real,'no console errors: '+str(real[:3]))
sys.exit(1 if errs else 0)
