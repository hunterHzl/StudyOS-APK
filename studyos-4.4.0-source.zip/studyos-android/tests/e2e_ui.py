import os
PROJ=os.environ.get('STUDYOS_PROJECT',os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
OUT=os.path.join(PROJ,'tests','out'); os.makedirs(OUT,exist_ok=True)
import sys, json, threading, http.server, socketserver, functools, datetime
from playwright.sync_api import sync_playwright
ROOT=sys.argv[1] if len(sys.argv)>1 else PROJ+'/web-src'
PORT=int(sys.argv[2]) if len(sys.argv)>2 else 8140
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
socketserver.TCPServer.allow_reuse_address=True
srv=socketserver.TCPServer(('127.0.0.1',PORT),functools.partial(Q,directory=ROOT)); threading.Thread(target=srv.serve_forever,daemon=True).start()
URL=f'http://127.0.0.1:{PORT}/index.html'
errs=[]
def check(c,msg):
    print(('PASS ' if c else 'FAIL ')+msg)
    if not c: errs.append(msg)
def iso(d): return d.strftime('%Y-%m-%d')
def sessions(n):
    t=datetime.date.today(); return [{'id':f's{i}','title':'x','subjectId':'','date':iso(t-datetime.timedelta(days=i)),'minutes':30} for i in range(n)]
def go(pg,v): pg.evaluate(f"document.querySelector('.sidebar [data-view={v}], [data-view={v}]').click()"); pg.wait_for_timeout(450)
with sync_playwright() as p:
    b=p.chromium.launch(); logs=[]
    def newpage(w=1280,h=800,scheme='light',touch=False,data=None,init=None):
        ctx=b.new_context(viewport={'width':w,'height':h},color_scheme=scheme,has_touch=touch)
        if data is not None: ctx.add_init_script("if(!localStorage.getItem('studyos.v1.data'))localStorage.setItem('studyos.v1.data',%s)"%json.dumps(json.dumps(data)))
        if init: ctx.add_init_script(init)
        pg=ctx.new_page(); pg.on('pageerror',lambda e: logs.append(str(e))); pg.on('console',lambda m: logs.append(m.text) if m.type=='error' and 'Failed to load' not in m.text else None)
        pg.goto(URL); pg.wait_for_timeout(3600); return ctx,pg
    # ---------- fresh install ----------
    ctx,pg=newpage()
    check(pg.evaluate("document.documentElement.dataset.accent")=='mono','default palette is Black + Grey (neutral)')
    sat=pg.evaluate("(()=>{const d=document.createElement('i');d.style.background='var(--primary)';document.body.appendChild(d);const c=getComputedStyle(d).backgroundColor;d.remove();const v=c.match(/\\d+/g).slice(0,3).map(Number);return Math.max(...v)-Math.min(...v)})()")
    check(0<=sat<=40,f'primary colour is neutral grey (channel spread {sat})')
    check(pg.evaluate("JSON.parse(localStorage.getItem('studyos.v1.data')||'{}').profile?.theme||'system'")=='system' and pg.evaluate("document.documentElement.dataset.theme")=='system','theme mode defaults to System')
    pg.screenshot(path=OUT+'/ui_home_desktop.png',full_page=True)
    # home order + no duplicates
    h2=pg.evaluate("[...document.querySelectorAll('#content h2')].map(e=>e.textContent.trim())")
    i1,i2,i3=[next((i for i,t in enumerate(h2) if t==x),-1) for x in ['Daily study duration','Consistency & productivity','This week']]
    check(0<=i1<i2<i3,f'Home order: Daily study duration > Consistency & productivity > This week {h2[:5]}')
    check(all(h2.count(x)==1 for x in ['Daily study duration','Consistency & productivity','This week']),'no duplicated widgets on Home')
    go(pg,'insights'); h2i=pg.evaluate("[...document.querySelectorAll('#content h2')].map(e=>e.textContent.trim())")
    check('Daily study duration' not in h2i and len(h2i)>5,'Insights still renders (moved widgets not duplicated there)')
    # ---------- timetable ----------
    go(pg,'timetable')
    txt=pg.evaluate("document.querySelector('#content').innerText")
    check('empty' in txt.lower() and not any(w in txt for w in ['Physics','ESL','Math B','Engineering','HR']),'timetable starts blank, no sample lessons')
    pg.click('[data-action=timetable-add-period]'); pg.wait_for_timeout(300)
    pg.fill('[data-timetable-time="0"]','9:00–10:00'); pg.dispatch_event('[data-timetable-time="0"]','change')
    pg.fill('[data-timetable-slot="0"][data-timetable-day="0"]','Maths'); pg.dispatch_event('[data-timetable-slot="0"][data-timetable-day="0"]','change')
    pg.click('[data-action=toggle-timetable-edit]'); pg.wait_for_timeout(300)
    check(pg.evaluate("document.querySelector('.timetable-table').innerText.includes('Maths')") and '9:00' in pg.evaluate("document.querySelector('.timetable-table').innerText"),'timetable create + edit works')
    check(pg.evaluate("getComputedStyle(document.querySelector('.timetable-subject')).backgroundImage")=='none' and pg.evaluate("getComputedStyle(document.querySelector('.timetable-subject')).backgroundColor")=='rgba(0, 0, 0, 0)','timetable cells are plain (no fills)')
    pg.screenshot(path=OUT+'/ui_timetable.png')
    pg.reload(); pg.wait_for_timeout(3000); go(pg,'timetable')
    check('Maths' in pg.evaluate("document.querySelector('#content').innerText"),'timetable persists after reload')
    pg.evaluate("document.querySelector('[data-action=toggle-timetable-edit]').click()"); pg.wait_for_timeout(200)
    pg.click('[data-action=timetable-remove-period]'); pg.wait_for_timeout(300); pg.evaluate("document.querySelector('[data-confirm=yes]').click()"); pg.wait_for_timeout(300)
    check('empty' in pg.evaluate("document.querySelector('#content').innerText").lower(),'remove period works (back to empty state)')
    ctx.close()
    # ---------- streak milestones ----------
    for n,exp in [(1,'#f6c90e'),(7,'#f7b52c'),(15,'#f39a1f'),(29,'#ee6a14'),(30,'#e53935'),(60,'#b3201f'),(100,'#2f80ed'),(200,'#8e44ec'),(300,'#2eb872'),(400,'#ffffff')]:
        ctx,pg=newpage(data={'sessions':sessions(n)})
        t=pg.evaluate("document.querySelector('.streak-num')?.textContent")
        col=pg.evaluate("document.querySelector('.streak-main .flame')?.style.getPropertyValue('--flame').trim()")
        check(t==f'x{n}' and col.lower()==exp,f'streak {n}: shows {t!r}, flame {col} (expected {exp})')
        if n in (1,30,400): pg.locator('.streak-panel').screenshot(path=f'{OUT}/ui_streak_{n}.png')
        if n==7: check('x7' in pg.evaluate("document.querySelector('.cons-tiles').innerText") and pg.evaluate("!!document.querySelector('.cons-streak .flame')"),'x-prefix + flame also in Consistency tiles')
        ctx.close()
    ctx,pg=newpage(data={'sessions':[]}); check(pg.evaluate("document.querySelector('.streak-num').textContent")=='x0','streak 0 shows x0'); ctx.close()
    # ---------- animation switch ----------
    ctx,pg=newpage(w=360,h=640,touch=True)
    check(pg.evaluate("document.documentElement.dataset.motion")=='on','animations enabled by default')
    pend=pg.evaluate("document.querySelectorAll('#content .rv').length")
    check(pend>=2,f'phone: {pend} below-the-fold widgets wait for scroll (incl. Daily study duration)')
    check(pg.evaluate("document.querySelector('#content .rv h2')?.textContent")!=None,'pending blocks are real widgets')
    pg.evaluate("window.scrollTo(0,document.documentElement.scrollHeight)"); pg.wait_for_timeout(900)
    check(pg.evaluate("document.querySelectorAll('#content .rv').length")==0,'scrolling reveals everything (reveals once)')
    pg.evaluate("window.scrollTo(0,0)"); pg.wait_for_timeout(300); pg.evaluate("window.scrollTo(0,document.documentElement.scrollHeight)"); pg.wait_for_timeout(300)
    check(pg.evaluate("document.querySelectorAll('#content .rv').length")==0,'scrolling back and forth does not re-hide / re-trigger')
    go(pg,'settings'); pg.evaluate("document.getElementById('prefAnimOff').scrollIntoView()")
    check('Turn off interface animations and transitions to improve responsiveness on lower-end devices.' in pg.evaluate("document.querySelector('#content').innerText"),'setting + description present in Settings')
    pg.evaluate("document.getElementById('prefAnimOff').click()"); pg.wait_for_timeout(400)
    check(pg.evaluate("document.documentElement.dataset.motion")=='off','toggle takes effect immediately (no restart)')
    check(pg.evaluate("localStorage.getItem('studyos.pref.animations')")=='off','preference persisted locally')
    anim=pg.evaluate("getComputedStyle(document.querySelector('#content .panel')).animationName+'|'+getComputedStyle(document.querySelector('.mobile-nav-item')).transitionDuration")
    check(anim.startswith('none|0s'),f'CSS animations/transitions are off ({anim})')
    pg.evaluate("document.querySelector('[data-view=home]').click()"); pg.wait_for_timeout(500)
    check(pg.evaluate("document.querySelectorAll('#content .rv').length")==0 and pg.evaluate("!document.querySelector('#content.anim')"),'no reveal / entrance machinery runs when off')
    check(pg.evaluate("[...document.querySelectorAll('#content .stat-value')].every(e=>e.textContent.trim().length>0)"),'values show instantly (no count-up)')
    pg.reload(); pg.wait_for_timeout(1500)
    check(pg.evaluate("document.documentElement.dataset.motion")=='off' and pg.evaluate("!document.getElementById('splash')"),'preference persists after restart; splash skipped')
    ctx.close()
    ctx,pg=newpage(w=360,h=640,touch=True,init="localStorage.setItem('studyos.pref.animations','off')")
    go(pg,'settings'); pg.evaluate("document.getElementById('prefAnimOff').click()"); pg.wait_for_timeout(400)
    check(pg.evaluate("document.documentElement.dataset.motion")=='on','can be turned back on immediately'); ctx.close()
    # OS reduced motion
    ctx=b.new_context(viewport={'width':360,'height':640},reduced_motion='reduce'); pg=ctx.new_page(); pg.goto(URL); pg.wait_for_timeout(1500)
    check(pg.evaluate("document.documentElement.dataset.motion")=='off','OS reduced-motion setting is respected'); ctx.close()
    # dark mode with animations off
    ctx,pg=newpage(scheme='dark',init="localStorage.setItem('studyos.pref.animations','off')")
    check(pg.evaluate("document.documentElement.dataset.motion")=='off' and pg.evaluate("getComputedStyle(document.body).backgroundColor")!='rgb(247, 245, 250)','works in dark mode too')
    pg.screenshot(path=OUT+'/ui_home_dark.png'); ctx.close()
    # ---------- mobile layout ----------
    for w,h in [(320,640),(360,640),(393,780)]:
        ctx,pg=newpage(w=w,h=h,touch=True)
        r=pg.evaluate("(()=>{const n=document.querySelector('.mobile-nav');return {w:n.scrollWidth,vw:innerWidth,items:[...document.querySelectorAll('.mobile-nav-item')].map(e=>Math.round(e.getBoundingClientRect().right)),minH:Math.min(...[...document.querySelectorAll('.mobile-nav-item')].map(e=>e.getBoundingClientRect().height))}})()")
        check(r['w']<=r['vw'] and max(r['items'])<=r['vw']+1 and r['minH']>=44,f'{w}px: bottom bar fits ({len(r["items"])} items, min height {r["minH"]:.0f})')
        bad=[]
        for v in ['home','academics','tasks','planner','timetable','pastpapers','studyspace','insights','tools','settings']:
            pg.evaluate("document.getElementById('mobileMenu').click()"); pg.wait_for_timeout(250)
            ok=pg.evaluate(f"!!document.querySelector('.nav-sheet [data-view={v}]')")
            if not ok: bad.append(v); continue
            pg.evaluate(f"document.querySelector('.nav-sheet [data-view={v}]').click()"); pg.wait_for_timeout(400)
            m=pg.evaluate("""()=>{window.scrollTo(0,document.documentElement.scrollHeight);const nav=document.querySelector('.mobile-nav').getBoundingClientRect().top;
              const els=[...document.querySelectorAll('#content *')].filter(e=>e.offsetParent&&e.getBoundingClientRect().height>0&&!e.closest('.rv'));
              const last=Math.max(...els.map(e=>e.getBoundingClientRect().bottom));return {gap:Math.round(nav-last),hs:document.documentElement.scrollWidth>innerWidth}}""")
            if m['gap']<0 or m['hs']: bad.append(f"{v}:{m}")
        check(not bad,f'{w}px: all 10 sections reachable, last content clear of the bar, no horizontal overflow {bad}')
        if w==360:
            pg.evaluate("document.getElementById('mobileMore').click()"); pg.wait_for_timeout(400); pg.screenshot(path=OUT+'/ui_more_sheet.png')
            pg.keyboard.press('Escape')
        ctx.close()
    ctx,pg=newpage(w=360,h=780,touch=True); pg.screenshot(path=OUT+'/ui_home_phone.png',full_page=True); ctx.close()
    b.close()
real=[l for l in logs if 'favicon' not in l]
check(not real,'no console/page errors: '+str(real[:3]))
sys.exit(1 if errs else 0)
