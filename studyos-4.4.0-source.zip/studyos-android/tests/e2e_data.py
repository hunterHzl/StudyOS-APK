import os
PROJ=os.environ.get('STUDYOS_PROJECT',os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
OUT=os.path.join(PROJ,'tests','out'); os.makedirs(OUT,exist_ok=True)
import sys, json, threading, http.server, socketserver, functools, datetime
from playwright.sync_api import sync_playwright
NEW=sys.argv[1]; OLD=sys.argv[2]
def serve(root,port):
    class Q(http.server.SimpleHTTPRequestHandler):
        def log_message(self,*a): pass
    socketserver.TCPServer.allow_reuse_address=True
    s=socketserver.TCPServer(('127.0.0.1',port),functools.partial(Q,directory=root)); threading.Thread(target=s.serve_forever,daemon=True).start()
serve(NEW,8160); serve(OLD,8161)
errs=[]
def check(c,msg):
    print(('PASS ' if c else 'FAIL ')+msg)
    if not c: errs.append(msg)
KEY='studyos.v1.data'
with sync_playwright() as p:
    b=p.chromium.launch(); logs=[]
    def page(port,data=None,w=1280,h=800,init=None,scheme='light',clock=False):
        ctx=b.new_context(viewport={'width':w,'height':h},color_scheme=scheme,accept_downloads=True)
        if data is not None: ctx.add_init_script("if(!localStorage.getItem('%s'))localStorage.setItem('%s',%s)"%(KEY,KEY,json.dumps(data)))
        if init: ctx.add_init_script(init)
        pg=ctx.new_page(); pg.on('pageerror',lambda e: logs.append(str(e)))
        if clock: pg.clock.install()
        pg.goto(f'http://127.0.0.1:{port}/index.html')
        if clock: pg.clock.run_for(4000)
        else: pg.wait_for_timeout(3300)
        return ctx,pg
    # ---- build a realistic LEGACY data set with the ORIGINAL (uploaded) app: saved profile, seeded timetable, 45-day streak ----
    ctx,pg=page(8161)
    pg.evaluate("document.querySelector('[data-view=settings]').click()"); pg.wait_for_timeout(500)
    pg.evaluate("(()=>{const e=document.getElementById('prefBlack');e.checked=true;e.dispatchEvent(new Event('change',{bubbles:true}))})()"); pg.wait_for_timeout(500)
    legacy=json.loads(pg.evaluate(f"localStorage.getItem('{KEY}')")); ctx.close()
    t=datetime.date.today()
    legacy['sessions']=[{'id':f'L{i}','title':'Legacy','subjectId':'','date':(t-datetime.timedelta(days=i)).isoformat(),'minutes':40} for i in range(45)]
    legacy['profile']['name']='Legacy User'; legacy['profile']['accent']='violet'; legacy['tasks'].append({'id':'legacy-task','title':'My old task','subjectId':'','due':'2030-01-01','status':'Not started','priority':'High'})
    legacy_json=json.dumps(legacy)
    first_lesson=legacy['schoolTimetable']['slots'][0]['subjects'][0]; check(bool(legacy['schoolTimetable']['slots']) and first_lesson,'legacy data set built from the original app (has its saved timetable, accent violet)')
    # ---- OLD app display of the streak (for comparison) ----
    ctx,pg=page(8161,legacy_json); old_streak=pg.evaluate("[...document.querySelectorAll('.streak-main strong')].map(e=>e.textContent)[0]"); ctx.close()
    # ---- NEW app on legacy data ----
    ctx,pg=page(8160,legacy_json)
    after=pg.evaluate(f"localStorage.getItem('{KEY}')")
    check(after==legacy_json,'launching the new build does not touch or rewrite existing saved data (byte-identical)')
    check(pg.evaluate("document.documentElement.dataset.accent")=='violet','existing palette (violet) is preserved, not forced to grey')
    check('Legacy User' in pg.evaluate("document.querySelector('.sidebar').innerText"),'profile preserved')
    new_streak=pg.evaluate("document.querySelector('.streak-num').textContent")
    check(old_streak and old_streak.startswith('45') and new_streak=='x45',f'streak calculation unchanged (old shows {old_streak!r}, new shows {new_streak!r}); flame colour {pg.evaluate("document.querySelector(\".streak-main .flame\").style.getPropertyValue(\"--flame\")")}')
    pg.evaluate("document.querySelector('[data-view=timetable]').click()"); pg.wait_for_timeout(500)
    check(first_lesson in pg.evaluate("document.querySelector('#content').innerText"),'existing saved timetable preserved and editable (blank default applies to new installs only)')
    pg.evaluate("document.querySelector('[data-view=tasks]').click()"); pg.wait_for_timeout(500)
    check('My old task' in pg.evaluate("document.querySelector('#content').innerText"),'tasks preserved')
    # ---- backup + restore ----
    pg.evaluate("document.querySelector('[data-view=settings]').click()"); pg.wait_for_timeout(500)
    with pg.expect_download() as dl: pg.evaluate("document.querySelector('[data-action=export-data]').click()")
    path=dl.value.path(); exported=json.load(open(path))
    check(len(exported['sessions'])==45 and exported['profile']['name']=='Legacy User' and any(x['id']=='legacy-task' for x in exported['tasks']),'backup export contains all data')
    ctx.close()
    ctx,pg=page(8160)   # fresh device
    check(pg.evaluate(f"localStorage.getItem('{KEY}')") is None,'fresh device has no data (restore target)')
    pg.evaluate("document.querySelector('[data-view=settings]').click()"); pg.wait_for_timeout(500)
    json.dump(exported,open(OUT+'/restore.json','w'))
    pg.set_input_files('#importFile',OUT+'/restore.json'); pg.wait_for_timeout(500)
    pg.evaluate("document.querySelector('[data-confirm=yes]')?.click()"); pg.wait_for_timeout(1500)
    restored=json.loads(pg.evaluate(f"localStorage.getItem('{KEY}')") or 'null')
    check(bool(restored) and len(restored['sessions'])==45 and restored['profile']['name']=='Legacy User' and restored['schoolTimetable']==legacy['schoolTimetable'],'restore from backup brings back sessions, profile and timetable exactly')
    # persistence across restart
    pg.reload(); pg.wait_for_timeout(2500)
    check(json.loads(pg.evaluate(f"localStorage.getItem('{KEY}')"))['profile']['name']=='Legacy User','data persists across restart'); ctx.close()
    # ---- study timer + automatic session logging (fake clock) ----
    ctx,pg=page(8160,clock=True)
    pg.evaluate("document.querySelector('[data-view=studyspace]').click()"); pg.clock.run_for(600)
    pg.evaluate("(()=>{const e=document.getElementById('focusDuration');e.value=1;e.dispatchEvent(new Event('change',{bubbles:true}));e.dispatchEvent(new Event('input',{bubbles:true}))})()"); pg.clock.run_for(300)
    clk0=pg.evaluate("document.getElementById('focusClock').textContent")
    pg.evaluate("document.querySelector('[data-action=focus-toggle]').click()"); pg.clock.run_for(5000)
    clk1=pg.evaluate("document.getElementById('focusClock').textContent")
    check(clk0.strip().startswith('01:00') and clk1!=clk0,f'timer counts down ({clk0.strip()} -> {clk1.strip()})')
    pg.clock.run_for(60000); pg.clock.run_for(1500)
    d=json.loads(pg.evaluate(f"localStorage.getItem('{KEY}')"))
    auto=[s for s in d['sessions'] if s.get('autoLogged')]
    check(len(auto)==1 and auto[0]['minutes']==1,f'completing the timer logs a session automatically ({len(auto)} logged, {auto[0]["minutes"] if auto else None} min)')
    pg.evaluate("document.querySelector('[data-view=home]').click()"); pg.clock.run_for(1500)
    check(pg.evaluate("document.querySelector('.streak-num').textContent")=='x1','new session feeds the streak (x1) and stats'); ctx.close()
    # ---- theme switching ----
    ctx,pg=page(8160,scheme='dark'); 
    bg=lambda: pg.evaluate("getComputedStyle(document.body).backgroundColor")
    dark_sys=bg(); check(pg.evaluate("document.documentElement.dataset.theme")=='system' and dark_sys in ('rgb(0, 0, 0)','rgb(1, 1, 1)','rgb(2, 2, 2)') or dark_sys.startswith('rgb(0'),f'System follows device dark mode ({dark_sys}, pure black as default palette uses Black)')
    pg.evaluate("document.querySelector('[data-view=settings]').click()"); pg.wait_for_timeout(400)
    pg.select_option('#prefTheme','light'); pg.wait_for_timeout(300); l=bg(); check(l!=dark_sys and pg.evaluate("document.documentElement.dataset.theme")=='light',f'Light mode switches immediately ({l})')
    pg.select_option('#prefTheme','dark'); pg.wait_for_timeout(300); check(bg()==dark_sys,'Dark mode switches immediately')
    pg.select_option('#prefTheme','system'); pg.wait_for_timeout(300)
    pg.evaluate("document.querySelector('[data-accent=violet]').click()"); pg.wait_for_timeout(300)
    check(pg.evaluate("document.documentElement.dataset.accent")=='violet','custom palettes still selectable (violet)')
    pg.evaluate("document.querySelector('[data-accent=mono]').click()"); pg.wait_for_timeout(300)
    check(pg.evaluate("document.documentElement.dataset.accent")=='mono','Black + Grey selectable again')
    pg.emulate_media(color_scheme='light'); pg.wait_for_timeout(400)
    check(bg()!=dark_sys,'System mode follows a live OS change to light')
    pg.screenshot(path=OUT+'/ui_settings_phone_like.png'); ctx.close()
    b.close()
real=[l for l in logs if 'favicon' not in l]
check(not real,'no page errors: '+str(real[:3]))
sys.exit(1 if errs else 0)
