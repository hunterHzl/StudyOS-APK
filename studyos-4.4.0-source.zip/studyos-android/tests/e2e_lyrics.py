import os
PROJ=os.environ.get('STUDYOS_PROJECT',os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
OUT=os.path.join(PROJ,'tests','out'); os.makedirs(OUT,exist_ok=True)
import sys, json, threading, http.server, socketserver, functools
from playwright.sync_api import sync_playwright
LONG='This is a very long lyric line that must never widen the player or wrap onto a second line because it is truncated'
LRC='\n'.join(f"[{(i*2)//60:02d}:{(i*2)%60:02d}.00] "+(LONG if i==12 else f"Lyric line number {i}") for i in range(30))
MOCK="""
(()=>{window.__np={state:{granted:true,hasSession:true,package:'p',label:'Player',title:'Song A',artist:'Artist',album:'Alb',duration:100,position:0,playbackState:'playing',hasArtwork:false,artworkId:'x',caps:{playPause:true,next:true,previous:true,seek:true},volume:{supported:false},sdk:36,manufacturer:'x'},listeners:[]};
const NP={getNowPlaying:async()=>JSON.parse(JSON.stringify(window.__np.state)),getArtwork:async()=>({data:''}),control:async()=>({ok:true}),getAccess:async()=>window.__np.state,addListener:(n,cb)=>{window.__np.listeners.push(cb);return{remove(){}}}};
window.Capacitor={isNativePlatform:()=>true,Plugins:{StudyOSNative:{safetyRead:async()=>({exists:false}),safetyWrite:async()=>{},safetyArchive:async()=>({}),safetyPrune:async()=>{},safetyList:async()=>({files:[]}),setChrome:async()=>{},getStatus:async()=>({sdk:36}),exportFile:async()=>({saved:true})},NowPlaying:NP,App:{addListener:()=>{}}}};
const of=window.fetch.bind(window);window.fetch=(i,n)=>{const u=typeof i==='string'?i:i.url;if(u.includes('lrclib.net/api/get'))return Promise.resolve(new Response(JSON.stringify({syncedLyrics:LRC_TEXT}),{status:200}));if(u.includes('itunes'))return Promise.resolve(new Response('{"results":[]}',{status:200}));return of(i,n);};})();
""".replace('LRC_TEXT',json.dumps(LRC))
def run(root,port,label):
    class Q(http.server.SimpleHTTPRequestHandler):
        def log_message(self,*a): pass
    socketserver.TCPServer.allow_reuse_address=True
    srv=socketserver.TCPServer(('127.0.0.1',port),functools.partial(Q,directory=root)); threading.Thread(target=srv.serve_forever,daemon=True).start()
    out={}
    with sync_playwright() as p:
        b=p.chromium.launch(); ctx=b.new_context(viewport={'width':1280,'height':800}); ctx.add_init_script("localStorage.setItem('studyos.pref.animations','off')"); ctx.add_init_script(MOCK)
        pg=ctx.new_page(); pg.goto(f'http://127.0.0.1:{port}/index.html'); pg.wait_for_timeout(2500)
        pg.evaluate("document.getElementById('nowPlayingTrigger').click()"); pg.wait_for_timeout(600)
        def setpos(sec):
            pg.evaluate("s=>{window.__np.state.position=s}",sec); pg.evaluate("window.StudyOSNowPlaying.requestPoll()"); pg.wait_for_timeout(900)
        def geo():
            return pg.evaluate("""()=>{const box=document.getElementById('npLyrics'),a=box.querySelector('.np-lyrics-line.active'),pop=document.getElementById('nowPlayingPopover').getBoundingClientRect(),tr=document.getElementById('nowPlayingTrigger').getBoundingClientRect();
              if(!a)return null;const ab=a.getBoundingClientRect(),bb=box.getBoundingClientRect();
              return {text:a.textContent.slice(0,24),centerOff:Math.round((ab.top+ab.height/2)-(bb.top+box.clientHeight/2)),popW:Math.round(pop.width),popH:Math.round(pop.height),trW:Math.round(tr.width),trH:Math.round(tr.height),aH:Math.round(ab.height),
              truncated:a.scrollWidth>a.clientWidth+1,ellipsis:getComputedStyle(a).textOverflow,nowrap:getComputedStyle(a).whiteSpace,boxH:Math.round(bb.height)}}""")
        setpos(30); g1=geo(); setpos(24); g2=geo(); setpos(26); g3=geo(); setpos(44); g4=geo()
        out={'mid':g1,'long':g2,'after':g3,'late':g4}
        b.close()
    srv.shutdown(); return out
a=run(sys.argv[1],int(sys.argv[2]),'x')
print(json.dumps(a,indent=0))

if len(sys.argv)>3 and sys.argv[3]=='assert':
    g=list(a.values()); ok=True
    def chk(c,m):
        global ok; print(('PASS ' if c else 'FAIL ')+m); ok=ok and c
    chk(all(abs(x['centerOff'])<=44 for x in g),'active lyric stays within the centre band of the lyric window (original logic deadband = 22% of the box)')
    chk(len({(x['popW'],x['popH'],x['trW'],x['trH'],x['boxH'],x['aH']) for x in g})==1,'popover, trigger, lyric box and row heights never change between lines (incl. a very long line)')
    chk(a['long']['truncated'] and a['long']['ellipsis']=='ellipsis' and a['long']['nowrap']=='nowrap','long lyric is cut with an ellipsis instead of wrapping/expanding')
    sys.exit(0 if ok else 1)
