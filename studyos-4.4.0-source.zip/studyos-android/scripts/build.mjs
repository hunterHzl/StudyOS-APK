// Build helper: node scripts/build.mjs <sync|debug|release|verify>
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { prepareWeb } from './prepare-web.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const win = process.platform === 'win32';
const androidDir = path.join(root, 'android');
const dist = path.join(root, 'dist');
const sh = (cmd, args, cwd = root, capture = false) =>
  spawnSync(cmd, args, { cwd, shell: win, encoding: 'utf8', stdio: capture ? 'pipe' : 'inherit' });
const fail = (m) => { console.error('\n' + m); process.exit(1); };

function needAndroid() { if (!fs.existsSync(androidDir)) fail('android/ not found. Run `npm run setup` first.'); }
function sync() { needAndroid(); prepareWeb(); if (sh('npx', ['cap', 'sync', 'android']).status !== 0) fail('cap sync failed'); }
function gradle(task, extra = []) {
  const wrapper = path.join(androidDir, win ? 'gradlew.bat' : 'gradlew');
  if (!win) { try { fs.chmodSync(wrapper, 0o755); } catch {} }
  const r = sh(wrapper, [task, ...extra], androidDir);
  if (r.status !== 0) fail(`Gradle task ${task} failed.`);
}
function sha256(file) { return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'); }

function findApksigner() {
  const sdk = process.env.ANDROID_HOME || process.env.ANDROID_SDK_ROOT;
  if (!sdk) return null;
  const bt = path.join(sdk, 'build-tools');
  if (!fs.existsSync(bt)) return null;
  const vs = fs.readdirSync(bt).sort((a, b) => a.localeCompare(b, undefined, { numeric: true })).reverse();
  for (const v of vs) { const p = path.join(bt, v, win ? 'apksigner.bat' : 'apksigner'); if (fs.existsSync(p)) return p; }
  return null;
}

function findBuildTool(name) {
  const sdk = process.env.ANDROID_HOME || process.env.ANDROID_SDK_ROOT;
  const bt = sdk && path.join(sdk, 'build-tools');
  if (!bt || !fs.existsSync(bt)) return null;
  for (const v of fs.readdirSync(bt).sort((a, b) => a.localeCompare(b, undefined, { numeric: true })).reverse()) {
    for (const ext of win ? ['.exe', '.bat', ''] : ['']) { const p = path.join(bt, v, name + ext); if (fs.existsSync(p)) return p; }
  }
  return null;
}

/** What the installed app will look like: id, version, label, icon, permissions, debuggable flag. */
function checkBadging(apk, { release }) {
  const aapt2 = findBuildTool('aapt2');
  if (!aapt2) { console.warn('aapt2 not found: skipped label/icon/permission check.'); return; }
  const r = sh(aapt2, ['dump', 'badging', apk], root, true);
  const t = (r.stdout || '');
  if (r.status !== 0) fail('aapt2 could not read the APK.');
  const props = Object.fromEntries(fs.readFileSync(path.join(root, 'version.properties'), 'utf8').split('\n').filter((l) => l.includes('=') && !l.startsWith('#')).map((l) => l.split('=')));
  const pkg = /package: name='([^']+)' versionCode='(\d+)' versionName='([^']+)'/.exec(t) || [];
  const label = (/application-label:'([^']*)'/.exec(t) || [])[1];
  const problems = [];
  if (release) {
    if (pkg[1] !== 'com.hunterhz.studyos') problems.push(`application id is ${pkg[1]}`);
    if (label !== 'StudyOS') problems.push(`label is "${label}" (expected StudyOS)`);
    if (/application-debuggable/.test(t)) problems.push('APK is debuggable');
    if (pkg[2] !== props.versionCode || pkg[3] !== props.versionName) problems.push(`version ${pkg[3]} (${pkg[2]}) does not match version.properties`);
  }
  const perms = [...t.matchAll(/uses-permission: name='([^']+)'/g)].map((m) => m[1]);
  const allowed = new Set(['android.permission.INTERNET', 'android.permission.ACCESS_NETWORK_STATE']);
  const extra = perms.filter((p) => !allowed.has(p) && !p.endsWith('.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION'));
  if (extra.length) problems.push('unexpected permissions: ' + extra.join(', '));
  const icons = [...t.matchAll(/application-icon-(\d+):'([^']+)'/g)].map((m) => m[2]);
  if (!icons.length || !icons.some((i) => /ic_launcher/.test(i))) problems.push('launcher icon (ic_launcher) not found in the APK');
  if (!/mipmap-anydpi-v26\/ic_launcher\.xml/.test(icons.join(' ')) && !/mipmap-anydpi-v26/.test(t)) console.warn('note: adaptive icon XML was not listed by aapt2 (check on a device).');
  console.log(`Package ${pkg[1]} · version ${pkg[3]} (${pkg[2]}) · label "${label}" · permissions: ${perms.join(', ') || 'none'}`);
  console.log(`Launcher icons: ${icons.slice(0, 3).join(' | ')}`);
  if (problems.length) fail('APK check FAILED:\n - ' + problems.join('\n - '));
  console.log('APK identity, icon, label and permissions OK.');
}

/** Checks the AAB is signed (jarsigner, needs a JDK) and contains the adaptive icon + manifest. */
function checkBundle(aab) {
  const js = path.join(process.env.JAVA_HOME || '', 'bin', win ? 'jarsigner.exe' : 'jarsigner');
  const jarsigner = fs.existsSync(js) ? js : 'jarsigner';
  const r = sh(jarsigner, ['-verify', '-certs', aab], root, true);
  if (r.error) console.warn('jarsigner not found: AAB signature not checked.');
  else if (r.status !== 0 || /unsigned|not signed/i.test(r.stdout + r.stderr)) fail('AAB signature verification FAILED.\n' + r.stdout + r.stderr);
  else if (/jar verified/i.test(r.stdout)) console.log('AAB signature verified (jarsigner).');
  const l = sh(win ? 'jar' : 'unzip', win ? ['tf', aab] : ['-l', aab], root, true);
  if (!l.error && l.status === 0) {
    const names = l.stdout;
    if (!/base\/res\/mipmap-anydpi-v26\/ic_launcher\.xml|base\/res\/.*ic_launcher/.test(names)) fail('AAB does not contain the StudyOS launcher icon.');
    if (!/base\/manifest\/AndroidManifest\.xml/.test(names)) fail('AAB has no base manifest.');
    console.log('AAB contents OK (manifest + launcher icon present).');
  }
}

function verify(apk, { release }) {
  const signer = findApksigner();
  if (!signer) fail('apksigner not found (install Android SDK build-tools and set ANDROID_HOME).');
  const r = sh(signer, ['verify', '--verbose', '--print-certs', '--min-sdk-version', '24', apk], root, true);
  const out = (r.stdout || '') + (r.stderr || '');
  console.log(out);
  if (r.status !== 0) fail('APK signature verification FAILED.');
  const v2 = /v2 scheme[^\n]*: true/.test(out), v3 = /v3 scheme[^\n]*: true/.test(out);
  if (!v2 || !v3) fail(`Signature schemes: v2=${v2} v3=${v3}. Both are required.`);
  const fp = (/certificate SHA-256 digest: ([0-9a-f]+)/i.exec(out) || [])[1];
  if (release) {
    if (/Android Debug/i.test(out)) fail('Release APK is signed with the DEBUG key.');
    const pin = path.join(root, 'release-cert.sha256');
    if (fp) {
      if (!fs.existsSync(pin)) { fs.writeFileSync(pin, fp + '\n'); console.log('Pinned release certificate fingerprint in release-cert.sha256 (commit this file; it is public).'); }
      else if (fs.readFileSync(pin, 'utf8').trim() !== fp) fail('Signing certificate DIFFERS from the pinned one (release-cert.sha256). An APK signed with a different key cannot update the installed app.');
      else console.log('Certificate matches the pinned fingerprint: updates will install over earlier releases.');
    }
  }
  console.log('Signature OK (v2 + v3).');
  checkBadging(apk, { release });
}

const cmd = process.argv[2];
if (cmd === 'sync') sync();
else if (cmd === 'debug') {
  sync(); gradle('assembleDebug');
  const apk = path.join(androidDir, 'app/build/outputs/apk/debug/app-debug.apk');
  if (!fs.existsSync(apk)) fail('Debug APK not found after build.');
  fs.mkdirSync(dist, { recursive: true });
  fs.copyFileSync(apk, path.join(dist, 'StudyOS-debug.apk'));
  console.log('\nBuilt dist/StudyOS-debug.apk (installs as "StudyOS Debug", separate from the real app and its data).');
} else if (cmd === 'release') {
  if (!fs.existsSync(path.join(root, 'keystore.properties')) && !process.env.STUDYOS_KEYSTORE_FILE) fail('No signing configuration. Run `npm run keystore` once first.');
  sync(); gradle('assembleRelease', ['bundleRelease', ...process.argv.slice(3)]);
  const apk = path.join(androidDir, 'app/build/outputs/apk/release/app-release.apk');
  if (!fs.existsSync(apk)) fail('Signed release APK not found (an app-release-unsigned.apk means signing was not applied).');
  fs.mkdirSync(dist, { recursive: true });
  const target = path.join(dist, 'StudyOS-release.apk');
  fs.copyFileSync(apk, target);
  verify(target, { release: true });
  const aab = path.join(androidDir, 'app/build/outputs/bundle/release/app-release.aab');
  if (!fs.existsSync(aab)) fail('Signed release bundle (.aab) not found after build.');
  const aabTarget = path.join(dist, 'StudyOS-release.aab');
  fs.copyFileSync(aab, aabTarget);
  checkBundle(aabTarget);
  fs.writeFileSync(path.join(dist, 'SHA256SUMS.txt'), `${sha256(target)}  StudyOS-release.apk\n${sha256(aabTarget)}  StudyOS-release.aab\n`);
  console.log('\nBuilt dist/StudyOS-release.apk and dist/StudyOS-release.aab');
} else if (cmd === 'verify') {
  const f = path.join(dist, 'StudyOS-release.apk');
  if (!fs.existsSync(f)) fail('dist/StudyOS-release.apk not found.');
  verify(f, { release: true });
  const ab = path.join(dist, 'StudyOS-release.aab'); if (fs.existsSync(ab)) checkBundle(ab);
} else fail('Usage: node scripts/build.mjs <sync|debug|release|verify>');
