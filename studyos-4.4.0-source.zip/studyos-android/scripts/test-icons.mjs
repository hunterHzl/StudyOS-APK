// Verifies the official-icon resources: every density present with the right pixel size, adaptive XML wired, manifest references.
import assert from 'node:assert'; import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..'); const res = path.join(root, 'android-native/res');
const png = (f) => { const b = fs.readFileSync(f); assert.strictEqual(b.toString('latin1', 1, 4), 'PNG', f + ' is not a PNG'); return [b.readUInt32BE(16), b.readUInt32BE(20)]; };
const sizes = { mdpi: [48, 108], hdpi: [72, 162], xhdpi: [96, 216], xxhdpi: [144, 324], xxxhdpi: [192, 432] };
for (const [d, [legacy, adaptive]] of Object.entries(sizes)) {
  for (const n of ['ic_launcher', 'ic_launcher_round']) assert.deepStrictEqual(png(path.join(res, `mipmap-${d}/${n}.png`)), [legacy, legacy], `${n} ${d}`);
  for (const n of ['ic_launcher_foreground', 'ic_launcher_monochrome']) assert.deepStrictEqual(png(path.join(res, `mipmap-${d}/${n}.png`)), [adaptive, adaptive], `${n} ${d}`);
}
for (const x of ['ic_launcher.xml', 'ic_launcher_round.xml']) {
  const t = fs.readFileSync(path.join(res, 'mipmap-anydpi-v26', x), 'utf8');
  assert.match(t, /<background android:drawable="@color\/ic_launcher_background"/); assert.match(t, /<foreground android:drawable="@mipmap\/ic_launcher_foreground"/); assert.match(t, /<monochrome/);
}
const svg = fs.readFileSync(path.join(root, 'web-src/icon.svg'), 'utf8');
const bg = /<rect[^>]*fill="(#[0-9a-f]{6})"/i.exec(svg)[1].toUpperCase();
assert.ok(fs.readFileSync(path.join(res, 'values/ic_launcher_background.xml'), 'utf8').toUpperCase().includes(bg), 'adaptive background must match the official artwork colour');
assert.deepStrictEqual(png(path.join(root, 'assets/store-icon-512.png')), [512, 512]);
const man = fs.readFileSync(path.join(root, 'android-native/AndroidManifest.xml'), 'utf8');
assert.match(man, /android:icon="@mipmap\/ic_launcher"/); assert.match(man, /android:roundIcon="@mipmap\/ic_launcher_round"/);
assert.ok(!fs.existsSync(path.join(res, 'drawable/splash.png')), 'splash must be the XML layer-list, not a stretched bitmap');
console.log('ok  - official icon: 5 densities x (legacy, round, adaptive fg, themed mono), adaptive XML, store icon, manifest wiring');
