// Release hygiene: no signing secrets, private keys, tokens, personal data or cleartext network config in anything that would be committed/shipped.
import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const skipDir = new Set(['node_modules', 'www', 'dist', 'keystore', '.git', 'build', '.gradle', 'shots']);
const skipFile = new Set(['keystore.properties']);
const problems = []; let scanned = 0;
const walk = (d) => { for (const e of fs.readdirSync(d, { withFileTypes: true })) {
  const p = path.join(d, e.name), rel = path.relative(root, p);
  if (e.isDirectory()) { if (!skipDir.has(e.name) && !rel.startsWith('android' + path.sep + 'app' + path.sep + 'build')) walk(p); continue; }
  if (skipFile.has(e.name)) continue;
  if (/\.(jks|keystore|p12|pfx|pem)$/i.test(e.name)) { problems.push(`${rel}: key material outside keystore/`); continue; }
  if (!/\.(js|mjs|json|xml|gradle|properties|md|txt|html|css|yml|yaml|py|java|pro|svg|webmanifest)$/i.test(e.name)) continue;
  const t = fs.readFileSync(p, 'utf8'); scanned++;
  if (/-----BEGIN [A-Z ]*PRIVATE KEY-----/.test(t)) problems.push(`${rel}: private key block`);
  if (/AKIA[0-9A-Z]{16}|ghp_[A-Za-z0-9]{30,}|xox[abp]-[A-Za-z0-9-]{10,}|AIza[0-9A-Za-z_-]{30,}/.test(t)) problems.push(`${rel}: looks like an API token`);
  for (const m of t.matchAll(/^\s*(storePassword|keyPassword)\s*=\s*(.+)$/gm)) if (!/^\s*(\$|System\.getenv|ks|cred|process)/.test(m[2]) && !rel.endsWith('.md')) problems.push(`${rel}: literal ${m[1]}`);
  if (/web-src[\\/](index\.html|app\.js)$/.test(rel)) {
    if (/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[a-z]{2,}/.test(t.replace(/user@example\.com/g, ''))) problems.push(`${rel}: contains an e-mail address`);
    if (/\b\+?\d[\d -]{9,14}\d\b/.test(t.replace(/\d{4}-\d{2}-\d{2}/g, '').replace(/\d{10,}\.\d+/g, ''))) { /* long digit runs are common in code; informational only */ }
  }
  if (rel.endsWith('AndroidManifest.xml')) {
    if (/usesCleartextTraffic="true"/.test(t)) problems.push(`${rel}: cleartext traffic enabled`);
    if (/android:debuggable="true"/.test(t)) problems.push(`${rel}: debuggable=true`);
  }
} };
walk(root);
const gi = fs.readFileSync(path.join(root, '.gitignore'), 'utf8');
for (const need of ['keystore/', 'keystore.properties', '*.jks']) if (!gi.includes(need)) problems.push(`.gitignore is missing ${need}`);
const cfg = JSON.parse(fs.readFileSync(path.join(root, 'capacitor.config.json'), 'utf8'));
if (cfg.server && cfg.server.url) problems.push('capacitor.config.json points at a dev server (server.url)');
if (cfg.android && cfg.android.webContentsDebuggingEnabled) problems.push('WebView debugging is enabled');
if (cfg.appId !== 'com.hunterhz.studyos' || cfg.appName !== 'StudyOS') problems.push('appId/appName changed');
const pk = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
for (const dep of Object.keys({ ...pk.dependencies, ...pk.devDependencies })) if (!/^@capacitor\//.test(dep)) problems.push('unexpected dependency ' + dep);
assert(problems.length === 0, 'Release hygiene problems:\n - ' + problems.join('\n - '));
function assert(c, m) { if (!c) { console.error(m); process.exit(1); } }
console.log(`ok  - release hygiene: ${scanned} files scanned, no secrets/tokens/key material, no cleartext or dev-server config, only Capacitor dependencies`);
