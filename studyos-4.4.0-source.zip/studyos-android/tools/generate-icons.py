"""Generates every Android icon resource from web-src/icon.svg (the official StudyOS artwork). The source SVG is only READ.
Needs: python3, playwright (chromium), pillow.  Output -> android-native/res (committed; the build does not need this script)."""
import re, os, sys
from playwright.sync_api import sync_playwright
root=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
svg=open(os.path.join(root,'web-src/icon.svg')).read()
BG=re.search(r'<rect[^>]*fill="(#[0-9A-Fa-f]{6})"',svg).group(1)      # #DCEBCF
FG=re.search(r'<path[^>]*fill="(#[0-9A-Fa-f]{6})"',svg).group(1)      # #304A35
D=re.search(r'<path d="([^"]+)"',svg).group(1)
RX=int(re.search(r'rx="(\d+)"',svg).group(1))
res=os.path.join(root,'android-native/res'); os.makedirs(res,exist_ok=True)
CX,CY=66.5,69.0   # centre of the S glyph inside the 128 box
def page(b,px,body):
    pg=b.new_page(viewport={'width':px,'height':px}); pg.set_content(f'<body style="margin:0;background:transparent">{body}</body>'); return pg
def shot(b,path,px,body):
    os.makedirs(os.path.dirname(path),exist_ok=True); pg=page(b,px,body); pg.screenshot(path=path,omit_background=True,clip={'x':0,'y':0,'width':px,'height':px}); pg.close()
def full(px):      # the official icon exactly as drawn (rounded square)
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="{px}" height="{px}"><rect width="128" height="128" rx="{RX}" fill="{BG}"/><path d="{D}" fill="{FG}"/></svg>'
def round_(px):    # same artwork on a circle for legacy round icons
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="{px}" height="{px}"><circle cx="64" cy="64" r="64" fill="{BG}"/><g transform="translate(64 64) scale(.86) translate(-{CX} -{CY})"><path d="{D}" fill="{FG}"/></g></svg>'
F=0.68             # glyph scale inside the adaptive 108dp canvas: keeps the S inside the 66dp safe circle
def layer(px,color,bg=None):
    r=f'<rect width="108" height="108" fill="{bg}"/>' if bg else ''
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 108" width="{px}" height="{px}">{r}<g transform="translate(54 54) scale({F}) translate(-{CX} -{CY})"><path d="{D}" fill="{color}"/></g></svg>'
dens={'mdpi':(48,108),'hdpi':(72,162),'xhdpi':(96,216),'xxhdpi':(144,324),'xxxhdpi':(192,432)}
with sync_playwright() as p:
    b=p.chromium.launch()
    for d,(leg,ad) in dens.items():
        base=f'{res}/mipmap-{d}'
        shot(b,f'{base}/ic_launcher.png',leg,full(leg)); shot(b,f'{base}/ic_launcher_round.png',leg,round_(leg))
        shot(b,f'{base}/ic_launcher_foreground.png',ad,layer(ad,FG)); shot(b,f'{base}/ic_launcher_monochrome.png',ad,layer(ad,'#000000'))
    shot(b,os.path.join(root,'assets/store-icon-512.png'),512,layer(512,FG,BG))            # Play Store listing icon (full square, store masks it)
    shot(b,f'{res}/drawable-nodpi/splash_icon.png',288,full(288))
    b.close()
os.makedirs(f'{res}/mipmap-anydpi-v26',exist_ok=True)
adaptive='''<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_background" />
    <foreground android:drawable="@mipmap/ic_launcher_foreground" />
    <monochrome android:drawable="@mipmap/ic_launcher_monochrome" />
</adaptive-icon>
'''
for n in ('ic_launcher.xml','ic_launcher_round.xml'): open(f'{res}/mipmap-anydpi-v26/{n}','w').write(adaptive)
os.makedirs(f'{res}/values',exist_ok=True); os.makedirs(f'{res}/values-night',exist_ok=True); os.makedirs(f'{res}/drawable',exist_ok=True)
open(f'{res}/values/ic_launcher_background.xml','w').write(f'<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">{BG}</color>\n</resources>\n')
open(f'{res}/values/studyos_splash.xml','w').write('<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="studyos_splash_bg">#F7F7F7</color>\n</resources>\n')
open(f'{res}/values-night/studyos_splash.xml','w').write('<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="studyos_splash_bg">#000000</color>\n</resources>\n')
open(f'{res}/drawable/splash.xml','w').write('''<?xml version="1.0" encoding="utf-8"?>
<layer-list xmlns:android="http://schemas.android.com/apk/res/android">
    <item><color android:color="@color/studyos_splash_bg" /></item>
    <item><bitmap android:gravity="center" android:src="@drawable/splash_icon" /></item>
</layer-list>
''')
print('icons generated from',os.path.join(root,'web-src/icon.svg'),'bg',BG,'fg',FG)
